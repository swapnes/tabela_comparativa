@echo off
rem Faz agora uma copia do banco em back\dados\backups (alem da copia automatica diaria).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\backup.ps1"
echo.
pause
