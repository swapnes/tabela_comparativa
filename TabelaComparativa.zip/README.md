# Tabela Comparativa Intelbras (câmeras, gravadores, baluns e extensores)

Site com as características técnicas dos equipamentos **em linha**, com filtros, busca e ficha técnica. A lista do que está em linha vem da **Tabela de Preços Distribuição** (CSV), importada pelo painel do admin. O admin completa os dados técnicos dos modelos novos e pode criar características (filtros) novas.

> Este README é o documento de acompanhamento do projeto: o que existe, as regras, o plano e o histórico.
> **Sempre que algo mudar no código, atualize a seção correspondente e o [Histórico](#histórico-de-alterações).**

---

## Sumário
- [Como funciona](#como-funciona)
- [Estrutura](#estrutura)
- [Como rodar](#como-rodar)
- [Configuração (back/.env)](#configuração-backenv)
- [Planilha de preços e sincronização](#planilha-de-preços-e-sincronização)
- [Regras de negócio](#regras-de-negócio)
- [Área de admin](#área-de-admin)
- [Histórico e "Desfazer"](#histórico-e-desfazer)
- [Removidos](#removidos)
- [Armazenamento](#armazenamento)
- [Características (filtros)](#características-filtros)
- [API](#api)
- [Testes](#testes)
- [Plano: PC de testes → servidor do trabalho](#plano-pc-de-testes--servidor-do-trabalho)
- [Implantação no servidor](#implantação-no-servidor-do-trabalho-rodando-sozinha-porta-49152)
- [Pendências](#pendências)
- [Histórico de alterações](#histórico-de-alterações)
- [Notas para a IA / quem for mexer no código](#notas-para-a-ia--quem-for-mexer-no-código)

---

## Como funciona

```
 Analistas: http://MAQUINA:3777 → menu (Câmeras analógicas, Câmeras IP, NVDs, DVRs, Baluns, Extensores, Phaseout, Recuperação de senha)
            → tabela com filtros por coluna, busca geral e ficha técnica (clique no equipamento)

 Admin (botão "Admin"): importa a "Tabela de Preços Distribuição" (CSV) 2–3x por semana
   Importar e analisar (prévia) → Aplicar mudanças
   ┌──────────────────────────────────────────────────────────────┐
   │ Modelo da nossa linha na planilha e fora da tabela            │ → entra EM LINHA + alerta "preencher dados"
   │ Mesmo equipamento com nome diferente                          │ → renomeia (dados mantidos)
   │ Modelo novo parecido com um antigo em phaseout                │ → entra com os dados técnicos do antigo
   │ Equipamento em linha que sumiu da planilha                    │ → PHASEOUT (data de hoje) + alerta
   │ Equipamento em phaseout que voltou para a planilha            │ → EM LINHA de novo (dados mantidos)
   │ Modelo FT (linha Future, outro segmento)                      │ → não é adicionado
   └──────────────────────────────────────────────────────────────┘
```

**Um único programa** (pasta `back`) serve o site e a API, numa única porta (3777). Não há IP fixo no código: o site chama a API no mesmo endereço em que foi aberto (`/api`), então funciona igual no PC e no servidor.

## Estrutura

```
tabela/
├── INICIAR.bat                 # Liga o sistema e abre o navegador (funciona em qualquer pasta)
├── RESTAURAR_TABELA_ANTIGA.bat # Coloca a cópia (pg_dump) da tabela antiga no banco daqui
├── README.md
├── Tabela de Preços ... .csv   # Planilha de exemplo (setembro) para importar pelo painel
├── back/                       # Servidor: site + API (Node.js + Express + PostgreSQL)
│   ├── .env                    # Login do admin, banco, porta (NÃO compartilhar)
│   ├── .env.example
│   ├── index.js                # Rotas da API (/api/...) e entrega do site (front/build)
│   ├── config.js · db.js       # Configuração e conexão com o banco
│   ├── banco.js                # Cria as tabelas que faltarem ao iniciar
│   ├── equipamentos.js         # ⭐ Regras e consultas de equipamentos (status, adicionar, alterar...)
│   ├── colunas.js · alertas.js # Características criadas pelo painel (e troca de valores) · alertas do painel
│   ├── rotina.js               # Avisos de rotina do painel (última planilha aplicada, último backup)
│   ├── middleware/authMiddleware.js
│   ├── dados/                  # Última planilha importada (criada sozinha)
│   └── sincronizacao/
│       ├── regras.js           # ⭐ REGRA DO SEGMENTO: siglas, extração do modelo, FT, "parecido"
│       ├── leitorPlanilha.js   # Lê .csv (UTF-8 ou Windows-1252) e .xlsx, acha o cabeçalho sozinho
│       ├── arquivoPlanilha.js  # Guarda a planilha enviada
│       └── sincronizador.js    # Compara planilha × banco e aplica
└── front/                      # Site (React). Só a pasta build/ é usada para rodar.
    ├── build/                  # Site pronto (gerado por "npm run build")
    ├── public/                 # index.html, logo, ícones dos avisos, fonte Museo Sans
    └── src/
        ├── App.jsx · abas.js · api.js · status.js · filtro.js (colunas, categorias e filtros)
        ├── pages/              # Home, Tabela, LoginAdmin, HomeAdmin (painel), Produtos, Revisão, Phaseout...
        ├── componets/          # (sic) BarraNavegacao, PainelPlanilha, FormularioEquipamento, PainelFiltros, EnviarCliente...
        └── styles/             # Visual (GlobalStyled tem as cores)
```

## Como rodar

Precisa de: **Node.js** (instalado) e **PostgreSQL** com o banco da tabela.

1. Preencha o `back/.env` (login do admin, `DATABASE_URL` do PostgreSQL).
2. Dê dois cliques em **`INICIAR.bat`**. Ele instala as dependências na primeira vez, liga o sistema e abre `http://localhost:3777`.
3. Para desligar, feche a janela.

Na primeira vez, o sistema cria sozinho as tabelas que faltarem no banco (`cameras` e `gravadores` só se não existirem; `baluns`, `extensores`, `alertas`, `sincronizacoes`, `colunas_personalizadas`). **Tabelas que já existem não são alteradas.** Exceção única: se existir a antiga tabela `acessorios`, ela é separada automaticamente em `baluns` e `extensores` (ver Histórico 2026-10-01).

**Alterou o site (front/src)?** Rode `npm run build` na pasta `front` e reinicie. Para desenvolver com recarga automática: `npm start` em `front` (porta 3000, usa a API da porta 3777).

## Configuração (back/.env)

| Variável | Para que serve |
|---|---|
| `ADMIN_USUARIO` / `ADMIN_SENHA` | Login único do admin. Vazios = login desativado. |
| `JWT_SECRET` | Chave que assina o login (texto aleatório). |
| `DATABASE_URL` | PostgreSQL: `postgres://USUARIO:SENHA@SERVIDOR:5432/BANCO` |
| `PORTA` | Porta do site (padrão 3777). |

## Planilha de preços e sincronização

### A planilha (duas abas, desde 05/10/2026)
- **Tabela de Preços Distribuição** em **CSV** (o `.xlsx` também funciona). Formato de setembro/2026: ~35 MB, separador `;`, Windows-1252, cabeçalho na 3ª linha, **cada produto repete 27 vezes (uma por estado)**.
- Importam-se **duas abas**, exportadas cada uma em CSV e escolhidas juntas no painel (o servidor descobre qual é qual pela coluna "Substituto Direto"):
  - **Tabela** → `back/dados/planilha.csv` (colunas "Descrição do Produto", "Produto/Resumo", "Código Produto");
  - **Encerramentos** → `back/dados/encerramentos.csv` (+ "Data" no formato `out-26`, "Substituto Direto", "Indicação"). Leitura em `back/sincronizacao/encerramentos.js`.
- **Em linha = pelo menos uma versão (código) na aba Tabela que NÃO está em Encerramentos.** Se todas as versões que aparecem na Tabela também estão nos Encerramentos, o modelo está descontinuado (a Tabela ainda lista vários produtos já encerrados). Sem o arquivo de Encerramentos vale só a Tabela, e a análise avisa.
- **Phaseout com data e substituto da planilha**: ao ir para o phaseout, o equipamento recebe o mês dos Encerramentos (o da versão encerrada por último; a planilha só traz mês/ano, então a data gravada é o dia 1 e a tabela mostra `10/2026`) e o **substituto direto** (coluna `substituto`, criada em todas as tabelas de equipamentos). Sem substituto direto, usa a coluna "Indicação", gravada como `Indicação: <modelo>`. Substituto que é versão do próprio modelo é ignorado.
- **Equipamentos já em phaseout** que estão nos Encerramentos têm o mês e o substituto corrigidos a cada importação (só o que mudou; o dia digitado no painel fica se o mês for o mesmo; substituto digitado no painel só muda se a planilha trouxer outro).
- Modelo que está nos Encerramentos e nunca foi cadastrado (inclusive o que ainda aparece na aba Tabela com todas as versões encerradas) **entra direto no phaseout**, com mês e substituto (desde 07/10/2026).
- **Modelo novo entra "Em revisão"** (página Revisão do admin): só aparece na tabela depois que o admin preencher os dados técnicos e clicar em "Liberar na tabela" (ou remove, se não for nosso). A planilha não muda o status de quem está em revisão.
- Equipamento em linha que está nos Encerramentos nunca é "renomeado" para um modelo novo parecido (foi descontinuado de verdade): o novo entra copiando os dados.

### Regra do segmento (oficial) — `back/sincronizacao/regras.js`
O modelo é extraído da descrição ("Câmera Bullet **VIP 1230 B G5**, 2MP..." → `VIP 1230 B G5`):

| Siglas | Tabela | Aba |
|---|---|---|
| `VIP`, `VIPC`, `VIPW` (Wi-Fi), `VLP` | câmeras | Câmeras IP |
| `VHD`, `VHL`, `VHC` | câmeras | Câmeras analógicas |
| `MHDX`, `iMHDX` | gravadores | DVRs |
| `NVD`, `iNVD` | gravadores | NVDs |
| `VB` | baluns | Baluns (com `WP` = power balun) |
| `VEX` | extensores | Extensores |

`VTN` e `TESTER` não entram mais na tabela (desde 01/10/2026).

- **FT (linha Future)**: modelo com "FT" (inclusive "F T") não é adicionado (a análise mostra com "Adicionar mesmo assim"). FT já cadastrado não é mexido.
- **REM (remanufaturado)**: modelo com "REM" (ex.: `MHDX 1108-C REM`), de qualquer tipo, **não entra na tabela** e não conta como "em linha" (a análise só lista).
- **Kits e versões**: kits com HD/SSD (`C/HD 1TB`), versão Manaus (`MANAUS`, `AM`) e cada estado contam como o mesmo modelo. **O modelo fica em linha enquanto qualquer versão estiver na aba Tabela e fora dos Encerramentos.**
- **Nomes** comparados sem maiúsculas/espaços/hífens; quando reconhece, padroniza para a grafia da planilha.
- **Nome do datasheet** (`NOMES_DO_DATASHEET` em `regras.js`): a planilha escreve "VEX 3120 G2 4K"; na tabela fica **VEX 3120 HDMI G2 4K** (a importação já lê assim). "VEX 3004 HDMI MULTI-VIEWER" (código 4780039; o "MULTI-VIEWER" é cortado como descrição) vira **VEX 3004 MULTI-VIEWER** desde 28/10/2026; antes virava VEX 3004 SWITCH (4780044), que é outro produto.
- **Geração no resumo**: se a descrição traz `VB 503 B` e o resumo `VB 503 B G2`, vale o resumo (`interpretarProduto`).
- Planilha de setembro: **249 modelos da nossa linha** (111 câmeras, 34 gravadores, 19 acessórios a adicionar num banco vazio + 85 FT ignorados).

### Dados técnicos são sempre mantidos
- Equipamento já cadastrado nunca é recadastrado; se volta para a planilha, volta com todos os dados.
- **Mesmo equipamento com nome diferente** (`VIP 1230 B G4` → planilha `VIP 1230 B BLACK G4`): renomeia em vez de mandar para phaseout.
- **Modelo novo parecido com antigo em phaseout** (`VHD 3230 B` → `VHD 3230 B SL`): o novo entra copiando os dados técnicos.
- "Parecido" (`semelhancaEntreModelos`): mesma sigla, **mesmas partes com número** (1230, G4, 4K — gerações diferentes nunca combinam) e só palavras a mais (B ≠ D).

### Seguranças
- Importar só **analisa**; nada muda até "Aplicar mudanças".
- Planilha errada (sem a coluna de descrição ou sem modelos da nossa linha): nada é alterado.
- **Trava**: mais de 10 equipamentos saindo de linha de uma vez → a confirmação de "Aplicar mudanças" avisa a quantidade e só passa da trava se o admin der OK nela (até 05/10/2026 era uma caixinha à parte, fácil de esquecer: a aplicação saía sem mover nada para o phaseout).
- Na análise, cada item que "iria para phaseout" tem **"É o mesmo que… → Renomear"**.
- Reimportar a mesma planilha não muda nada.

### Login do admin (desde 05/11/2026; `back/index.js` rota `/api/login`, `back/middleware/authMiddleware.js`)
- **Tentativas**: 5 erros do mesmo computador (IP) em 15 minutos bloqueiam o login dele por 15 minutos, até com a senha certa (resposta 429 com quanto falta). Faltando 2 e 1 tentativas, a mensagem avisa. Outros computadores continuam entrando. Fica na memória: reiniciar o servidor zera. Cada erro ainda espera 1 s, e usuário e senha são comparados em tempo constante. O log do servidor registra login certo e recusado com o IP (nunca a senha digitada).
- **Token**: vale 12 h e renova sozinho enquanto o admin usa o painel (depois de 1 h de uso); parado 12 h, pede a senha de novo (antes eram 7 dias). Assinado e conferido só com HS256 (token forjado com outro algoritmo ou sem assinatura é recusado). Leva uma marca do usuário e da senha do `back/.env`: **trocar a `ADMIN_SENHA` desloga todo mundo** na hora em que o servidor reinicia.
- **Página**: login e páginas do admin não abrem dentro de moldura de outro site (`X-Frame-Options: DENY`); o site todo manda `X-Content-Type-Options: nosniff` e `Referrer-Policy: same-origin` e não anuncia o Express. Campo de senha limpa depois de um erro.
- **Aviso ao ligar** (só o aviso, sem mostrar o valor): `ADMIN_SENHA` com menos de 10 caracteres ou `JWT_SECRET` com menos de 32.
- **O que ainda depende da TI**: o servidor é http, então a senha passa pela rede sem criptografia. Só https resolve isso (e também libera copiar imagem do QR code).

## Regras de negócio

### Status (coluna `phaseout`)
| Status | Valor no banco | Onde aparece |
|---|---|---|
| **Em linha** | `phaseout = 'Equipamento em linha'`, `data = null` | Abas de câmeras, gravadores, baluns e extensores |
| **Descontinuado** | outro texto (padrão `'Descontinuado'`) + `data` do phaseout | **Só** na aba Phaseout (amarelo < 3 anos; vermelho > 3 anos) |

### Home e abas (`front/src/abas.js`)
Home = **menu direto** (sem login): Câmeras analógicas, Câmeras IP, NVDs, DVRs (MHDX), Baluns, Extensores, Phaseout, Recuperação de senha e FCA (uma linha inteira cada). Botão **Admin** discreto no canto. "Todas as câmeras" e "Todos os gravadores" saíram do menu e da barra em 28/10/2026 (pedido do Gabriel: ninguém usava); os endereços `/cameras` e `/gravadores` continuam abrindo, para links antigos.
Na barra do topo, **Phaseout** fica com um tom vermelho translúcido, **Recuperação de senha** com azul e **FCA** com roxo (`destaque` em `abas.js`, `.destaque` em `styles/NavStyled.js`), para separar das abas de produtos em linha.
**Barra do topo em tela menor** (desde 29/10/2026; antes as últimas abas ficavam cortadas, escondidas numa rolagem sem barra): até 1280 px de largura, logo, HDs e Admin ficam em cima e as abas inteiras na linha de baixo; se ainda não couberem (celular), quebram em mais linhas. Nunca ficam cortadas.
**Contador de acessos** (desde 29/10/2026): no canto de baixo à esquerda da Home ("Acessos N"). Soma 1 a cada vez que o site é carregado em qualquer página (abrir ou recarregar conta; trocar de aba dentro do site não). `contarAcesso` em `front/src/api.js` (chamado uma vez no `index.js`) → `POST /api/acessos` → tabela `contador_acessos` (uma linha, `id = 1`). Começa do zero no servidor.

| Aba | Endereço |
|---|---|
| Câmeras analógicas | `/cameras?modelo=VHD,VHL,VHC` (esconde as colunas só de IP) |
| Câmeras IP | `/cameras?modelo=VIP,VLP,VIPC,VIPW` |
| NVDs | `/gravadores?modelo=NVD` (esconde as colunas só de analógico) |
| DVRs (MHDX) | `/gravadores?modelo=MHDX` (esconde InSearch e Portas PoE, só de NVD) |
| Baluns | `/baluns` |
| Extensores | `/extensores` |
| Phaseout | `/phaseout_senhas` |
| Recuperação de senha | `/recuperacao_senha` (`?ns=...` já preenche o NS do gerador; ver "Recuperação de senha" abaixo) |
| FCA | `/fca` (ver "FCA" abaixo) |

### Recuperação de senha (`pages/RecuperacaoSenha.jsx`, `front/src/recuperacao/`; desde 29/10/2026)
As 3 telas do site antigo do 10.1.45.193:8053 (zips da pasta `REC senha`), numa aba pública só, sem ligação com o admin. **Desde 05/11/2026 é uma página só, sem as 3 partes (pílulas)**: em cima o gerador ("Gravadores e faciais") ao lado das "Senhas geradas", embaixo o cartão "Recuperação Jufeng" (as 2 etapas lado a lado) e a Consulta de NS numa janela aberta pela **lupa** no canto de cima, igual à da FCA (estilo `.botao-lupa` em `RecuperacaoStyled.js`, usado pelas duas):
- **Consulta de NS** (janela da lupa, `ConsultaNS`): NS de 13 letras e números → modelo pela API de produtos da Intelbras, QR code do NS (api.qrserver.com, como no antigo; "Copiar QR code" copia a imagem; no servidor em http vai como figura, e "Baixar" salva o PNG, desde 05/11/2026) e "Copiar NS". Se o modelo está no Phaseout da tabela, mostra o mês, os métodos de recuperação e o substituto. Botão para gerar as senhas (gravadores e faciais SS) ou ir para a Jufeng (lista `MODELOS_JUFENG`).
- **Recuperação de senha** (gravadores e faciais): NS (com 13 caracteres o modelo aparece sozinho), modelo (lista por linha, com busca; `recuperacao/modelos.js`, copiado do antigo), data do equipamento (campo dd/mm/aaaa com máscara, `componets/CampoData.jsx`, desde 04/11/2026: digita só os números e as barras entram sozinhas, "1/1/26" vira 01/01/2026 ao sair do campo, data que não existe fica vermelha; botão de calendário e atalhos **Hoje** e **01/01/2000** (o **Ontem** saiu em 05/11/2026, a pedido), a data que o gravador mostra quando a bateria do relógio está com problema; começa em hoje) e ano do firmware (só nos modelos que escolhem o gerador por ele). **Gerar senhas** chama os geradores do callcenter (`recsenha-callcenter.intelbras.com.br/ws/gera_senha/1..4`, o 3 também tem a conta feita aqui) na mesma ordem do antigo: primeiro o do modelo, depois os outros, sem repetir (na tela: 1ª, 2ª...). A mensagem para o cliente (texto do antigo, sem a frase da "senha mais forte" desde 29/10/2026: "Teste as senhas na ordem abaixo, começando pela primeira..."; com o passo a passo de troca de senha, o aviso de descontinuado há mais de 3 anos e o do botão de reset) já vai para a área de transferência; cada senha tem o seu botão de copiar. Botões para copiar só o passo a passo (interface preta, cinza, VD; o do facial antigo saiu em 29/10/2026 a pedido, e a tela não fala mais em faciais). Os faciais SS continuam na lista de modelos: só o gerador 4 e a mensagem do facial. Cada gerador é chamado uma vez só por consulta (o antigo repetia).
- **Tutorial da Recuperação** (desde 29/10/2026; `passosDaRecuperacao` em `pages/RecuperacaoSenha.jsx`, mesmo `componets/Tutorial.jsx` da tabela): botão azul **Tutorial** ao lado do título; 9 passos (lupa, NS, modelo, data e firmware, Gerar senhas, senhas geradas, passo a passo, Jufeng ferramenta e código; `PASSOS_DO_TUTORIAL` desde 05/11/2026). Não chama a Intelbras.
- **Recuperação Jufeng**: link da ferramenta para o PC do cliente (baixar ou copiar) e a chave que ela mostra → "Código de segurança: ..." copiado. Aviso amarelo com a lista dos **únicos** equipamentos que a ferramenta reseta (`EQUIPAMENTOS_JUFENG`, escrita como na lista enviada pelo Gabriel em 29/10/2026): câmeras VIP 1020 B/D, VIP 1120 B/D (G1 e G2), VIP 1220 B/D (G1, G2 e G3), VIP 1130 (D) VF (G1 e G2), VIP 3230 VF (G1 e G2); NVRs NVD 1204, 1208 e 1216.
- **O que mudou em relação ao antigo**: o phaseout vem da tabela (o antigo tinha uma cópia fixa); geradores que pedem NS só são chamados com o NS completo (o antigo chamava com o NS vazio); gerador que não responde vira aviso na tela; "Nova consulta" funciona (no antigo dava erro); o token da Intelbras é guardado até perto de vencer (o antigo pedia um a cada consulta); NS que a regra antiga não reconhecia ainda acha o modelo se o nome dele aparecer inteiro na resposta.
- **Como chama a Intelbras** (`recuperacao/intelbras.js`): direto do navegador, como o antigo (com as mesmas credenciais de aplicação que já estavam no código dele). Espera no máximo 12 s por resposta: sem resposta, avisa "a Intelbras não respondeu a tempo" (gerador: "O gerador N não respondeu.", e a senha calculada aqui ainda sai) em vez de ficar travado em "Gerando...". **O `recsenha-callcenter` (geradores) só responde pela VPN da Intelbras**; os outros (token, NS, Jufeng) são públicos. Se o navegador for bloqueado (CORS, por o site estar em outro endereço), passa a chamar por `POST /api/recuperacao/encaminhar` (o servidor da tabela só encaminha para os 5 endereços da recuperação; qualquer outro = 400).
- **Testado** com respostas simuladas (sem chamar a Intelbras de verdade, 29/10/2026): NS → MHDX 1104 sozinho, phaseout 05/2022 com o aviso de mais de 3 anos e o do botão de reset; ordem dos geradores 4, 1, 2, 3, 4 igual ao antigo; HDCVI 1004 G2 sem NS (aviso); Consulta de NS → botão leva para o gerador com o NS; Jufeng; plano B pelo servidor. **Testado de verdade em 29/10/2026** (deste PC, com a VPN): tokens das duas APIs, NS (rota certa: 401 sem token, 404 "não encontrado" com token para um NS inventado), os 4 geradores com senha e a Jufeng com código; CORS liberado nos 5 endereços (então o navegador chama direto). Sem a VPN, o callcenter não responde e a tela avisa em ~24 s (VD 3104). Falta só uma consulta com NS real.

### FCA (`pages/Fca.jsx`, `front/src/fca/`; desde 05/11/2026)
Os dois sites de FCA que o pessoal usava (pasta `autofca/`: "Gerador FCA" do 10.1.45.193:8055 e "AUTO FCA" do 10.1.45.193:8154) juntos numa aba pública, à direita da Recuperação de senha:
- **3 modos** (como no AUTO FCA): **Padrão** (modelo, fato, causa, ação, informações adicionais), **Mau funcionamento** (+ "Dados do cliente checados no Salesforce", checklist do produto e classificação interna: fila e melhor contato) e **Atendimento facilitado** (+ pessoa solicitante e endereço de retorno; o CEP completo preenche rua, bairro, cidade e estado pelo ViaCEP).
- **Produto**: um por linha; o NS ao lado consulta a Intelbras (mesma `consultarNS` da Recuperação de senha, precisa da VPN) e põe "MODELO - NS" numa linha nova. Sem achar o NS, dá para "Adicionar só o NS".
- **Fato e causa com sugestões** (as do Gerador FCA) e **Guardar para usar de novo** (até 05/11/2026 "Salvar nas sugestões": guarda o texto escrito na lista de sugestões do campo, para escolher nos próximos atendimentos sem digitar; fica neste navegador; as guardadas têm estrela e um X para tirar).
- **Checklist do mau funcionamento** (`CHECKLISTS` em `fca/dados.js`): as perguntas do AUTO FCA viram campos e entram no texto; para câmeras IP, DVR/NVR, analógicas e SIM Next/Play aparece também, em Orientações, a lista de informações obrigatórias do Gerador FCA para ir marcando ("2 de 18 conferidos"; não entra no texto). **Defense IA Lite** troca o FCA pelo Template AD. Checklists na lista: Câmeras IP, DVR/NVR, Câmeras analógicas, Software (SIM Next/Play) e Defense IA Lite; os de vídeo porteiro, Allo, fechaduras, campainhas, IVW 3000 e serviços Mibo saíram em 05/11/2026 (pedido do Gabriel: não são do setor).
- **Texto pronto** ao lado, atualizando enquanto digita (`fca/texto.js`): títulos em negrito com as letras Unicode do AUTO FCA (opção "Títulos em negrito"), cada linha da ação vira um item; o facilitado sai no modelo do feed do caso. Aviso amarelo do que está em branco (só avisa). **Copiar FCA** usa `utils/copiar.js` (funciona no servidor em http). O rascunho fica guardado neste navegador até **Limpar tudo**.
- **Lupa** no canto de cima: janela simples de consulta de NS (modelo, fabricação, política de troca; copiar NS/modelo; "Usar no FCA").
- **Orientações** por modo: textos dos Procedimentos Internos do Gerador FCA (facilitado: antes de abrir, observações, o que dizer ao cliente) e o link da Wiki. As orientações por produto do AUTO FCA (pasta `orientacoes/`) não vieram no zip, por isso não estão aqui.
- Fora (não pedido): a Tabela de Transferência (iframe de 1,3 MB do Gerador FCA) e os menus de links dos sites antigos.

### Grupos dentro de uma aba (`GRUPOS_POR_TIPO` em `front/src/abas.js`)
Hoje só a aba **Baluns**: **Power balun** (com `WP` no nome, ex.: VB 1016 WP) e **Baluns comuns** (sem WP, ex.: VB 301 P). Botões no topo (Todos / cada grupo, com contagem) e faixas entre os grupos em "Todos"; ao escolher um grupo, as características que ninguém do grupo tem ficam escondidas.
Baluns e extensores têm tabelas próprias (características diferentes) e entram, saem e vão para phaseout pela planilha como qualquer equipamento.

### Recursos da tabela
- **Tutorial** (desde 28/10/2026; com exemplos desde 29/10/2026; `componets/Tutorial.jsx`, passos em `abrirTutorial` no `pages/Tabela.jsx`): botão azul cheio **Tutorial** ao lado do título (pulsa 3 vezes ao abrir a página). Só abre quando a pessoa clica: escurece a tela, destaca uma parte por vez com uma seta e explica (Anterior / Próximo / Sair do tutorial; setas do teclado e Esc). **Mostra funcionando**, com exemplos tirados da própria tabela na hora: aplica o filtro de um atalho "Precisa ter" (a inteligência perimetral, se pelo menos 3 produtos tiverem; senão outra inteligência ou outro atalho), abre o painel de Filtros e mostra a característica do exemplo por dentro, abre a janela Copiar / PDF / Excel com os produtos filtrados (logo depois dos filtros, desde 29/10/2026), marca os 3 primeiros produtos com ela e compara e monta uma **lista do cliente de exemplo** com os 5 primeiros. Como os produtos são escolhidos na hora, um produto que sai de linha não quebra o tutorial. Ao sair, **tudo volta como estava** (filtros, busca, marcados, comparação, atalhos) e a lista do cliente do analista não é tocada (a de exemplo nem é guardada no navegador). 14 passos nas Câmeras IP e NVDs; passos que não cabem na aba ficam de fora (no Phaseout são 6).
- **Inteligência perimetral (Linha e Cerca Virtual)**: assim nos atalhos "Precisa ter", no painel de Filtros e nas etiquetas "Filtrando" (`EXPLICACAO_NO_FILTRO` em `pages/Tabela.jsx`; desde 28/10/2026). Título da coluna, ficha e texto para o cliente continuam "Inteligência perimetral".
- **Ficha técnica no Phaseout** (desde 28/10/2026): a tabela continua só com nome, tipo, mês, substituto e métodos de recuperação; clicar no produto abre a ficha com esses dados e, embaixo, **todos os dados técnicos** de quando ele estava em linha (só os preenchidos, por categoria do tipo). Busca o cadastro pela rota pública `GET /api/phaseout_senhas/:tabela/:nome`. Sem dados: "Sem dados técnicos na tabela".
- **Filtros** (desde 15/10/2026; antes eram caixas de texto embaixo de cada título): botão **Filtros** (ou o funil ao lado do título da coluna) abre um painel lateral com todas as características por categoria; cada uma mostra as opções existentes como botões, com quantos equipamentos têm cada uma (as contagens já consideram os outros filtros). **Colunas no mesmo painel** (desde 22/10/2026; antes era o botão "Colunas", que confundia com o Filtros): o **olho** ao lado de cada característica mostra/esconde a coluna (escondida fica "Escondida" em cinza; filtrada continua aparecendo na faixa FILTRANDO); no topo do painel "N de M colunas na tabela" com **Mostrar todas** / **Esconder todas**. O botão Filtros mostra quantos filtros estão ativos e, com olho cortado, quantas colunas estão escondidas. Na aba Phaseout o painel só filtra (sem olho). Opções: **Possui** (qualquer "Sim"), os detalhes do Sim ("Humanos e veículos", "Linha e cerca virtual"), os outros valores (itens de listas separados: "PAL", "2,8 mm") e **Não** (também acha os "-"). Várias opções na mesma característica = qualquer uma delas; características diferentes = todas.
  - **"Precisa ter:"** acima da tabela: atalhos de um clique para as características Sim/Não (Microfone, PoE...) e para todas as de **inteligência** (vêm primeiro; nos gravadores valem os "Embarcado: 4 canais", "Recebe: 16 canais"), com contagem. "Possui" = qualquer valor que não seja "Não"/"-".
  - **Faixas nos filtros** (só nas opções de filtro; a célula da tabela continua com o valor completo; `FAIXAS` em `pages/Tabela.jsx`): resolução por tamanho ("2MP (1080p)" em vez de 1920×1080@25/@30...; 4.7MP vira 5MP, 2560×1440 vira 4MP), ângulo pelo horizontal (abaixo de 90°, 90° a 99°, 100° a 109°, 110° ou mais, varifocal), lente (fixas em mm, Varifocal, Zoom longo), IR e throughput por faixa, temperatura pela mínima, umidade pela máxima, protocolos pelo perfil ONVIF, inteligência dos gravadores (Embarcado / Recebe da câmera), entradas por número de canais, HD por TB/quantidade, G.711 junto.
  - **Ângulo** (linha de atalhos nas câmeras) e atalhos "Precisa ter" de Alarme, Zoom óptico, Zoom varifocal (câmeras) e Câmera com áudio (gravadores): lista `ATALHOS_TEM_OU_NAO`.
  - **Temperatura de operação** (desde 22/10/2026; câmeras, baluns e extensores; os gravadores não têm essa característica): botão no "Precisa ter", igual ao "Inteligência perimetral" (desde 22/10/2026 (5)): um clique mostra só os que têm a temperatura cadastrada, outro clique tira. Sem lista de faixas; não entra no título "Possuem ...:" do WhatsApp. O painel de Filtros continua com as faixas "Mínima de X°C".
  - **Resolução** (linha abaixo): câmeras pela resolução máxima ("4MP" = máxima de 4MP); gravadores (Entrada IP / Entrada HDCVI), baluns e extensores pelo que **suportam** ("8MP (4K)" = suporta 4K ou mais). 4K = 8MP, 1080p/Full HD = 2MP, 720p = 1MP, 1440p = 4MP.
  - **"Filtrando:"** mostra cada filtro ativo como etiqueta (clique tira) e "Limpar tudo". As características filtradas vão para logo depois do Nome, na faixa verde "FILTRANDO" (mesmo se estiverem escondidas pelo olho).
- **Pesquisa no endereço / Copiar link** (desde 21/10/2026): filtros, busca, grupo, colunas escondidas, ordenação, marcados, comparação (com "Só o que muda") e "Novos" ficam no endereço depois do `#` (ex.: `/cameras?modelo=VIP,VLP,VIPC,VIPW#microfone=__possui__&_novos=1`). O F5 não perde a pesquisa e o link abre igual em outro PC. Botão **Copiar link** ao lado da quantidade. Link colado na barra de endereço com a aba já aberta (só muda o `#`) aplica a pesquisa na hora (desde 23/10/2026; antes precisava de F5), e o "Voltar" do navegador volta para a pesquisa anterior. Código: `lerPesquisa`/`escreverPesquisa` em `pages/Tabela.jsx` (o `?modelo=` continua sendo só a aba).
- **"Atualizada em dd/mm/aaaa"** (desde 22/10/2026) ao lado da quantidade, em todas as abas: data da última aplicação da planilha de preços (passar o mouse mostra o arquivo e a hora). Vem de `GET /api/atualizacao` (lê a tabela `sincronizacoes`).
- **HDs homologados** e **Calculadora de HD** (desde 22/10/2026; `LINKS_EXTERNOS` em `abas.js`, `componets/BarraNavegacao.jsx`): na barra do topo, depois das abas, abrem as páginas da Intelbras em outra aba (links enviados pelo Gabriel). Ficam fora da rolagem das abas para nunca sumirem: em tela com 1700 px ou mais aparecem os dois; em tela menor, um botão **HDs** mostra os dois ao passar o mouse ou clicar. Para caber tudo em 1366 px, os espaços entre as abas diminuíram um pouco.
- **Selo "Novo"** e atalho **Lançamentos → Novos**: produtos que entraram na tabela nos últimos 30 dias. **Automático**: modelo novo da planilha (CSV) entra na Revisão e ganha o selo ao ser **liberado na tabela**; produto adicionado em linha pelo painel também. Vem do Histórico, só lendo; "desfazer" (restaurar removido) e volta do phaseout não contam; renomeado depois de entrar continua novo (desde 23/10/2026). **Manual** (desde 23/10/2026): na página Produtos do admin dá para **marcar como novo** (30 dias a partir de hoje), **tirar o selo** (vale até o produto entrar de novo na tabela) ou **voltar ao automático**; fica na tabela `selo_novo` (criada sozinha ao iniciar) e acompanha o nome se o produto for renomeado. Código: `novosDaTabela`/`marcarNovos` em `back/equipamentos.js` devolvem `novo_desde` e `novo_ate` em cada equipamento de `/api/<tabela>`. A ficha técnica mostra "novo na tabela desde dd/mm/aaaa".
- **Copiar / PDF / Excel** (botão no topo e na barra de comparar; `componets/EnviarCliente.jsx`): escolhe os produtos (os marcados ou todos da lista filtrada) e as características (abre com as dos filtros ativos; atalhos "Só as dos filtros", "Só o que muda", "Principais", "Todas", "Nenhuma" e "+ Adicionar característica"; o atalho escolhido fica verde); prévia da mensagem.
  - **+ Áudio** e **+ Inteligências** (desde 26/10/2026; borda tracejada): somam às características já escolhidas (não trocam as outras) só as de áudio/inteligência que **algum produto escolhido tem** (nada de "Mapa de calor: Não" em todos); clicar de novo tira. Somem quando nenhum produto tem (ex.: inteligências nas analógicas).
  - **Filtros dentro da janela** (desde 23/10/2026; antes, trocar a característica na janela não mudava os produtos e o pessoal achava que era filtro): em "Todos da lista" aparecem os filtros da tabela (clique tira), **+ Precisa ter…** e **Mais filtros** (abre o painel de Filtros por cima da janela; o Esc fecha só o painel). Mudou o filtro, a lista, a quantidade e a prévia mudam na hora; "Só as dos filtros" acompanha. A seção 2 avisa que ali só se escolhe o que aparece de cada produto.
  - **Comparação** (desde 23/10/2026): aberta da barra da comparação com **Só o que muda** marcado, já vem com **todas** as características diferentes (antes eram só as 6 primeiras) e o título "O que muda entre os N modelos:". Comparando, o que é diferente nunca vai para o título "Possuem ...:" (antes "Sim - Humanos" e "Sim - Humanos e veículos" viravam "Possuem detecção..." e a diferença sumia) e, se a versão curta fica igual (ex.: só a maior resolução), vai o texto inteiro. Critério do que muda (desde 23/10/2026 (2); o mesmo no amarelo da tela, `mudaEntre` em `valores.js`): o mesmo valor escrito de outro jeito não é diferença: maiúsculas, ordem dos itens ("Plástico e metal" = "Metal e plástico", protocolos em outra ordem), gênero/plural ("Branco" = "Branca") e item repetido; vazio (não informado), "-" e "Não" são iguais; vazio contra um valor ("IR: 30 m") continua sendo diferença. **Não informado = não tem** (desde 26/10/2026 (2), pedido do Gabriel): no WhatsApp, no PDF e no Excel o vazio sai como "Não" (antes "Não informado" no WhatsApp, "—" no PDF e célula vazia no Excel); o banco continua vazio e a tela da tabela continua com "—". Vale também para o PDF da Lista do cliente. Com "Só o que muda", lista longa (algum modelo com 5 itens ou mais; até 23/10/2026 (3) contava a soma dos modelos) com itens em comum mostra só a diferença: "Protocolos: tem também NAS" e, para quem não tem nada a mais, "Resolução de vídeo: não tem 1MP (1280×720)". Fica a lista inteira quando nenhum modelo tem 5 itens (ex.: Tecnologia de vídeo "HDCVI, AHD-H, HDTVI, Analógico (CVBS)"), quando a maior resolução já é diferente (vale a maior) e quando os itens diferentes têm rótulo ("H: 81°", "HDMI 1: ...").
  - **"Só o que muda" do Copiar = só o que pesa para o cliente** (desde 23/10/2026 (3); `IMPORTANTES_DO_TIPO` em `EnviarCliente.jsx`): das características que mudam, entram só estas (as outras ficam numa dica embaixo dos chips, "Também mudam, mas ficaram de fora...", e dá para pôr de volta em "+ Adicionar característica"). Se nenhuma delas muda (ex.: só a cor), vêm todas as que mudam. O amarelo e o "Só o que muda" da **tela** continuam com tudo.
    - Câmeras: formato, resolução, tecnologia de vídeo (HDCVI/AHD/HDTVI/CVBS), lente, ângulo, IR, full color, full color inteligente, starlight, zoom óptico e varifocal; inteligências (perimetral, detecção inteligente, facial, autotracking, estacionamento, contagem de pessoas, mapa de calor); PoE, Wi-Fi, fluxo de vídeo (conexões e Intelbras Cloud), protocolos; proteção (IP/IK), microfone, alarme, microSD.
    - Gravadores: entradas de vídeo (canais e modo NVR), entrada IP/HDCVI/AHD/HDTVI; inteligências (InSearch, busca inteligente, detecção inteligente, perimetral, face, reconhecimento facial, placa, comportamental, aglomeração, contagem de pessoas, mapa de calor); saídas de vídeo e resolução HDMI; portas PoE, entrada de rede, throughput, conexões simultâneas, funções e protocolos; câmera com áudio; quantidade e capacidade de HD.
    - Baluns: tipo, canais, função 4x1, resolução máxima, tecnologias, alcances (HDCVI, AHD, HDTVI, analógico), áudio, alimentação, proteção contra surtos.
    - Extensores: tipo, alcance CAT6 e CAT5e, resolução máxima, versão HDMI, controle IR.
    - Ficam de fora: cor, case/material, temperatura, umidade, dimensões, peso, formato NTSC/PAL, compressão, streams, bit rate, entrada analógica dos DVRs, saídas VGA/BNC, interfaces (USB, RS485, RS232, alarme do gravador, multibox), POS, adaptador Wi-Fi, bateria, consumo, conectores e métodos de recuperação.
  - **Baixar Excel** (desde 21/10/2026; `planilhaExcel.js`): `.xlsx` montado no próprio site, sem biblioteca: um produto por linha, cabeçalho verde com filtro do Excel, nome fixo ao rolar, link opcional. Todas as células como texto (o Excel não vira "-40°C a 60°C" em fórmula nem "1/3" em data).
  - **Copiar para o WhatsApp** (mais direto desde 22/10/2026, a pedido dos analistas): sem asteriscos. As características "tem ou não tem" (as mesmas dos atalhos "Precisa ter") que **todos** os produtos escolhidos possuem vão para o título, e embaixo vêm só os modelos:
    ```
    Possuem inteligência perimetral, microfone e alarme:

    VIP 3216 SD IR IA
    VIP 3225 SD IR IA G2
    ```
    Um produto só: "Possui ...:". Sem nenhuma em comum, o título é "Câmeras IP Intelbras:". As outras características escolhidas vão ao lado do modelo (`VIP 3250 AL IA - Formato: Bullet | Resolução de vídeo: 2MP (1920×1080) | Lente: 3,6 mm`); com mais de 3, uma por linha. Resoluções pela maior (`resolucao_video`: a maior; entradas dos gravadores: "até 8MP (4K)"). PDF e Excel continuam com todas. Opcional: link da página de cada produto. Funciona também pelo endereço da rede (http), onde o navegador não libera a área de transferência moderna.
  - **Gerar PDF**: abre a impressão do navegador ("Salvar como PDF") com cabeçalho e logo Intelbras verde; a margem da folha é feita na página (`@page` com margem 0), então o navegador não imprime endereço/data no topo e no rodapé; até 5 produtos lado a lado (comparativo), acima disso um produto por linha. Só usa os dados da tabela. A folha (cabeçalho, faixa e rodapé) é `paginaPdf` em `EnviarCliente.jsx`, usada também pela Lista do cliente.
- **Lista do cliente** (desde 22/10/2026; `componets/ListaCliente.jsx`): junta produtos de **várias abas** (ex.: 4 câmeras + 1 NVD + 4 baluns) para mandar ao cliente.
  - **Adicionar**: o **+** ao lado do nome do produto (vira um visto verde; clicar de novo tira), o botão **Adicionar à lista do cliente** na ficha técnica ou **Lista do cliente** na barra dos marcados (coloca todos os marcados).
  - **Abrir**: botão verde **Lista do cliente (N)** no canto de baixo à esquerda (só aparece quando a lista tem produtos; fica fora do topo para a tabela não perder espaço).
  - Na janela: produtos agrupados por aba (Câmeras analógicas, Câmeras IP, NVDs, DVRs, Baluns, Extensores) com **quantidade** (− / +), as principais características e a lixeira; **Nome do cliente** e **Observação** (opcionais); **Gerar PDF** (cabeçalho "Lista de equipamentos / Preparada para <cliente>", resumo "Câmeras IP: 5 · NVDs: 1 · Total: 10 equipamentos", uma tabela por grupo com Qtd, Modelo e características, e a observação) e **Copiar para o WhatsApp** (`4x VIP 1230 D FC+ AP` + características numa linha; dá para mandar só modelos e quantidades, e com link); **Limpar lista**.
  - Principais características (`RESUMO_DO_TIPO`, o padrão): câmeras = formato, resolução (a maior), lente, IR, proteção; gravadores = entradas, entrada IP e HDCVI (até a maior), quantidade e capacidade de HD, portas PoE; baluns = tipo, canais, resolução máxima; extensores = tipo, resolução máxima, alcance CAT6. O que o produto não tem ("Não"/vazio) fica de fora na tela e no WhatsApp; característica escondida no painel também.
  - **O que aparece de cada produto** (desde 26/10/2026, a pedido dos analistas): vale **só para a lista** (não mexe nos filtros nem nas colunas da tabela). Atalhos que põem ou tiram (verde = já estão): **Principais**, **Áudio** (`AUDIO_DO_TIPO` em `EnviarCliente.jsx`: microfone das câmeras, onde vem escrito o bidirecional; câmera com áudio, entrada, saída e áudio bidirecional dos gravadores; áudio dos baluns e extensores) e **Inteligências** (a categoria Inteligência de cada tipo). **Escolher características** abre, por tipo (Câmeras, Gravadores, Baluns, Extensores) e categoria, só as características que algum produto da lista tem; clique põe ou tira. **Voltar às principais** desfaz a escolha. A escolha fica guardada junto com a lista (`colunas`) e continua depois de "Limpar lista".
  - Com mais de 6 características, o WhatsApp põe uma por linha e o PDF troca as colunas por uma coluna **Características** (em duas colunas de texto, com o que cada produto tem). Até 6, o PDF continua em colunas, com "Não" em cinza para quem não tem e "—" para não informado.
  - Fica guardada **neste navegador** (`localStorage` "tabela-lista-cliente"): continua ao trocar de aba e no F5; cada analista tem a sua. Guarda uma cópia dos dados do produto na hora em que foi adicionado. Não aparece na aba Phaseout.
- **"Sim + detalhe"**: o detalhe começa com maiúscula na tela ("Sim" + "Humanos e veículos"); o banco não muda.
- **Busca geral**: procura o texto no modelo e em todas as características.
- **Comparar produtos**: caixinha ☐ ao lado do nome; os marcados ficam **fixos no topo** (faixa verde "Selecionados para comparar") mesmo pesquisando outros modelos; embaixo vem "Resultado da pesquisa". A barra no canto (Limpar / **Comparar**) mostra só os marcados, com o que é diferente entre eles em amarelo e a opção **Só o que muda** (esconde as características iguais). "Voltar para a lista" mantém as marcações. Desmarcou na comparação até sobrar 1: volta sozinha para a lista (desde 23/10/2026).
- **Modo escuro** (desde 23/10/2026; `componets/BotaoTema.jsx`): botão da lua no topo da tabela, do admin e da página inicial (vira sol para voltar). Desde 28/10/2026 a lua é roxa e o sol amarelo, preenchidos, com fundo da mesma cor bem leve (`BotaoTemaStyled` em `styles/Base.js`, cores `--lua` e `--sol`), para o pessoal achar. Fica guardado neste navegador (`localStorage` "tabela-tema"; cada analista escolhe o seu; sem escolha, claro) e muda na hora nas outras abas abertas. As cores ficam em `styles/GlobalStyled.js` (`:root` e `:root[data-tema='escuro']`): nada de cor fixa nos estilos, a não ser texto branco sobre verde. PDF e Excel continuam claros.
- **Ficha técnica**: clique em qualquer equipamento → todas as características organizadas por categoria + link da página do produto.
- **Versões do mesmo modelo em sequência** (bullet/dome e cores juntas), na ordem inicial e ao ordenar por Nome.
- **Leitura fácil** (`valorFormatado` em `Tabela.jsx`): "Sim" vira selo verde (com o detalhe ao lado), "-" aparece como "Não" discreto; **todo o resto vai em caixinhas** (`2,8 mm`, `Bullet`, `H: 88°`). Resoluções: as **3 maiores** + "+N" (o resto ao passar o mouse). Listas de frases ou com mais de 6 itens viram uma caixinha só com "·"; textos enormes (streams, protocolos) ficam em até 3 linhas (inteiros ao passar o mouse e na ficha). Caixinhas estreitas (~170 px, textos longos ~230 px) e títulos de coluna em até 3 linhas: as colunas ficam do tamanho do conteúdo. Na ficha técnica tudo aparece inteiro, uma linha por item.
- **Ordem das colunas**: câmeras — Nome, Formato, Resolução, Lente, Ângulo, IR, Full color e depois as categorias (Vídeo, Lente, Inteligência, Rede, Características mecânicas); gravadores — Entrada de vídeo (entradas, resoluções, streams), Saída de vídeo, Inteligência (InSearch e Busca inteligente primeiro), Rede (Portas PoE), Áudio, Interfaces, Geral; baluns — Conexões, Vídeo (resolução, tecnologias, alcances), Alimentação e proteção, Características mecânicas. Filtros de lista sugerem cada item separado (ex.: "PAL"). Resoluções de entrada dos gravadores mostram só a maior na tabela (+N).
- **Formato** (câmeras): Bullet, Dome, Speed dome, Mini speed dome, Fisheye, Bullet panorâmica, Cubo... — característica criada em 01/10/2026.

### Padrão de escrita dos dados técnicos
Itens separados por ` | `; decimal com vírgula (`2,8 mm`); graus com `°` (`H: 102° | V: 55° | D: 120°`, faixas `H: 109° a 33°`); resoluções `2MP (1920×1080) | 1.3MP (1280×960)`; temperatura `-40°C a 60°C`; umidade `Até 95% RH` ou `10% a 95% RH`; `Sim` / `Sim (detalhe)` / `-` (não possui); maiúscula só no começo (`Metal e plástico`, `Branca ou preta`).
- Ordenação clicando no título; mostrar/esconder colunas pelo olho no painel **Filtros**; coluna do nome fixa ao rolar.

## Área de admin

- **Painel**: alertas (modelos novos com "Preencher dados"/"Remover", phaseout, nomes ajustados, resumo) e a planilha (importar, analisar, corrigir, aplicar).
  - **Avisos de rotina** no alto (desde 22/10/2026; `back/rotina.js`, rota `GET /api/admin/rotina`): **Planilha de preços** ("Aplicada há 2 dias"; amarelo depois de 7 dias sem aplicar) e **Backup diário** ("Último: hoje, às 12:30 (3,4 MB) · 30 guardados"; amarelo se o último tem mais de 1 dia ou se não há nenhum em `back\dados\backups`, vermelho se o arquivo está vazio). Passar o mouse mostra o nome do arquivo. No PC de testes o backup aparece amarelo (a tarefa de backup só existe no servidor).
- **Phaseout** (`/editarPhaseout`): todos os descontinuados numa tabela editável — **nome, método de recuperação e data de phaseout** direto na linha (Enter ou ✓ salva; "Salvar N edições" salva todas). Filtros por tipo e por método de recuperação (com contagem, inclusive "(sem método)"), busca, e por linha: abrir o cadastro completo, **voltar para linha** e remover. **Em lote**: marque vários (ou "todos os visíveis") e aplique o mesmo método de recuperação ou a mesma data — fica um lote só no Histórico ("Alteração em lote" → Desfazer tudo). A data muda também o status "MM/AAAA".
- **Produtos** (`/produtos`, `pages/Produtos.jsx`; desde 15/10/2026 substitui as páginas Adicionar / Alterar / Remover): lista de **todos** os produtos à esquerda (busca, filtros por tipo e por status com contagem; fica presa ao rolar) e o cadastro à direita. Clicar abre para editar; **Salvar alterações** / **Descartar** na barra de baixo, **Remover** no topo, **Liberar na tabela** se estiver na Revisão; **Novo produto** abre o formulário em branco (escolher o tipo) e, depois de adicionar, o produto já fica aberto. Avisa antes de trocar de produto com alterações não salvas. Os endereços antigos (`/alterarDispositivo?tabela=&nome=&alerta=`, `/adicionarDispositivo`, `/removerDispositivo`) abrem esta página.
  - **Selo "Novo"** (desde 23/10/2026): filtro **Novos** na lista (com o selo "novo" ao lado do nome) e, no produto em linha aberto, a faixa do selo: "Aparece com o selo Novo até dd/mm (entrou na tabela em dd/mm)" com **Tirar o selo** / **Marcar como novo** / **Voltar ao automático**. Rotas `GET /api/admin/selo-novo/:tabela/:nome` e `PUT /api/admin/selo-novo`.
  - **Ler datasheet (PDF)** (desde 23/10/2026; `componets/LerDatasheet.jsx`, `datasheet.js`): botão no topo do produto, na faixa da Revisão e na página **Revisão** (abre o produto já com a janela). Escolhe (ou arrasta) o PDF; o texto é lido **no navegador** (biblioteca pdf.js, `pdfjs-dist` no `front`, baixada só quando a janela é usada; o servidor não muda). Monta a tabela de especificações do PDF (rótulo à esquerda, valor à direita, inclusive valor de várias linhas com o rótulo no meio e datasheet com 2 modelos lado a lado: escolhe a coluna do produto, dá para trocar) e converte para o padrão de escrita da tabela (`3.6mm` → `3,6 mm`, `Horizontal: 81°; Vertical: 44°` → `H: 81° | V: 44°`, `-40 °C ~ +60 °C / umidade ≤ 95%` → `-40°C a 60°C` e `Até 95% RH`, `H.265 / H.264` → `H.265 | H.264`, protocolos com ONVIF primeiro...). Palavras-chave também valem ("linha e cerca virtual" → Inteligência perimetral `Sim (linha e cerca virtual)`; "Full Color inteligente", "Starlight", "alerta sonoro/luminoso", "não possui PoE" → `-`). "N/A" numa característica de ter ou não ter vira `-`. Valor igual ao de outro equipamento mudando só maiúscula/acento/o-a fica com a grafia da tabela ("Plástico e Metal" → "Plástico e metal"); grafia parecida dos outros aparece como "Outros jeitos" (um clique). **Só entra o que está escrito no PDF**: cada valor mostra o trecho do PDF, começam marcados só os campos vazios, o que já tem valor mostra "Agora no cadastro", e a lista "Não estão no PDF" diz o que falta preencher à mão. **Preencher N campos** só põe no formulário (em amarelo): o admin confere e salva. As regras estão em `REGRAS` e `PALAVRAS_CHAVE` de `front/src/datasheet.js` (feitas com os 5 datasheets de câmera da pasta `datasheets`; gravadores, baluns e extensores usam as regras comuns e o "rótulo igual ao nome da característica"). Conferido com os 5 produtos já preenchidos à mão: 119 valores iguais aos do banco; as diferenças são escolhas de escrita da tabela ("pessoas" × "humanos" do PDF, ordem dos protocolos, "2 lentes de") e cor/formato, que os PDFs não trazem.
  - **Datasheet com mais de um modelo** (bullet e dome juntos; desde 27/10/2026): a janela mostra **Outros modelos deste datasheet**, cada um com o nome do PDF (dá para corrigir; é com ele que o modelo é procurado no cadastro, sem ligar para maiúsculas, espaços e hífens) e o que vai acontecer: **não cadastrado** → entra na **Revisão** com a coluna dele do PDF (não aparece na tabela até liberar); **na Revisão** → preenche só os campos vazios; **em linha / phaseout** → começa desmarcado e, se marcar, preenche só os campos vazios (o que já tem valor nunca muda). O botão vira "Preencher N campos e salvar VIP 1230 D G4": os campos do produto aberto continuam indo para o formulário (conferir e salvar), os outros modelos marcados são salvos na hora (aviso com Desfazer quando é um só; todos ficam no Histórico). Formato não é preenchido por esse caminho (o PDF de bullet + dome não diz qual é qual).
  - **Leitura mais precisa** (27/10/2026): rótulo no topo da célula (datasheets mais antigos, ex.: VIP 1230 B/D G4) ou no meio (os mais novos): vale o jeito que encaixa melhor no PDF inteiro; nome do modelo que quebra linha no cabeçalho ("VIP 1230 D" + "G4"); resolução com qualquer rótulo "Resolução..."/"Resoluções", a lista inteira mesmo quando parte dela fica colada na característica de cima ou de baixo, e escrita de vários jeitos (`1.3M(1280x960)/4:3`, `720p (1280x720)`, `1920*1080`, `2560 × 1440 (4MP)`, `WQHD`/`UXGA`/`SXGA` como no PDF; MP que não bate com o tamanho, como "3M (1280 × 960)", vale pelo tamanho); ângulo de lente varifocal (`H: 102,9° ~ 34,3º` → `H: 102,9° a 34,3°`) e partido em linhas; temperatura "- 40 à 60 °C"; "Tipo case/material" só vira Formato quando começa com bullet/dome ("Metal/Plástico" é material); valor de cada modelo na sua coluna mesmo quando o texto do bullet é comprido.
  - **Formulário**: barra presa no topo com **Procurar campo**, **Só os vazios**, "N de M campos preenchidos" e atalhos para cada seção; textos compridos ocupam a linha inteira; **"Preencher mais rápido"** (copiar de um modelo parecido) recolhível, aberto em produto novo; **sugestões** em cada campo e campos alterados em amarelo.

## Histórico e "Desfazer"

Toda mudança fica registrada na tabela `historico` com uma **cópia dos dados de antes e de depois**: adicionar, remover e alterar equipamentos (pelo painel ou pela planilha) e criar/alterar/esconder/excluir características.
- **Aviso com "Desfazer"**: ao remover, adicionar ou salvar no painel, o aviso de sucesso traz o botão Desfazer (fica 12 s na tela).
- **Painel → "Últimas alterações"**: as 6 mais recentes, com Desfazer.
- **Página "Histórico"** (`/historico`): tudo, com busca e filtros (equipamentos/características; painel/planilha/desfazer). Mostra o que mudou (antes → depois). As mudanças de uma aplicação da planilha ficam agrupadas, com **"Desfazer tudo"**.
- **Segurança**:
  - desfazer uma remoção restaura o equipamento **com todos os dados técnicos**;
  - o próprio desfazer também é registrado, então dá para voltar atrás dele;
  - se o equipamento foi alterado de novo depois, o sistema **recusa** e pede para desfazer primeiro a mais recente (não sobrescreve nada);
  - característica criada só é removida pelo desfazer se ainda estiver vazia.
- Código: `back/historico.js` (registrar, listar, desfazer, desfazerLote); `equipamentos.js`/`colunas.js` registram cada operação e devolvem o id do registro.

## Removidos

Página **Removidos** no painel (`/removidos`): todo equipamento removido pelo painel e que continua fora da tabela, com a data, quantos dados técnicos tinha, busca e filtro por tipo. Botão **Restaurar** devolve o equipamento com todos os dados (é o "desfazer" da remoção, registrado no Histórico). Não expira: dá para restaurar a qualquer momento.
- **Planilha × Removidos**: se a análise da planilha encontra um modelo novo que está em Removidos, ele **não é adicionado** e continua em Removidos. A análise mostra a lista "Na planilha, mas removidos por você — não adicionados" e, ao aplicar, cria um alerta (`removido_na_planilha`) com o link "Ver removidos". Se foi engano, é só restaurar.
- Só entram remoções feitas pelo painel a partir da versão com histórico (VHD 7503 MINI SD DUAL LENS foi removido antes: volta na próxima importação; removendo de novo ele fica em Removidos e deixa de voltar).
- Código: `historico.listarRemovidos()` (última remoção de cada equipamento, não desfeita, que não está na tabela); `sincronizador.js` (`removidosNaPlanilha`); rota `GET /api/admin/removidos`.

## Armazenamento

Tudo fica no **PostgreSQL** (em disco, serviço do Windows automático): equipamentos, características, alertas, histórico, removidos e o selo "Novo" escolhido pelo admin (`selo_novo`). Fechar o `INICIAR.bat`, reiniciar o PC ou o servidor **não perde nada**. Só a última planilha importada fica em arquivo (`back/dados/`).

## Características (filtros)

Página **Características** no painel do admin (`/caracteristicas`): escolha o tipo (câmera, gravador, balun, extensor) e veja todas as características agrupadas por categoria, com busca. Para cada uma:
- **Nome na tabela** (editável) e **categoria** (mover para outra ou criar uma nova) → botão **Salvar** (ou **Desfazer**);
- chave **"Na tabela"**: esconde/mostra a coluna na tabela, no painel de Filtros e na ficha técnica (salva na hora). Escondida continua editável no formulário do admin, marcada como "escondida na tabela";
- **Preenchida em**: em quantos equipamentos tem valor (ajuda a achar filtros vazios);
- **Valores** (desde 22/10/2026; `componets/ValoresCaracteristica.jsx`): janela com cada valor diferente da característica, quantos equipamentos usam (em linha, revisão e phaseout; "N em linha") e quais. **Trocar** um valor muda todos os equipamentos com aquele valor **exato** de uma vez (vazio = apagar). Grafias que só mudam em maiúscula, acento, espaço, ponto final ou º/° ficam marcadas em amarelo ("Parecido com: ...") e o filtro **Só grafias parecidas** junta as variações; na troca, **Usar:** preenche com a outra grafia. Tudo vai para o Histórico num lote "Padronização da escrita" (o aviso traz **Desfazer tudo**; também pelo Histórico). Exemplos encontrados no banco de testes: cor da case "Branco" (64) × "Branca" (363), métodos de recuperação "Senha padrão e ferramenta" (2) × "Senha padrão e Ferramenta" (25). Código: `colunas.valores` e `colunas.trocarValor` (usa `equipamentos.alterar` em cada um);
- **Excluir** (lixeira): qualquer característica (original ou criada pelo painel), menos nome/link/status. O sistema guarda no Histórico **todos os valores** que ela tinha: o **Desfazer** recria a coluna (mesmo tipo, nome e categoria) e devolve o valor de cada equipamento. Um formulário aberto antes da exclusão salva normalmente (o campo excluído é ignorado).
- **Sugestões de preenchimento** (Adicionar/Alterar): vêm do banco na hora — valores novos (ex.: "Sim em 8 canais" numa característica nova) viram sugestão nos outros equipamentos logo depois de salvar.
- **Nova característica**: cria a coluna no banco (texto) e ela aparece na hora como coluna + filtro + campo + ficha técnica. (Também disponível no formulário de Adicionar/Alterar.)

Tudo fica em `colunas_personalizadas` (`rotulo`, `categoria`, `oculta`, `personalizada`): as definições fixas de `front/src/filtro.js` são o padrão, e o painel sobrepõe nome/categoria/escondida de qualquer característica.

## API

Tudo em `/api` (mesmo endereço do site).

| Método | Rota | Login? | O que faz |
|---|---|---|---|
| POST | `/api/login` | — | `{usuario, senha}` → `{token}` |
| GET | `/api/cameras`, `/api/gravadores`, `/api/baluns`, `/api/extensores` (`?modelo=A,B`) | não | Equipamentos em linha (os que entraram nos últimos 30 dias vêm com `novo_desde`) |
| GET | `/api/phaseout_senhas` | não | Descontinuados (`tipo` e `tabela` de cada um) |
| GET | `/api/phaseout_senhas/:tabela/:nome` | não | Cadastro inteiro de um descontinuado (ficha técnica do Phaseout); 404 se estiver em linha ou na Revisão |
| POST | `/api/recuperacao/encaminhar` | não | Plano B da Recuperação de senha: `{ url, metodo, cabecalhos, corpo }` encaminhado à Intelbras (só os endereços da recuperação) |
| POST | `/api/admin/alterarVarios` | sim | Mesma alteração em vários: `{itens: [{tabela, nome}], campos}` → `{alterados, erros, lote}` |
| GET | `/api/colunas` | não | Características criadas pelo painel |
| POST | `/api/acessos` | não | Contador de acessos da Home: soma 1 e devolve `{ total }` |
| GET | `/api/atualizacao` | não | Última aplicação da planilha: `{ ultima: { em, planilha } }` (ou `null`) |
| GET | `/api/admin/rotina` | sim | Avisos de rotina: `{ planilha: { em, planilha }, backup: { quantidade, ultimo: { arquivo, em, tamanho } } }` |
| GET · POST | `/api/admin/colunas/:tabela/:coluna/valores` · `/api/admin/colunas/:tabela/:coluna/trocar-valor` | sim | Valores diferentes (`valor, total, em_linha, nomes`) · trocar um valor em todos: `{ de, para, rotulo }` → `{ alterados, erros, lote }` |
| GET | `/api/buscarEquipamentos?tabela=` · `/api/buscarEquipamento/:tabela/:nome` | sim | Nomes · um equipamento |
| POST · PUT · DELETE | `/api/adicionarCadastroEquipamento` · `/api/alterarCadastroEquipamento/:nomeAtual` · `/api/removerEquipamento` | sim | Cadastro |
| GET | `/api/admin/valores/:tabela` | sim | Sugestões de preenchimento |
| POST · PUT | `/api/admin/colunas` | sim | Criar característica · salvar nome/categoria/escondida (`{tabela, coluna, rotulo, categoria, oculta}`) |
| GET · DELETE | `/api/admin/colunas/:tabela/uso` · `/api/admin/colunas/:tabela/:coluna` | sim | Uso de cada característica · excluir qualquer uma (`?rotulo=`; valores guardados no histórico) |
| GET · POST | `/api/admin/alertas` · `/api/admin/alertas/:id/resolver` | sim | Alertas |
| POST | `/api/admin/planilha?nome=arquivo.csv` | sim | Corpo = arquivo; salva e devolve a análise |
| GET · POST | `/api/admin/sincronizacao` | sim | Status · `{aplicar, ignorarLimite}` |
| GET · POST | `/api/admin/historico` · `/api/admin/historico/:id/desfazer` · `/api/admin/historico/desfazer-lote` | sim | Histórico · desfazer um · desfazer uma aplicação da planilha |
| GET | `/api/admin/removidos` | sim | Removidos (restaurar = desfazer com o `id`) |
| GET · PUT | `/api/admin/selo-novo/:tabela/:nome` · `/api/admin/selo-novo` | sim | Selo "Novo" de um produto (`{ atual: { desde, ate, manual }, escolha }`) · `{ tabela, nome, acao }` com acao `marcar`, `tirar` ou `automatico` |

## Testes

Sem suíte automatizada.

**Leitor de datasheet** (desde 27/10/2026; `datasheets/teste-leitor/testar.mjs`): roda o `front/src/datasheet.js` nos PDFs da pasta `datasheets` e nos textos com posição de 11 datasheets de câmera (`textos-*.txt`: os PDFs de 01/10 não estão mais no PC, o texto ficou guardado nas conversas) e compara cada modelo com `banco.json` (o banco preenchido à mão pelos datasheets). Rodar depois de mexer nas regras e comparar o total com o de antes:
- `node datasheets/teste-leitor/testar.mjs` (só as diferenças) ou `node datasheets/teste-leitor/testar.mjs "1230" resolucao_video,lente` (só esses datasheets e colunas).
- Atualizar o `banco.json` (só leitura do banco): `psql -U postgres -d tabela -At -c "select json_agg(c) from cameras c" > datasheets/teste-leitor/banco.json`.
- Diferença que sobra não é sempre erro: o banco às vezes foi corrigido à mão ("2556x1440" no PDF do VIPW 1410 MINI, "2560×1440" no banco) ou escrito de outro jeito ("Branca e preta"). Os textos não têm a altura real das linhas, então rótulo no meio de célula comprida pode sair diferente do PDF de verdade.
- 27/10/2026: 300 valores iguais ao banco (eram 268); resolução certa em 16 de 24 modelos (eram 5).

**Com PostgreSQL 17 real** (29/09/2026): banco que simula o do trabalho (colunas varchar/boolean/date, dados técnicos) → `pg_dump` → `RESTAURAR_TABELA_ANTIGA` (restaurou; recusou rodar de novo com dados) → sistema real importou o CSV (249 modelos) e aplicou sem erros: nomes do banco antigo padronizados com dados mantidos (ângulo, case, IP do lab), dados copiados para modelo novo, phaseout, volta para linha; edição de campo booleano antigo; característica nova (`ALTER TABLE`); sugestões; reimportação = 0 mudanças; envio da planilha estável após ajuste do keep-alive (3/3).

Antes, com banco simulado em memória (Node v24):
- Servidor único na porta 3777: site, páginas (`/cameras`...) e API (`/api/...`).
- Importação do CSV real pelo endpoint do painel: 249 modelos, análise em ~0,25 s; nomes diferentes reconhecidos e padronizados; renomeação com dados mantidos; cópia de dados técnicos; kits (base removida → fica; todas as versões removidas → phaseout); FT; VIPW; reimportação sem mudanças.
- Pela tela: login → aplicar → alertas; busca geral; ficha técnica.
- `node --check` no back e `npm run build` no front sem erros nem avisos.
- **Não testado**: PostgreSQL real.

## Implantação no servidor do trabalho (rodando sozinha, porta 49152)

A tabela roda como **tarefa do Windows** "Tabela Comparativa": liga sozinha quando o PC liga (como SYSTEM, **sem ninguém logado e sem janela aberta**), e o vigia `servidor\servico.cmd` religa em 5 s se ela cair. Se o PostgreSQL subir depois dela no boot, ela espera e tenta de novo a cada 10 s.

**No PC de testes**
1. `PREPARAR_PACOTE_SERVIDOR.bat` → exporta o banco daqui para `servidor\banco\tabela.sql` (com tudo: dados técnicos, histórico, características) e monta `PACOTE_SERVIDOR\TabelaComparativa` (~70 MB, sem `front\node_modules`, datasheets e backups antigos).
2. Copiar a pasta `TabelaComparativa` para o servidor, de preferência em **`C:\TabelaComparativa`** (fora da Área de Trabalho/OneDrive).

**No servidor (10.1.45.193)**
1. Precisa ter **Node.js LTS** instalado (para todos os usuários) e o **PostgreSQL** (já existe lá, o da tabela antiga).
2. Conferir no `back\.env`: `DATABASE_URL=postgres://postgres:SENHA@localhost:5432/tabela` (usuário e senha do PostgreSQL de lá; o banco **`tabela`** é novo e separado do banco `postgres` da tabela antiga, que não é tocado).
3. Dois cliques em **`INSTALAR_NO_SERVIDOR.bat`** (aceitar o pedido de administrador). Ele: grava `PORTA=49152`; deixa o PostgreSQL em início automático e religando se cair; cria o banco `tabela` e importa o `tabela.sql` (**se o banco já existir, não sobrescreve**); libera a porta no Firewall; cria a tarefa de início automático e a de **backup diário (12:30, guarda 30 dias em `back\dados\backups`)**; desliga a suspensão do PC; liga a tabela e mostra os endereços.
4. Acessar de qualquer PC da rede: **http://10.1.45.193:49152**. Outra porta: `INSTALAR_NO_SERVIDOR.bat 8080`.

**Atualizar o sistema no servidor** (mudanças de código/visual feitas no PC de testes)
1. No PC de testes: **`PREPARAR_ATUALIZACAO.bat`** → monta `PACOTE_ATUALIZACAO\TabelaComparativa` (~3 MB: `back` sem `.env`/`dados`/`node_modules`, `front\build`, `servidor` e os `.bat`).
2. No servidor: copiar o **conteúdo** dessa pasta por cima de `C:\TabelaComparativa` (substituir) e rodar **`REINICIAR_TABELA.bat`**. O `.env`, os registros, os backups e o banco de lá não são tocados.
3. **Correções de dados** que acompanham a atualização ficam em `back/correcoes.js` e rodam **sozinhas uma vez** ao ligar (tabela `correcoes_aplicadas`); cada valor só é trocado se ainda estiver com o valor errado conhecido; tudo no Histórico (lote "Correção automática", com Desfazer tudo).

**Depois**
- `REINICIAR_TABELA.bat`: depois de atualizar arquivos ou mudar o `.env`.
- `BACKUP_AGORA.bat`: cópia do banco na hora.
- `DESINSTALAR_DO_SERVIDOR.bat`: para e tira do início automático (não apaga banco nem arquivos).
- Registro: `back\dados\logs\servidor.log` (passa de 5 MB → `servidor-anterior.log`).
- No servidor o `INICIAR.bat` só abre o navegador (não liga uma segunda cópia).
- **Atualizar a tabela depois**: copiar por cima só `back` (menos `back\.env` e `back\dados`) e `front\build`, e rodar `REINICIAR_TABELA.bat`. Os dados ficam no banco do servidor; não importar o `tabela.sql` de novo.
- A porta 49152 é a primeira da faixa "dinâmica" do Windows: se algum dia outro programa pegar essa porta, o vigia fica tentando e o registro mostra "Não foi possível usar a porta"; aí é só reinstalar com outra (ex.: `INSTALAR_NO_SERVIDOR.bat 8080`).
## Plano: PC de testes → servidor do trabalho (histórico)

1. **PC de testes (agora)** — PostgreSQL 17 instalado (serviço `postgresql-x64-17`, automático, usuário `postgres`, senha `admin`, banco **`tabela`**). Falta trazer a cópia das tabelas antigas, restaurar, ligar com `INICIAR.bat`, importar a planilha e validar.
2. **Servidor do trabalho (depois)** — copiar a pasta, ajustar só o `back/.env` (`DATABASE_URL` do banco de lá e `PORTA`), desligar a tabela antiga e usar o `INICIAR.bat`. Sem IP no código.

### Onde está o banco da tabela antiga
O back antigo conectava em `postgres://postgres:admin@localhost:5432/postgres`: o PostgreSQL roda **no próprio servidor do trabalho** (localhost), usuário `postgres`, senha `admin`, banco `postgres`. Instalação em `C:\Program Files\PostgreSQL\<versão>\` (dados em `...\<versão>\data` — **não copiar essa pasta**; usar o pg_dump abaixo).

### Trazer os dados técnicos (no servidor do trabalho)
1. Descobrir a versão: `dir "C:\Program Files\PostgreSQL"` (ex.: `16`).
2. Num Prompt de Comando (trocar 16 pela versão; a senha pedida é `admin`):
   ```bat
   "C:\Program Files\PostgreSQL\16\bin\pg_dump.exe" -U postgres -h localhost -d postgres -t cameras -t gravadores -f "%USERPROFILE%\Desktop\tabela_antiga.sql"
   ```
   Gera `tabela_antiga.sql` na Área de Trabalho. **Só lê**, não altera nada no servidor.
   (Alternativa com pgAdmin: botão direito nas tabelas `cameras`/`gravadores` → Backup → formato **Plain**.)
3. Trazer o arquivo para o PC e colocar na pasta principal da tabela.

### Restaurar no PC
Dois cliques em **`RESTAURAR_TABELA_ANTIGA.bat`** (ou arraste o `.sql` sobre ele). A ferramenta (`back/ferramentas/restaurarTabelaAntiga.js`):
- **recusa** se o banco daqui já tiver equipamentos (nunca sobrescreve);
- remove as tabelas vazias criadas pelo sistema e restaura as originais, com todas as colunas e dados;
- mostra quantos equipamentos vieram.

Depois: `INICIAR.bat` → Admin → Importar e analisar o CSV → conferir → Aplicar.

## Pendências

- **Preencher os equipamentos sem dados técnicos**: câmeras analógicas (30/09/2026), câmeras IP, gravadores, baluns e extensores (01/10/2026) concluídos.
- **VEX 3120 HDMI IP e IP RX**: o datasheet traz dimensões "97 x 24 x 94" e peso "145" sem a unidade (mm? g?) — gravado como está; completar se a Intelbras informar.
- MHDX 1216 (phaseout) tem "Funções e protocolos" cortado ("...Onvif, Co") desde a tabela antiga; completar se alguém tiver o datasheet.
- **Dados técnicos ficam no banco deste PC**: as correções pelos datasheets e a padronização estão no banco `tabela` daqui. Na implantação no servidor do trabalho, levar o banco (pg_dump/restore) em vez de começar do banco antigo de lá.
- **Métodos de recuperação do phaseout**: vieram da `tabela_antiga.sql` como estavam (grafias variadas, alguns errados). Corrigir pela página Phaseout do admin (filtro por método + edição em lote) ou por Características → Métodos de recuperação → **Valores** (troca uma grafia em todos de uma vez).
- `tabela_antiga.sql` (na raiz) é a cópia da tabela do trabalho em 30/09/2026 — serve de backup; pode ser guardado fora da pasta.
- O gatilho `verificar_phaseout` do banco antigo não foi recriado (a função não veio na cópia; o sistema controla o status). No servidor do trabalho ele ainda existe: **avaliar na implantação** se ele interfere nas gravações do sistema novo.
- Campo "Cor da case" tem padrão "Branco" no banco antigo: modelos novos não-BLACK entram como "Branco" — conferir ao preencher. No banco de testes há 64 câmeras com "Branco" (4 em linha) e 363 com "Branca": dá para padronizar em Características → Cor da case → **Valores** (não foi feito: decisão do Gabriel, conferindo com os datasheets).
- **Verificar links automaticamente** (item 8 da lista de 21/10/2026): não dá. O site da Intelbras usa proteção Cloudflare e responde 403 "Just a moment..." a qualquer acesso que não seja de um navegador de pessoa (testado em 22/10/2026: páginas de produto, página inexistente e sitemap, todas 403). A conferência dos links continua manual.
- **Na implantação no servidor do trabalho**: o banco de lá ainda tem "IP no LAB" e "Tem no LAB" — excluir as duas (câmera e gravador) pela página Características.
- **Coluna `descontinuado`** do banco: não é usada (a regra usa `phaseout`).
- **`front/node_modules`** (~530 MB) só serve para gerar o site (`npm run build`); dá para apagar e reinstalar com `npm install` quando precisar editar o site. Para rodar, basta `front/build`.
- Tabela `admin` do banco antigo não é mais usada.
- **Leitor de datasheet**: as regras foram feitas e conferidas com os 5 datasheets de **câmera** da pasta `datasheets` e, desde 27/10/2026, também com o texto de 11 datasheets antigos (7 com bullet e dome juntos; ver "Testes"). Formato (Bullet/Dome) não sai de datasheet com os dois modelos juntos: preencher à mão. Para gravadores, baluns e extensores ele usa as regras comuns (temperatura, umidade, proteção) e o rótulo igual ao nome da característica: na primeira vez com um datasheet desses, conferir o que ele achou e, se faltar muito, mandar o PDF para acrescentar os rótulos em `front/src/datasheet.js`. PDF escaneado (imagem, sem texto) não tem como ser lido.

## Histórico de alterações

### 2026-11-05 (3) — FCA: checklists fora do setor removidos
- **Pedido** (Gabriel): tirar do checklist do produto os itens que não são do setor (lista marcada no print).
- **Feito**: `fca/dados.js` sem Vídeo Porteiro Cabeado, Vídeo Porteiro Wifi Allo W3/W5, Allo Plus, Intelbras Allo, Fechaduras Digitais, Campainhas e TIS 5010, IVW 3000 (Hardware), IVW 3000 (App Izy Smart), Fechaduras (Hardware ou App) e Serviços (Mibo Cloud, Mibo+). `fca/texto.js`: rascunho guardado com um desses checklists volta a avisar "Checklist do produto" em branco.

### 2026-11-05 (2) — Recuperação numa página só com lupa, sem "Ontem", login mais seguro e QA geral
- **Pedidos** (Gabriel): explicar o "Salvar nas sugestões" da FCA; integrar melhor a Recuperação de senha ("3 abas ta meio escroto"), com uma lupa para a consulta de NS como na FCA; tirar o atalho "Ontem" das datas; melhorar ao máximo a segurança do login; QA geral antes de subir no servidor.
- **FCA**: o botão virou **Guardar para usar de novo** (com explicação ao passar o mouse); ver "FCA".
- **Recuperação de senha**: página só (ver "Recuperação de senha"). `pages/RecuperacaoSenha.jsx` (sem `PARTES`; `ConsultaNS` virou janela; "Gerar senhas deste equipamento" recomeça o gerador com o NS; NS de equipamento Jufeng no gerador avisa para usar a Jufeng; resposta atrasada de um NS antigo é ignorada; Enter no NS tenta de novo), `styles/RecuperacaoStyled.js` (`.botao-lupa` e cabeçalho vieram da FCA, `.jufeng .etapa`, `.duas-colunas` sem estourar no celular), `styles/FcaStyled.js` (sem a cópia da lupa). `componets/CampoData.jsx`: sem o Ontem.
- **Login**: ver "Login do admin". `back/index.js`, `back/middleware/authMiddleware.js`, `back/config.js`, `front/src/componets/Login.jsx`. Depois de atualizar o servidor, quem estava logado no admin entra de novo uma vez (o token antigo de 7 dias não vale mais).
- **Teste / QA** (cópia `tabela_teste`, porta 3778, acessada pelo IP em http, com usuário e senha de teste só do servidor de teste; apagados depois): rotas da API (públicas 200, admin sem login 401, tabela inválida 404), páginas, gzip e cache; lupa da Recuperação com respostas simuladas (gravador -> modelo no gerador e phaseout; Jufeng -> leva ao cartão; sem recuperação; NS inexistente; NS curto; Esc); celular sem rolagem lateral; tutorial com 9 passos; Câmeras IP (57 linhas, busca 1230 = 10, atalho PoE 45, filtros "poe"/"microf"/"deteccao" só pelo nome, comparar 2, Copiar); as outras 6 abas carregam (analógicas 32, NVDs 14, MHDX 10, baluns 9, extensores 4, phaseout 521); FCA; login: certo, errado (senha limpa, mensagem), 5 erros -> bloqueio de 15 min (até com a senha certa), outro IP entra, token antigo e token forjado recusados, cabeçalhos; admin: as 7 páginas abrem sem erro; alterar um balun e desfazer pelo histórico. Gerar senhas de verdade e a consulta real de NS não foram testadas (precisam da VPN; o código delas não mudou). **Banco e `correcoes.js` sem mudança.**

### 2026-11-05 — Copiar no servidor, filtros pelo nome, aba FCA e desempenho
- **Pedidos** (Gabriel): (1) alinhar "Data do equipamento" e "Ano do firmware" e os botões do passo a passo; copiar não funcionava no servidor (Recuperação de senha, QR code e NS), só no PC de testes; (2) a busca do painel de Filtros achava "Possui" ao procurar "POS": filtrar só pelo nome da característica e melhorar o painel; (3) aba **FCA** à direita da Recuperação de senha, juntando os dois sites da pasta `autofca/`, com uma lupa que abre a consulta de NS; (4) melhorar o desempenho sem mudar o funcionamento nem o visual.
- **Causa do copiar**: o servidor é `http://10.1.45.193:49152`, e em http o navegador desliga o `navigator.clipboard` (só existe em https e em `localhost`, por isso no PC de testes funcionava). A Recuperação de senha usava só ele; dava erro calado. **Corrigido** com `front/src/utils/copiar.js`: `copiarTexto` tenta o `navigator.clipboard` e, em http, copia pelo jeito antigo (`document.execCommand('copy')`); `EnviarCliente.jsx` passou a usar o mesmo. Testado acessando pelo IP da rede (http, sem `navigator.clipboard`): botões do passo a passo, Copiar para o WhatsApp e Copiar FCA copiaram. Se não copiar, o botão mostra "Não copiou".
- **QR code**: em http o navegador **não deixa** pôr imagem na área de transferência. `copiarImagem` copia o QR como figura (cola no Word, Outlook, Teams e e-mail; o WhatsApp Web não aceita) e há um botão **Baixar** (PNG). Para copiar a imagem igual ao PC de testes, o endereço precisa ser tratado como seguro: https no servidor, ou a política do Chrome/Edge `OverrideSecurityRestrictionsOnInsecureOrigin` com `http://10.1.45.193:49152` (TI), ou em cada PC `chrome://flags/#unsafely-treat-insecure-origin-as-secure` (Edge: `edge://flags/...`).
- **Alinhamento**: os atalhos Hoje/Ontem/01/01/2000 foram para baixo do campo de data (o campo fica na mesma altura do Ano do firmware); passo a passo com o título numa linha e os 3 botões do mesmo tamanho lado a lado.
- **Filtros** (`componets/PainelFiltros.jsx`): "Procurar" olha só o nome da característica, sem acento e pelo começo das palavras ("pos" -> só POS; "deteccao" -> Detecção...; "entrada ip" -> Entrada IP), numa lista só com o nome igual primeiro e a categoria ao lado; o campo já vem com o cursor ao abrir o painel; Esc com algo escrito limpa a busca (o segundo Esc fecha).
- **FCA**: ver "FCA" acima. Novos: `pages/Fca.jsx`, `fca/dados.js`, `fca/texto.js`, `styles/FcaStyled.js` (usa os estilos da Recuperação, em roxo); `abas.js` (aba), `Home.jsx` (ícone), `NavStyled.js` (`.destaque.roxo`), `Modal.jsx` (opção `largura`).
- **Desempenho**: (a) `App.jsx`: admin, Recuperação de senha e FCA carregam só quando abertos (`lazy`; arquivo principal 50 KB menor compactado); aba aberta antes de uma atualização recarrega sozinha se pedir um arquivo antigo; (b) `back/index.js`: JS/CSS do site vão compactados em gzip (zlib do Node, sem pacote novo; ~4x menores) e ficam guardados no navegador por 1 ano (o nome muda a cada versão); o `index.html` sempre confere, então depois de atualizar o servidor já vem a versão nova; arquivo de `/static` que não existe dá 404; (c) `pages/Tabela.jsx`: cada linha da tabela é um componente que só redesenha quando ela muda (`LinhaDaTabela` com `memo`), as classes das células são calculadas uma vez por coluna (antes a comparação calculava "o que muda" em cada célula) e a busca de modelo usa `useDeferredValue` (a caixa responde na hora); (d) `EnviarCliente.jsx`: fechada, não monta mais o texto de todos os produtos a cada clique na tela.
- **Teste** (cópia `tabela_teste`, porta 3778, acessada pelo IP em http; apagados depois): copiar (passo a passo, WhatsApp, FCA) e QR como figura; data e firmware alinhados (PC e celular); busca dos filtros (pos, deteccao, entrada ip, ip, Esc); tabela: marcar 2, comparar (10 células diferentes, "Só o que muda" 6 colunas), lista do cliente, ficha, busca 1230 e vipw1430 (phaseout), Copiar/PDF com o resultado; FCA nos 3 modos, Defense IA Lite, CEP 88104-800 pelo ViaCEP, sugestões salvar/tirar, rascunho depois do F5, Limpar tudo, lupa (NS inventado -> "não encontrado"; resultado com resposta simulada) e celular sem rolagem lateral. Achado e corrigido no teste: depois do Limpar tudo, o mesmo CEP digitado de novo não buscava o endereço. **Banco e `correcoes.js` sem mudança.**

### 2026-11-04 — Data da recuperação de senha e teste geral
- **Pedido** (Gabriel): a data da Recuperação de senha não aceitava 01/01 (o primeiro 01 virava 10); deixar a data mais fácil e no formato do Brasil; atalho para 01/01/2000 (data do gravador com problema na bateria); testar o site como QA e corrigir o que achar.
- **Causa do bug**: o campo era `input type="date"` com `onChange={e => setData(e.target.value || hoje())}`. Enquanto a data ficava incompleta na digitação, o valor vinha vazio, o campo voltava para hoje e os números se misturavam.
- **Feito**: `componets/CampoData.jsx` (máscara dd/mm/aaaa, calendário, atalhos Hoje/Ontem/01/01/2000, aviso "Essa data não existe"); `RecuperacaoSenha.jsx`: Gerar avisa data incompleta ou inexistente; modelo digitado inteiro ("mhdx 1304") já conta como escolhido e Enter escolhe o primeiro da lista; mudar NS, modelo, data ou firmware apaga as senhas da tela e descarta uma geração que ainda estava em andamento (antes as senhas da data antiga ficavam na tela e iam para a área de transferência); texto do tutorial. `styles/RecuperacaoStyled.js`: estilos do campo e, no celular, as 3 partes num bloco em vez de um oval.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): máscara digitando 01012026, 1/1/2026, 1/1/26, colando 2026-01-05; 31/02/2026 fica vermelha e não gera; senha local de 03/11/2026 (564344) e de 01/01/2000 (668648) conferidas com a conta; trocar a data durante a geração descartou o resultado; Consulta de NS (NS curto, letras com hífen), Jufeng sem chave, busca de modelo fora de linha nas Câmeras IP, Home e Phaseout no celular, API com tabela inexistente e aspas no filtro (404/lista vazia, sem erro 500). Geradores da Intelbras não respondem daqui (só pela VPN/servidor). **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-29 (3) — Contador de acessos, barra do topo sem cortar abas, mensagem e Jufeng
- **Pedidos** (Gabriel): (1) contador de acessos na Home, embaixo à esquerda, contando a cada carregamento (recarregar conta, trocar de aba não); (2) tirar da mensagem dos gravadores a frase da "senha mais forte" e só orientar a testar na ordem; (3) barra do topo cortando as últimas abas em tela menor; (4) deixar explícito na Jufeng que só os equipamentos da lista dele podem ser resetados.
- **Feito**: ver "Home e abas" e "Recuperação de senha". Arquivos: `pages/Home.jsx`, `styles/HomeStyled.js`, `api.js`, `index.js`, `styles/NavStyled.js`, `recuperacao/senhas.js`, `pages/RecuperacaoSenha.jsx` (lista Jufeng, "Mais forte" virou "1ª", textos do tutorial), `styles/RecuperacaoStyled.js`; back: `banco.js` (tabela `contador_acessos`, criada sozinha ao ligar) e `index.js` (`POST /api/acessos`).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): contador 3 → navegar para Câmeras analógicas e voltar pelo logo continuou 3 → recarregar foi para 4; barra com todas as abas visíveis em 1500, 1290, 946 e 375 px; aviso da Jufeng; mensagem do MHDX 1304 com o texto novo. **`correcoes.js` sem mudança.**

### 2026-10-29 (2) — Recuperação testada de verdade, tutorial da Recuperação, Copiar logo depois dos filtros
- **Pedidos** (Gabriel): tirar o botão "Facial interface antiga" e o "e faciais" do texto da Recuperação; verificar se a Consulta de NS, a Recuperação de senha e a Jufeng funcionam de verdade; tutorial da Recuperação de senha; no tutorial da tabela, o Copiar / PDF / Excel logo depois dos filtros.
- **Feito**: ver "Recursos da tabela > Recuperação de senha" e "> Tutorial". Arquivos: `pages/RecuperacaoSenha.jsx`, `recuperacao/intelbras.js` (espera de 12 s), `recuperacao/senhas.js` (gerador uma vez por consulta), `recuperacao/modelos.js` (sem `FACIAL_ANTIGO`), `styles/RecuperacaoStyled.js`, `styles/TabelasStyled.js` (`.botao-tutorial` fora do `.topo`, para servir às duas páginas), `pages/Tabela.jsx` (ordem dos passos).
- **Teste**: Intelbras de verdade (ver a seção); cópia `tabela_teste`, porta 3778, apagados depois: tutorial da Recuperação (10 passos, cada destaque na parte certa, volta para `?aba=senha` ao sair); tutorial das Câmeras IP (14 passos, o 7º é o Copiar com "Todos da lista 30" e o filtro de perimetral; Esc devolve tudo). **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-29 — Recuperação de senha funcionando e Tutorial com exemplos
- **Pedidos** (Gabriel): (1) integrar na aba Recuperação de senha a "Consulta de NS", a "Recuperação de senha" e a "Recuperação de senha Jufeng" dos 3 zips da pasta `REC senha`, do mesmo jeito, só que modernizado; (2) Tutorial com exemplos de filtro de verdade (inteligência perimetral nas IPs), pegando os primeiros produtos para não quebrar quando um sair de linha, mostrando por dentro o painel de Filtros e uma lista do cliente pronta; (3) botão Tutorial mais evidente.
- **Recuperação de senha**: detalhes em "Recursos da tabela > Recuperação de senha". Arquivos: `pages/RecuperacaoSenha.jsx`, `recuperacao/modelos.js`, `recuperacao/senhas.js`, `recuperacao/intelbras.js`, `styles/RecuperacaoStyled.js`, `styles/GlobalStyled.js` (`--fundo-qr`); back: rota `POST /api/recuperacao/encaminhar` (`index.js`).
- **Tutorial**: detalhes em "Recursos da tabela > Tutorial". O fundo escuro passou a ser 4 faixas em volta da parte destacada (a sombra gigante falhava em partes grandes, como o painel de Filtros).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): Recuperação com a Intelbras simulada (ver a seção); Tutorial nas Câmeras IP (14 passos: perimetral com 30 de 57, VIP 3216 SD IR IA / VIP 3225 SD IR IA G2 / VIP 3230 FC+ AP IA comparados, lista de exemplo com 5), NVDs (14 passos: perimetral com 10 de 14) e Phaseout (6); ao sair, uma lista do cliente "Meu cliente" guardada antes voltou igual, sem filtros nem marcados; Esc no meio também devolve tudo. Sem erros no console.

### 2026-10-28 — Ficha técnica no Phaseout, VEX 3004 Multi-viewer, aba Recuperação de senha, Tutorial
- **Pedidos** (Gabriel): (1) clicar num produto do Phaseout e ver os dados técnicos, mantendo o resto como está; (2) "VEX 3004 Multi-viewer por que não está aparecendo em phaseout?"; (3) tirar as abas "Todas as câmeras" e "Todos os gravadores" e criar a aba **Recuperação de senha** (DVRs e NVDs) em branco, sem ligação com o admin; (4) Phaseout com um tom vermelho e Recuperação de senha com azul na barra do topo, translúcidos; (5) "Inteligência perimetral (Linha e Cerca Virtual)" nos atalhos e filtros; (6) botão do modo escuro mais visível (lua e sol coloridos); (7) Tutorial guiado, só quando a pessoa clicar.
- **VEX 3004 Multi-viewer** (causa): na planilha ele é "VEX 3004 HDMI MULTI-VIEWER" (4780039, encerrado em 09/2025). A leitura cortava o "MULTI-VIEWER", sobrava "VEX 3004 HDMI", e o `NOMES_DO_DATASHEET` de 01/10 trocava por "VEX 3004 SWITCH" (4780044, encerrado em 05/2024): os dois viravam um só, e o SWITCH ficou com a data do Multi-viewer. Agora vira **VEX 3004 MULTI-VIEWER**. Análise da planilha numa cópia: só 2 mudanças (Multi-viewer entra no phaseout em 09/2025; SWITCH volta para 05/2024 com "Indicação: VEX 3004", como está na planilha). O Multi-viewer entra sem dados técnicos (não temos o datasheet dele).
- **Correção automática** `2026-10-28-vex-3004-multi-viewer` (`back/correcoes.js`): ao ligar, com a planilha já importada no servidor, adiciona os encerrados que faltam no phaseout (o Multi-viewer) e atualiza mês/substituto só do VEX 3004 SWITCH (tipo novo `phaseoutPelosEncerramentos`, função `atualizarPhaseoutPelosEncerramentos` do sincronizador). Testado numa cópia: "2 trocados", Multi-viewer 09/2025 e SWITCH 05/2024. A próxima importação da planilha também faria isso.
- **Site**: `pages/Tabela.jsx` (ficha do Phaseout, Tutorial, rótulo da inteligência perimetral), `componets/Tutorial.jsx` e `styles/TutorialStyled.js` (novos), `pages/RecuperacaoSenha.jsx` (novo), `App.jsx`, `abas.js`, `pages/Home.jsx`, `componets/BarraNavegacao.jsx`, `styles/NavStyled.js`, `componets/BotaoTema.jsx`, `styles/Base.js`, `styles/GlobalStyled.js` (`--lua`, `--sol`, `--tutorial-fundo` nos dois temas), `styles/TabelasStyled.js`. **Back**: rota `GET /api/phaseout_senhas/:tabela/:nome` (`index.js`), `sincronizacao/regras.js`, `sincronizacao/sincronizador.js`, `correcoes.js`.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): ficha do VEX 3004 SWITCH no Phaseout com Phaseout + Conexões, Vídeo, Alimentação e Características mecânicas; produto em linha na rota nova = 404; abrir/trocar/fechar fichas sem erro no console; barra do topo em 1366 px cabendo com Phaseout vermelho e Recuperação de senha azul; página em branco e Home no escuro; Tutorial com os 10 passos nas Câmeras IP e 6 no Phaseout, no claro e no escuro.

### 2026-10-27 — Ler datasheet: resolução certa e o dome junto com o bullet
- **Pedido** (Gabriel): ao importar o PDF a resolução não vinha certa e, com bullet e dome no mesmo datasheet, só o bullet (o produto aberto) era preenchido; o dome não era criado.
- **Causa**: (1) nos datasheets em que o rótulo fica na primeira linha da célula, as linhas seguintes da resolução iam para a característica de baixo ("Foto"), e sobrava só a primeira; (2) rótulos "Resoluções" e "Resolução de imagem/ Proporção de tela" não eram reconhecidos; (3) o nome que quebra linha no cabeçalho ficava cortado ("VIP 1230 D" sem o "G4"); (4) a janela só preenchia o produto aberto.
- **Site** (`front/src/datasheet.js`, `componets/LerDatasheet.jsx`, `pages/Produtos.jsx`, `styles/AlterarAcidionarStyled.js`): detalhes em "Área de admin > Produtos" (Datasheet com mais de um modelo, Leitura mais precisa). O servidor não muda (os outros modelos são salvos pelas rotas que já existiam).
- **Teste do leitor** (`datasheets/teste-leitor`, ver "Testes"): 300 valores iguais ao banco (eram 268), resolução certa em 16 de 24 modelos (eram 5); os 5 PDFs da pasta continuam iguais ao que saía antes.
- **Teste na tela** (cópia `tabela_teste` sem o VIP 1230 D SC, porta 3778, apagados depois): VIP 1230 SC → Ler datasheet → "VIP 1230 D SC: não está cadastrado, entra na Revisão com 18 campos" → salvar → VIP 1230 D SC na Revisão com a coluna do dome (lente 2,8 mm, H: 101°, igual ao cadastrado à mão no banco real). Ao contrário (dome aberto): coluna "VIP 1230 D SC" escolhida sozinha, o bullet em linha desmarcado com "preenche 2 campos que estão vazios" → marcar → só os 2 vazios preenchidos (3,6 mm e IP67), aviso com Desfazer. Console sem erros. **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-26 (2) — "Não informado" sai como "Não" para o cliente
- **Pedido** (Gabriel): VIP 1230 SC × VIP 1300 MINI SD com "Só o que muda" e Copiar saía "IR: Não informado", "Autotracking: Não informado", "Alarme: Não informado", "MicroSD: Não informado"; quando não está informado, é porque não tem.
- **Site** (`componets/EnviarCliente.jsx` texto, `celulaPdf` e Excel; `componets/ListaCliente.jsx` PDF): o vazio vira "Não" (cinza no PDF). Só o texto para o cliente: banco, tela e o critério do que muda continuam iguais. Nenhum produto em linha tem "Não informado" gravado como texto (conferido no banco, só lendo).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): o mesmo par: WhatsApp com "IR: Não", "Autotracking: Não", "Alarme: Não", "MicroSD: Não" e nenhum "Não informado"; PDF lado a lado com "Não" nessas linhas. **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-26 — Lista do cliente com áudio, inteligências e escolha do que aparece
- **Pedido** (Gabriel, a pedido dos analistas): na Lista do cliente, mostrar o áudio (microfone, áudio bidirecional) e as inteligências; atalhos para as informações mais pedidas e um botão de filtro dentro da lista para escolher o que aparece, sem mexer na tabela; levar a melhoria para o resto da tabela.
- **Site** (`componets/ListaCliente.jsx`, `componets/EnviarCliente.jsx`, `pages/Tabela.jsx` passa `inteligencia` ao Copiar, `styles/TabelasStyled.js`): "O que aparece de cada produto" na Lista do cliente e "+ Áudio"/"+ Inteligências" no Copiar / PDF / Excel (detalhes em "Recursos da tabela"). A lista antiga guardada no navegador continua igual (sem escolha = principais).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): lista com 2 câmeras IP, 1 analógica, NVD, DVR, balun e extensor: padrão igual ao de antes; Áudio e Inteligências nos 4 tipos (a analógica sem microfone nem IA continua só com as principais); Escolher características (tirar Formato) e Voltar às principais; WhatsApp (até 6 na linha, acima uma por linha) e PDF (colunas nas analógicas, baluns e extensores; coluna "Características" nas IP, NVD e DVR); Limpar lista mantém a escolha; F5 mantém; modo escuro; Copiar com + Inteligências = só perimetral, detecção inteligente e facial (as que os dois produtos têm) e "Todos da lista" com os atalhos. Console sem erros. **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-23 (3) — Copiar da comparação só com o que importa para o cliente
- **Pedido** (Gabriel): no Copiar do comparativo, trazer só o que vale para o cliente final e o técnico (resoluções, inteligências, método de operação, protocolos, conexões via cloud), sem tudo o que muda.
- **Site** (`componets/EnviarCliente.jsx`, `pages/Tabela.jsx` passa `tipo`): lista `IMPORTANTES_DO_TIPO` e regras em "Copiar / PDF / Excel > Comparação". Também: (a) iNVD 3008-P/3016/3016-P/3032 saíam "Entrada IP: até Até 16MP" (o datasheet já diz "Até 16MP"), agora "até 16MP" (vale também para a Lista do cliente); (b) listas curtas não viram mais "tem também AHD-H e HDTVI" (só quando algum modelo tem 5 itens ou mais).
- **Resultado**: VIP 3230 SC IA × VIP 5440 FC+ IA de 16 para 11 características (saíram formato de vídeo, streams, throughput, case e métodos de recuperação); iNVD 3016 × iNVD 5232 de 18 para 10; iMHDX 3108 × MHDX 1216-C DUAL AUDIO de 31 para 15; VB 1008 WP × VB 501 P G2 de 20 para 10; 3 extensores de 20 para 6.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): câmeras IP, analógicas (3 modelos, tecnologia com a lista inteira), NVDs, DVRs, baluns, extensores e o caso só com cor (VHD 1220 D FC+ × FC+ BLACK: vem a cor). Console sem erros. **Back, banco e `correcoes.js` sem mudança.**

### 2026-10-23 (2) — "O que muda" mais certo (tela e Copiar)
- **Pedido** (Gabriel): VIP 1230 SC × VIP 1230 FC+ com "Só o que muda" e Copiar saía "tudo errado": "Não informado" × "Não" em 12 características, "Plástico e metal" × "Metal e plástico", "Branco" × "Branca" e as listas de protocolos e resoluções inteiras.
- **Causa**: a comparação era letra por letra e vazio (o datasheet do SC não fala de starlight, Wi-Fi, alarme...) contava diferente de "-".
- **Site** (`valores.js` `mudaEntre`/`itensParaComparar`, `pages/Tabela.jsx`, `componets/EnviarCliente.jsx` `diferencaDasListas`): critério novo descrito em "Copiar / PDF / Excel > Comparação". O amarelo e o "Só o que muda" da tela usam o mesmo critério.
- **Resultado** (SC × FC+): de 22 para 9 características, com "Resolução de vídeo: tem também 1.3MP (1280×960) e 1MP (1280×720)" × "não tem ...", "Protocolos: tem também Registro Automático, QoS, NFS, P2P e 802.1x" × "tem também NAS". IR, Full color inteligente e Métodos de recuperação ficam como "Não informado" no SC (o datasheet dele não tem esses dados).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): todos os pares de câmeras (458), gravadores (159), baluns e extensores: tudo o que deixou de contar como diferença é o mesmo valor (cor Branco/Branca, ordem de compressão, áudio e protocolos, "IK10 e IP66" = "IP66 e IK10", resolução com item repetido); nenhuma diferença real sumiu. Na tela: 4 comparações (2 e 3 câmeras) com as colunas da tela iguais às do Copiar, console sem erros.

### 2026-10-23 — Selo "Novo" no admin, Copiar corrigido, modo escuro, leitor de datasheet e bateria de testes
- **Pedido** (Gabriel): (1) como funciona o selo "Novo" e poder marcar/tirar no admin, continuando automático para o que vem da planilha; (2) no Copiar, mudar o filtro dentro da janela não atualizava; (3) comparando com "Só o que muda", o Copiar ficava genérico; (4) modo escuro; (5) testar tudo para achar bugs do mesmo tipo; (6) ler o PDF do datasheet na Revisão e preencher sozinho o que achar (palavras-chave como "linha e cerca virtual"), usando os datasheets da pasta `datasheets`.
- **Selo "Novo"** (`back/equipamentos.js`, `back/banco.js`, `back/index.js`, `pages/Produtos.jsx`): detalhes em "Recursos da tabela" e "Área de admin". **Banco**: tabela nova `selo_novo`, criada sozinha ao iniciar (nada muda nas tabelas que já existem). `correcoes.js` sem nada novo.
- **Copiar** (`componets/EnviarCliente.jsx`, `pages/Tabela.jsx`, `componets/PainelFiltros.jsx`, `componets/Modal.jsx`): causa do (2): a janela não tinha filtros, e trocar a característica não mudava os produtos (a lista seguia o filtro da tabela). Causa do (3): abria com as 6 primeiras colunas e as diferenças de detalhe ("Sim - Humanos" × "Sim - Humanos e veículos") iam para o título "Possuem ...:".
- **Modo escuro** (`componets/BotaoTema.jsx`, `styles/*`, `index.js`): cores fixas dos estilos viraram variáveis; botão vermelho "Remover" com o vermelho de sempre nos dois modos; "Não" e "—" nas células amarelas da comparação mais fortes.
- **Bugs achados nos testes**: (a) link colado com a aba aberta (só o `#` muda) não aplicava a pesquisa; (b) desmarcando na comparação até sobrar 1, ficava "Comparando 1 equipamentos"; (c) na comparação, "-" e "Não" contavam como diferentes (os dois aparecem "Não"); (d) produto renomeado perdia o selo "Novo"; (e) README com duas linhas coladas ("Filtrando" e "Pesquisa no endereço").
- **Leitor de datasheet** (`front/src/datasheet.js`, `componets/LerDatasheet.jsx`, `pages/Revisao.jsx`, `pages/Produtos.jsx`; `pdfjs-dist` 3.11.174 no `front/package.json`): detalhes em "Área de admin". O servidor não muda (o PDF é lido no navegador).
- **Teste** (cópia `tabela_teste`, servidor na porta 3778 com chave de login só dele, apagados depois):
  - **Filtros**: 1.344 opções do painel clicadas uma a uma em todas as abas (Câmeras IP 177, analógicas 73, NVDs 168, DVRs 180, Baluns 89, Extensores 80, Phaseout 79, Todas as câmeras 202, Todos os gravadores 296): a quantidade de cada opção sempre igual ao resultado. Atalhos (Precisa ter, Resolução, Ângulo, Novos) nas Câmeras IP e NVDs: 55, todos certos.
  - **Copiar**: Microfone na tabela → janela → "+ Precisa ter: Inteligência perimetral" → 30 produtos e "Possuem inteligência perimetral e microfone:"; tirar Microfone → "Possuem inteligência perimetral:" e o endereço da tabela junto; "Mais filtros" por cima da janela, 4MP → 12 produtos na prévia; Esc fecha só o painel.
  - **Comparação**: VIP 3230 SC IA × VIP 5440 FC+ IA com Só o que muda: 17 de 17 características (antes 6), "Microfone: Sim" × "Sim, Entrada: 1, Saída: 1". 10 comparações aleatórias de 2, 3 e 4 câmeras: as características do Copiar iguais às colunas da tela e cada uma aparece em todos os produtos. Desmarcar até 1 volta para a lista.
  - **Endereço**: F5 com filtros, ordem, colunas escondidas e Novos volta igual; `#` trocado na barra aplica na hora; "Voltar" do navegador volta a pesquisa.
  - **Selo Novo**: API (marcar, tirar, voltar ao automático, sem login = 401, produto inexistente = 404, ação inválida = 400); renomear e desfazer: o selo acompanha (manual e automático); pela tela: Voltar ao automático, filtro "Novos 7", aviso.
  - **Modo escuro**: verificador de contraste (texto × fundo) em todas as páginas da tabela, janelas (ficha, Copiar, Lista do cliente, painel de Filtros, Valores), admin (Painel, Revisão, Produtos, Phaseout, Removidos, Características, Histórico), página inicial e login; modo claro com as mesmas cores de antes; topo cabe em 1366 px; F5 mantém; clique real no botão.
  - **Datasheet**: os 5 PDFs da pasta lidos e comparados com o que está no banco (119 iguais). Na tela: produto de teste na Revisão sem dados → "Ler datasheet (PDF)" na Revisão → coluna "VIP 1230 D SC" escolhida sozinha → 18 campos → salvar → 18 de 20 iguais ao VIP 1230 D SC cadastrado à mão ("humanos e veículos" como está no PDF; formato não está no PDF).

### 2026-10-22 (6) — Filtros e Colunas num botão só
- **Pedido** (Gabriel): o pessoal confundia os botões Filtros e Colunas (os dois listavam as características); juntar num botão de filtros, mais fácil e prático.
- **Site** (`componets/PainelFiltros.jsx`, `pages/Tabela.jsx`, `styles/TabelasStyled.js`; comentários em `filtro.js`): saiu o botão **Colunas** e o modal "Colunas visíveis" (e o `SeletorColunas`); o painel Filtros ganhou o olho por característica, "N de M colunas na tabela", Mostrar todas / Esconder todas, e mostra também as características sem opção para filtrar (para dar para escondê-las). Funil do título: "Filtrar ou esconder esta coluna". Links antigos com `_ocultas=` continuam funcionando. Nada tirado: todas as características continuam no painel e na tabela.
- **Back, banco e `correcoes.js` sem mudança.**
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): câmeras IP esconder "Tecnologia de vídeo" (sai da tabela, `#_ocultas=`, botão com 1 escondida, "35 de 36"), Esconder todas + Microfone "Possui" (tabela com Nome + Microfone na faixa FILTRANDO, olho "aparece enquanto estiver filtrando"), F5 mantém, funil do título abre a característica com o olho, Mostrar todas (36 de 36); painel com todas as colunas da tabela nas analógicas (19), NVDs (43), DVRs (50) e Baluns (24, também no grupo Power balun); Phaseout sem olho; link antigo `_ocultas=lente,ir` = 2 escondidas. Topo cabe numa linha em 1366 px. Sem erros no console nem no servidor.

### 2026-10-22 (5) — Temperatura de operação igual à Inteligência perimetral
- **Pedido** (Gabriel): sem lista de valores; funcionar como o atalho "Inteligência perimetral": um clique filtra, sem diferenciar faixa por faixa.
- **Site** (`pages/Tabela.jsx`, `styles/TabelasStyled.js`): saiu a lista do (4); "Temperatura de operação" agora é um botão do "Precisa ter" (um clique = só os que têm a temperatura cadastrada, de novo = tira). Não entra no título "Possuem ...:" do WhatsApp.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): câmeras IP "Temperatura de operação 57", clique = 57 de 57 com "Temperatura de operação: Possui" em "Filtrando", de novo = sem filtro; baluns com o botão (7).

### 2026-10-22 (4) — Temperatura de operação num botão só
- **Pedido** (Gabriel): em vez da linha com todas as faixas, um botão só chamado "Temperatura de operação"; o analista clica e filtra.
- **Site** (`pages/Tabela.jsx`, `styles/TabelasStyled.js`): a linha de chips virou um botão (lista do navegador) "Temperatura de operação"; ao clicar abre os valores da aba com a quantidade ("-40°C a 60°C (33)"), escolher um filtra (o botão fica verde com a faixa escolhida) e escolher "Temperatura de operação" de novo tira o filtro.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): câmeras IP com 9 valores, "-30°C a 55°C" = 6 de 57 com a etiqueta em "Filtrando", voltar = 57; analógicas com 2 valores. Sem erros no console.

### 2026-10-22 (3) — Temperatura nos atalhos mais simples
- **Pedido** (Gabriel): a linha "frio até / calor até" era complicada; mostrar só "Temperatura de operação" com todos os valores.
- **Site** (`pages/Tabela.jsx`): a linha agora mostra cada valor da aba ("-40°C a 60°C 33", "-30°C a 55°C 6"...), clique = só os daquela faixa. Saiu a lógica de frio/calor (`__tmin__`/`__tmax__`).
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): câmeras IP com 9 faixas, "-30°C a 55°C" = 6 de 57 com a etiqueta em "Filtrando"; analógicas (2 faixas) e baluns (3). Sem erros no console.

### 2026-10-22 (2) — Lista do cliente, WhatsApp mais direto e temperatura nos atalhos
- **Pedido** (Gabriel): item 3 das ideias (lista com produtos de várias abas para o cliente, "interessante para o cliente e fácil para os analistas"); WhatsApp sem asteriscos e sem repetir "Sim" em todos os modelos ("Possuem inteligência perimetral, microfone e saída de alarme:" e embaixo os modelos); temperatura de operação nos atalhos.
- **Site** (`componets/ListaCliente.jsx` novo, `componets/EnviarCliente.jsx`, `pages/Tabela.jsx`, `abas.js` (`abaDoProduto`), `valores.js` (`possui`), `styles/TabelasStyled.js`): detalhes em "Recursos da tabela". `EnviarCliente` recebe `colunasDePossui` (as colunas dos atalhos "Precisa ter").
- **Só código do site**: back, banco e `correcoes.js` sem mudança. A lista fica no navegador de cada analista.
- **Teste** (cópia `tabela_teste`, servidor na porta 3778, apagados depois): WhatsApp com 1 filtro ("Possuem inteligência perimetral:" + 3 modelos), 3 filtros, com "Principais" (formato/resolução/lente ao lado), nos NVDs ("Possuem inteligência perimetral e detecção de face:") e com um produto ("Possui"); temperatura nas câmeras IP (frio até -20/-30/-40, calor até 50 a 70; -30°C = 51 de 57, com 60°C = 39, coluna conferida), extensores (calor até 60°C) e analógicas, painel de Filtros e etiquetas; lista: + na linha, pela ficha, pelos marcados, troca de aba e F5 mantêm, quantidades, cliente, observação, texto do WhatsApp e PDF conferidos, tirar, limpar (o botão some), sem + nem botão no Phaseout; PDF antigo do "Copiar / PDF / Excel" igual. Topo da tabela continua numa linha em 1366 px. Sem erros no console nem no servidor.

### 2026-10-22 — HDs homologados e calculadora no topo, "Atualizada em", avisos de rotina e padronizar valores
- **Pedido** (Gabriel): itens 4, 5, 7 e 8 da lista de melhorias (data de atualização na tabela, padronizar valores de uma característica, avisos de rotina no painel, verificar links) e, no topo da tabela, botões para as páginas "HDs homologados" e "Calculadora de HD" da Intelbras.
- **Tabela** (`componets/BarraNavegacao.jsx`, `abas.js`, `styles/NavStyled.js`, `pages/Tabela.jsx`, `styles/TabelasStyled.js`): links de HD na barra do topo e "Atualizada em" ao lado da quantidade (detalhes em "Recursos da tabela").
- **Painel** (`pages/HomeAdmin.jsx`, `styles/HomeAdminStyled.js`, `back/rotina.js`): avisos de rotina (planilha e backup).
- **Características** (`componets/ValoresCaracteristica.jsx`, `pages/Caracteristicas.jsx`, `styles/CaracteristicasStyled.js`, `back/colunas.js`): botão **Valores** com a troca de um valor em todos (lote "Padronização da escrita").
- **Item 8 (verificar links) não foi feito**: o site da Intelbras bloqueia acesso automático (ver Pendências).
- **Back**: rotas novas `GET /api/atualizacao`, `GET /api/admin/rotina`, `GET /api/admin/colunas/:tabela/:coluna/valores`, `POST /api/admin/colunas/:tabela/:coluna/trocar-valor`; `ultimaAplicacao` em `sincronizador.js`. **Banco sem mudança** (nenhuma tabela, coluna ou índice novo) e `correcoes.js` sem nada novo: a atualização não muda nenhum dado do servidor. A troca de valores só acontece quando o admin clica.
- **Teste** (cópia `tabela_teste`, servidor na porta 3778, apagados depois): rotas sem login = 401; coluna de controle ou inexistente = 404; troca "Branco" → "Branca" na cor da case (64) e Desfazer tudo pelo Histórico (voltou 363/64, conferido no banco); grafias parecidas nos métodos de recuperação dos gravadores (2 × 25), "Usar:" e troca; troca de 27 e **Desfazer tudo** pelo aviso; avisos de rotina sem backup (amarelo), com backup de hoje (verde) e de 4 dias atrás (amarelo), com arquivos de backup falsos apagados depois; "Atualizada em 07/10/2026" nas abas e no Phaseout; barra do topo em 1366 px (todas as abas cabem, botão HDs abre os dois links) e em 1920 px (os dois links aparecem). Sem erros no console nem no servidor.

### 2026-10-21 (2) — "Só o que muda" só na comparação
- **Pedido** (Gabriel): o botão "Só o que muda" no topo não fazia sentido (já existe na comparação).
- **Site** (`pages/Tabela.jsx`): saiu o botão do topo (e o "N colunas iguais escondidas"); "Só o que muda" ficou só na barra da comparação e desliga ao voltar para a lista.
- **Filtros: tentativa desfeita.** Foi feito um esconder automático dos filtros em que todos os produtos são iguais, mas ele tirou filtros importantes (ex.: Temperatura de operação, porque o filtro é pela mínima e ela é igual em todas as analógicas). Gabriel pediu para voltar tudo: **os filtros e os atalhos "Precisa ter" estão como antes**. Lição: antes de tirar qualquer filtro ou coluna, mostrar a lista e esperar o OK.
- **Teste** (cópia `tabela_teste`, porta 3778, apagados depois): todas as abas com funil em todas as colunas e o painel completo (temperatura de volta nas analógicas, baluns e extensores; Tecnologia de vídeo nas IP); comparação com Só o que muda 37 → 9 colunas e volta para a lista com as 37. Back e banco sem mudança.

### 2026-10-21 — Link da pesquisa, "Só o que muda" na lista, Excel e selo "Novo"
- **Pedido** (Gabriel): itens 2, 3, 4 e 8 da lista de melhorias (pesquisa como link, esconder colunas iguais, exportar para Excel, selo de produto novo).
- **Site** (`pages/Tabela.jsx`, `componets/EnviarCliente.jsx`, `planilhaExcel.js` novo, `styles/TabelasStyled.js`): detalhes em "Recursos da tabela". "Copiar / PDF" virou "Copiar / PDF / Excel". A data do PDF e do nome do arquivo usava o horário UTC (depois das 21h saía o dia seguinte); agora é a data daqui.
- **Back** (`equipamentos.js`): `/api/<tabela>` traz `novo_desde` nos produtos novos (consulta só de leitura no `historico`). **Banco sem mudança** (nenhuma tabela, coluna ou índice novo) e `correcoes.js` sem nada novo.
- **Teste** (cópia `tabela_teste`, servidor na porta 3778, apagados depois): Novos = 5 câmeras IP e 1 analógica (as liberadas em 05 e 07/10); filtros + Novos + Só o que muda → link → F5 volta igual (filtros, ordem, marcados, comparação); trocar de aba limpa e "Voltar" do navegador recupera; grupo dos Baluns no link; Copiar link com clique real ("Link copiado!"); Excel gerado na tela e conferido (openpyxl e leitor de pacote do .NET): 57 linhas, tudo texto, filtro e painel congelado. Sem erros no console.

### 2026-10-15 (4) — Topo da tabela compacto
- **Pedido** (Gabriel): a parte de cima (título, botões e atalhos) ocupava muito espaço; a tabela deve ocupar quase a tela toda.
- **O quê** (`pages/Tabela.jsx`, `styles/TabelasStyled.js`): título e quantidade numa linha com os botões (a dica "clique no equipamento..." foi para o passar do mouse); Precisa ter, Resolução e Ângulo num bloco só, seguindo na mesma linha enquanto couber, com chips menores; botão **Atalhos** esconde/mostra os atalhos (lembrado no navegador, `localStorage` "tabela-atalhos"); menos espaço entre as partes. Em 1900×910 a tabela começa em 168 px (antes ~270); sem atalhos, em 110 px.
- **Só código do site**; banco sem mudança.

### 2026-10-15 (3) — Filtros agrupados em faixas, linha de ângulo e mais atalhos
- **Pedido** (Gabriel): nos filtros, resolução sem as várias versões da mesma coisa (só "2MP (1080p)"), ângulos agrupados (acima/abaixo de 100°) e o mesmo para os outros filtros (umidade, temperatura, lente...); nas câmeras analógicas atalhos de ângulo, alarme e zoom; nos DVRs, câmera com áudio.
- **O quê**: faixas nas opções de filtro e linhas de atalho de resolução/ângulo (detalhes em "Recursos da tabela"). Ex. nas câmeras IP: Resolução de vídeo de 36 opções para 5, Ângulo de abertura de 119 para 5, Protocolos de 37 para 5.
- **Só código do site** (`front/build`); banco e `correcoes.js` sem mudança. Testado só lendo, nas abas Câmeras analógicas, Câmeras IP e DVRs (filtro por faixa + atalho juntos, etiquetas "Filtrando", sem erros no console).

### 2026-10-15 (2) — PDF sem endereço, logo verde e atalhos de inteligência/resolução em todas as abas
- **Pedido** (Gabriel): o PDF mostrava o endereço de onde foi gerado (localhost:3777/cameras?...); nome Intelbras verde no PDF; nos gravadores (e nas outras abas) atalhos "Precisa ter" de inteligência e de resolução como nas câmeras IP.
- **PDF** (`componets/EnviarCliente.jsx`): `@page` com margem 0 e margem feita por uma tabela que repete em cada folha (sem espaço para o navegador imprimir endereço/data); logo no verde original; "Intelbras" verde no rodapé. Testado imprimindo com cabeçalho/rodapé ligados (Chrome): sem endereço, 2 folhas com margem certa.
- **Atalhos** (`pages/Tabela.jsx`): inteligência dos gravadores (Detecção inteligente, Inteligência perimetral, Detecção de face, Reconhecimento facial, Leitura de placa...) e linha de resolução (detalhes em "Recursos da tabela").
- **Só código do site** (`front/build`); banco e `correcoes.js` sem mudança. Testado só lendo (filtros não gravam nada).

### 2026-10-15 — Filtros mais simples, Copiar / PDF para o cliente e página Produtos no admin
- **Pedido** (Gabriel): o pessoal se confundia com os filtros; lista pronta para mandar ao cliente no WhatsApp (ex.: câmeras com linha e cerca e microfone) e PDF dos comparados; "Sim" seguido de detalhe em minúscula; abas do admin confusas para mexer nos produtos.
- **Tabela**: filtros em painel lateral com opções clicáveis e contagens, atalhos "Precisa ter", etiquetas "Filtrando" e colunas filtradas logo depois do Nome (detalhes em "Recursos da tabela"). Saiu a linha de caixas "Filtrar" do cabeçalho. Código: `pages/Tabela.jsx`, `componets/PainelFiltros.jsx`, `componets/EnviarCliente.jsx`, `valores.js` (texto dos valores, comum à tabela, cópia e PDF).
- **Copiar / PDF** e **"Sim" + detalhe com maiúscula** (só na tela, cópia e PDF).
- **Admin**: Adicionar / Alterar / Remover viraram a página **Produtos** (menu: Painel · Revisão · Produtos · Phaseout · Removidos · Características · Histórico). Links do Painel, Revisão e Phaseout apontam para ela.
- **Só código do site** (`front/build`): nenhuma mudança no back, no banco nem em `correcoes.js` — a atualização no servidor não mexe nos dados de lá.
- **Teste** (cópia `tabela_teste`, servidor separado na porta 3778, apagados depois): filtros (painel, atalhos, contagens, combinação), copiar (clique real → "Copiado!"), PDF lado a lado e em lista, Produtos (abrir pelo link antigo, salvar, desfazer, remover → desfazer, novo produto → abre → remover), Revisão/Phaseout/Painel abrindo sem erros no console.

### 2026-10-07 — Datasheets da Revisão, encerrados que faltavam no phaseout (VHC) e busca só pelo modelo
- **Revisão → tabela** (correção automática `2026-10-07-revisao-datasheets`, roda uma vez também no servidor): VIP 1230 SC, VIP 1230 D SC, VIPW 3200 MINI SD SC IA, VIPW 3200 MINI SD DUAL SC IA, VIPW 3230 BULLET FC+ AP IA e VHD 5830 4K FULL COLOR+ preenchidos pelos datasheets da pasta `datasheets` (só o que está escrito; o resto vazio), com os links enviados pelo Gabriel, e liberados. Só grava em campo vazio e só libera se ainda estiver na Revisão. VIP 3430 SC IA e iMHDX 3232 DUAL AUDIO continuam na Revisão (sem página no site). Tipo novo de correção: `preencherELiberar`.
  - VIPW 3230 FC+ AP IA: o datasheet traz "Throughput Máximo (Cabo): 12 Mbps (??)" → throughput deixado vazio até confirmar.
- **Encerrados que nunca foram cadastrados** (ex.: VHC 1120 B/D, que só existem nos Encerramentos): a importação agora coloca direto no phaseout, com mês e substituto ("Encerrados que não estão cadastrados" na análise). Não entram: linha Future, removidos pelo admin e os que ainda estão em linha na aba Tabela. No teste: 73 modelos (VHC, VB 3004 WP, VEX 3060 KVM, VIP 7xxx, gerações antigas de VHD...).
  - Para não depender de uma nova importação, a correção automática `2026-10-07-encerrados-no-phaseout` (tipo `encerradosNoPhaseout`, função `adicionarEncerradosNoPhaseout` do sincronizador) faz só essa parte ao ligar, com a planilha já importada. No PC de testes foi aplicado direto (73 no phaseout, VHC 1120 B/D em 10/2024 → VHL 1120 B/D G2); testado numa cópia sem as VHC: ao ligar, ela as recolocou.
- **Leitura dos nomes antigos dos Encerramentos** (`regras.js`): "COM HD 1TB", "C/ 3TB", "C/ SUPORTE", "4MP COM INTELIGÊNCIA..." e lente no fim ("3.6MM"; "3,6MM" cortado na vírgula virava "VHD 3120 B 3") saem do nome do modelo. Conferido: a aba Tabela continua gerando exatamente os mesmos 261 modelos.
- **Busca do topo** virou "Buscar modelo": procura só no nome, igual ao filtro da coluna Nome ("SC" mostra só os modelos com SC; antes achava "sc" em qualquer característica). Também acha sem espaço/hífen ("vipw1430").
- **Revisão geral** (cópia `tabela_teste`): todas as abas abrem sem erro; ficha técnica, comparar (com "Voltar para a lista"), Colunas, alterar/adicionar/remover, histórico, importação (aplicar → reimportar = 0 mudanças) e Revisão funcionando.

### 2026-10-05 — Pesquisa de modelo fora de linha mostra o phaseout e o substituto
- Numa aba em linha, se a pesquisa não acha nada e o nome bate com equipamentos do phaseout, aparece "Fora de linha com esse nome": modelo, mês do phaseout e substituto direto/indicação (até 6), com link para a aba Phaseout. A lista do phaseout só é buscada quando alguém pesquisa.
- A mensagem "Nenhum equipamento encontrado" ficava centralizada no meio da tabela (bem mais larga que a tela) e não aparecia: agora fica presa na parte visível.
- Conferência do banco do PC de testes: só equipamentos em linha com dados técnicos nas abas (câmeras 83, média 34 características; gravadores 24, média 50; baluns 7; extensores 4); nenhum com menos de 5 características ou sem link próprio.

### 2026-10-05 — Revisão: produto novo só entra na tabela depois de preenchido e liberado
- **Pedido** (Gabriel): às vezes o produto aparece na planilha antes de ser lançado de verdade, ou nem é da nossa linha.
- **Status novo "Em revisão"** (`phaseout = 'Em revisão'`, `STATUS.REVISAO`): não aparece nas abas nem no Phaseout. Todo modelo novo da planilha entra assim (com ou sem dados copiados de um modelo parecido) + alerta "Novo equipamento na Revisão".
- **Página Revisão** do admin (`/revisao`, `front/src/pages/Revisao.jsx`): para cada produto, "Preencher dados", **"Liberar na tabela"** (só com pelo menos 1 dado técnico; `POST /api/admin/revisao/liberar`) e **"Remover"** (vai para Removidos e não volta pela planilha). No Alterar, um produto em revisão mostra a faixa com "Liberar na tabela". As listas do admin marcam "revisão".
- "Dado técnico" = qualquer característica preenchida, menos as colunas de controle, "cores" (padrão 'Branco' no banco) e método de recuperação (`contarDadosTecnicos`).
- A planilha **não mexe** em produto em revisão (não volta para linha nem vai para phaseout sozinho); se ele sair da planilha ou for encerrado, a análise lista "Na Revisão, mas não estão mais em linha".
- **Correção automática** `2026-10-05-revisao-sem-dados` (roda uma vez, também no servidor): os que estão em linha sem nenhum dado técnico vão para a Revisão (no PC de testes: 8, os novos da planilha de outubro). Fica no Histórico (Desfazer tudo).
- **Teste** (cópia `tabela_teste`): liberar sem dados é recusado; depois de preencher, libera e aparece na aba; remover vai para Removidos e não volta; modelo novo da planilha entra na Revisão e não aparece na aba; reanalisar = 0 mudanças.

### 2026-10-05 — Aba Encerramentos: em linha de verdade, data de phaseout e substituto direto
- **Problema** (Gabriel): a aba Tabela da planilha ainda lista produtos já descontinuados; só ela não basta para saber o que está em linha.
- **Regra nova**: em linha = alguma versão (código) na Tabela que não está em Encerramentos (detalhes em "Planilha de preços e sincronização").
- **Painel**: o cartão da planilha aceita os dois arquivos juntos (em qualquer ordem), mostra as duas abas importadas e, na análise: phaseout com mês e substituto, "Já no phaseout: data/substituto serão corrigidos" e "Na aba Tabela, mas com todas as versões nos Encerramentos". Aviso quando falta o arquivo de Encerramentos.
- **Aba Phaseout**: colunas Nome, Tipo, Phaseout (mês/ano, ordena pela data), **Substituto direto** e Métodos de recuperação (a coluna de data completa saiu: a planilha só informa mês/ano). Página Phaseout do admin: coluna **Substituto direto** editável e busca por substituto.
- Voltar para linha limpa o substituto. `substituto` é coluna de controle (não aparece nas abas em linha, não é copiada nem vira característica).
- **Teste** (cópia `tabela_teste`, planilha Outubro V1): 204 modelos em linha; **40 vão para phaseout** (ex.: VIP 1230 B/D G5, VIPW 1430 e 1430 D, VHD 5830 B 4K, VB 503 B G2, VB 1104 WP, VB 3016, VEX 3004 SWITCH, VEX 3120 HDMI IP/RX, NVD 3316-PLUS, MHDX 1304/1308/1316); **225 já em phaseout** com mês/substituto corrigidos; 9 novos. Aplicar → reanalisar = 0 mudanças; "Desfazer tudo" do lote volta as 274 mudanças. Na primeira importação no servidor a **trava de 10** vai aparecer na confirmação de "Aplicar mudanças" (dar OK).
- **Trava sem caixinha**: no PC de testes o Gabriel aplicou sem marcar "Aplicar mesmo acima do limite" e os 40 não saíram de linha (só as correções de data/substituto entraram). A caixinha saiu: a própria confirmação avisa e aplica.

### 2026-10-04 — Stream extra e classificação perimetral fora; Inteligência antes das saídas; faixa de categorias
- **Retiradas da tabela** (pedido do Gabriel): IP/HDCVI/AHD/HDTVI/Analógico stream extra e "Classificação da inteligência perimetral". No servidor saem sozinhas ao reiniciar (`back/correcoes.js`, correção `2026-10-03-remover-colunas`); os valores ficam no Histórico (lote "Correção automática" → Desfazer tudo recria as colunas com os valores — testado).
- **Gravadores**: categoria Inteligência logo depois da Entrada de vídeo (antes da Saída de vídeo).
- **"Sim + detalhe"**: selo no começo e o detalhe continua ao lado como parágrafo (alinhado à esquerda, até 220 px); antes o selo ficava centralizado ao lado de um texto quebrado palavra por palavra.
- **Visual**: faixa de categorias acima dos títulos (ENTRADA DE VÍDEO · INTELIGÊNCIA · ...), linha separando cada grupo de colunas e separação discreta entre colunas.
### 2026-10-03 (3) — Ficha técnica consertada; auditoria dos links
- **Ficha técnica**: as caixinhas novas da tabela usavam a classe `item`, a mesma das linhas da ficha → a ficha ficou espremida (~170 px). Caixinha renomeada para `valor`; ficha com rótulo numa coluna fixa e valor ao lado, alinhado à esquerda, seções mais largas.
- **Auditoria dos links** (endereço tem o modelo e cada parte do nome?): 143 ok; sem link genérico depois da correção automática. **Confirmados pelo Gabriel em 03/10/2026 — corretos como estão**: VIPC 1220 D FC+ (aponta para a página de suporte do "VIP 1220 D FC", outro produto); versões BLACK que usam a página da versão branca (VHD 1220 D BLACK G8, VHD 1220 D FC+ BLACK, VHD 1220 FC+ BLACK, VHD 1230 B BLACK G8, VHD 3220 MINI D BLACK G8, VIP 1230 B/D BLACK G4); só página de suporte/download (VIPW 1220 D FC+, iMHDX 3116, NVD 1404, NVD 1408, NVD 3316-PLUS, VB 3016, VEX 3004 SWITCH).
### 2026-10-03 (2) — Marcados fixos no topo; caixinhas em tudo; colunas compactas (NVDs refeitos)
- **Comparar**: os marcados ficam fixos no topo da lista (faixa "Selecionados para comparar") mesmo pesquisando outro modelo; embaixo "Resultado da pesquisa".
- **Caixinhas em todas as informações** (menos Sim/Não). Resoluções: só as 3 maiores na tabela + "+N" (passar o mouse mostra o resto).
- **Larguras e espaços**: títulos de coluna quebram em até 3 linhas (antes "Classificação da inteligência perimetral" deixava a coluna com 387 px), filtros e células mais estreitos, caixinhas com largura máxima, frases e listas longas numa caixinha só, streams em até 3 linhas. Medido a 1440 px: NVDs linha 137 → 85 px e coluna média 203 → 193 px; Câmeras IP linha 98 → 79 px; coluna Formato 221 → ~170 px.
### 2026-10-03 — Bug de salvar no painel, links, tudo visível na tabela e comparação de produtos
- **Bug "alterar não salva"**: o login do painel vencia em 6 h; ao salvar com o login vencido, a tela ia para o login e **perdia o que foi digitado**. Agora o login vale **7 dias**, é **renovado sozinho** enquanto o painel é usado (cabeçalho `X-Novo-Token`) e, se vencer mesmo assim, abre uma **janela de login por cima** da página: o que foi digitado continua na tela e é só salvar de novo. A API também passou a responder sem cache (`Cache-Control: no-store`).
- **Teste de todas as funções do painel** (35 verificações, cada uma relendo o banco): alterar (câmera, gravador, balun, extensor, característica nova, status, renomear), adicionar, remover/Removidos/restaurar, phaseout em lote e desfazer lote, características (criar, renomear, categoria, esconder, uso, excluir, desfazer), histórico, alertas, sugestões, planilha (enviar, analisar, aplicar, reaplicar). Tudo ok, inclusive numa simulação do servidor (versão antiga + atualização por cima).
- **Links**: os 158 em linha abertos no navegador. VIPW 1210 MINI DUAL e VIPW 1200 MINI SD DUAL AP apontavam para a página genérica "Segurança eletrônica" → links dos produtos; VHL 1220 B G9, VHL 1220 D G9 e iNVD 5232-16P com o endereço novo do site; VIPC 1220 D FC+, VIPW 1220 D FC+, iMHDX 3116, NVD 1404, NVD 1408 e NVD 3316-PLUS levam hoje à página de suporte/download (a Intelbras tirou a página de produto). Aplicado por `back/correcoes.js` (automático no servidor).
- **Tudo visível na tabela**: acabou o "+1" e o "…"; listas como etiquetas e textos longos quebrando em linhas.
- **Comparar produtos**: caixinhas, barra Comparar, diferenças em amarelo, "Só o que muda".
- `PREPARAR_ATUALIZACAO.bat` para levar só o necessário ao servidor.
### 2026-10-01 — Verificação final e pacote para o servidor
- Verificação completa numa cópia do banco: todas as rotas da API (públicas e admin, login, 401 sem login), páginas, contagens (106 câmeras, 33 gravadores, 10 baluns, 9 extensores, 407 em phaseout), salvar → Histórico → Desfazer pelo painel, console sem erros.
- **Servidor 24h**: `servidor\servico.cmd` (vigia que religa em 5 s, testado derrubando o programa), tarefa agendada no boot como SYSTEM, `INSTALAR_NO_SERVIDOR.bat`, `REINICIAR_TABELA.bat`, `DESINSTALAR_DO_SERVIDOR.bat`, `BACKUP_AGORA.bat`, `PREPARAR_PACOTE_SERVIDOR.bat`. Back: tenta preparar o banco de novo a cada 10 s (PostgreSQL atrasado no boot), encerra para ser religado em erro inesperado ou porta ocupada, registro com data/hora.
- Pacote testado: `tabela.sql` importado num banco novo = mesmas contagens do original; tabela rodando da pasta do pacote na porta 49152 (inclusive pelo IP da rede) com a verificação completa ok; backup ok. **Não testado aqui** (precisa de administrador): o registro da tarefa, firewall e PostgreSQL automático — feitos pelo instalador no servidor.
- 41 alertas "dados pendentes" resolvidos (equipamentos já preenchidos pelos datasheets). Ficam 60 avisos informativos da importação de 30/09 para dispensar no painel.
### 2026-10-01 — Modal "Colunas" compacto; Interface, Métodos de acesso e FC inteligente excluídas
- Modal **Colunas visíveis** em colunas (estilo jornal, `SeletorColunas` em `TabelasStyled.js`): cada grupo encaixa logo abaixo do anterior, sem os buracos da grade; itens mais juntos. Gravadores cabem sem rolar.
- **Excluídas a pedido** (todas as tabelas onde existiam): "Interface" (câmeras: 65 preenchidas; gravadores: 8), "Métodos de acesso" (gravadores: 13) e "Compatível com Full Color inteligente" (gravadores: 27). Os valores ficam guardados no **Histórico** (Desfazer recria a coluna com os valores). Removidas também de `front/src/filtro.js`.
- Backup antes: `back/dados/backup-antes-excluir-interface-cloud-fc-2026-10-01.sql`. Testado numa cópia e pela tela (NVDs e câmeras IP).
### 2026-10-01 — Extensores fiéis ao datasheet; nomes do datasheet
- **Regra: só o que está no datasheet.** O que o datasheet não informa fica vazio ("—"); nada de interpretação. Extensores refeitos assim: tipo = subtítulo do datasheet, resoluções literais (`1080p@24/25/30/50/60Hz`), "HDMI (splitter)" como no datasheet, alimentação de TX e RX separadas.
- Renomeados para o nome do datasheet: **VEX 3004 HDMI → VEX 3004 SWITCH** e **VEX 3120 G2 4K → VEX 3120 HDMI G2 4K** (dados mantidos); a leitura da planilha converte esses nomes (`NOMES_DO_DATASHEET`), para não voltarem nem irem para phaseout.
- Revisão do que tinha sido deduzido antes: VB 1016 WP sem alcance HDTVI (o datasheet não traz; estava copiado do AHD), VB 1001 WP "não possui fonte interna" (era "não inclusa"), VB 3016 "Balun sem alimentação para CFTV", iNVD 5316 PD sem "classificação" (não consta no datasheet). VB 503 B G2 com o link da página e a saída do datasheet novo.
- Backup antes: `back/dados/backup-antes-extensores-fiel-2026-10-01.sql`. Testado numa cópia (2ª passada = 0).
### 2026-10-01 — Extensores (VEX) pelos datasheets; link do VB 503 B G2
- **Extensores (9)**: 24 características criadas — tipo de equipamento, transmissor (TX), receptor (RX), alcance CAT6/CAT5e, cabo HDMI, resolução máxima e suportadas, versões HDMI/HDCP/USB, taxa de transferência, compressão (só os IP: H.264), áudio, controle IR, alimentação, consumo, surtos, material, cor, temperatura, umidade, dimensões, peso — preenchidas pelos datasheets da pasta `datasheets/vex`, com os links enviados. Splitter e switch (aparelho único) aparecem com RX "Não tem" e alcance "Não se aplica".
- **VB 503 B G2**: link da página do produto (`balun-passivo-vb-503-b-g2`) e saída conferida no datasheet novo do G2.
- Backup antes: `back/dados/backup-antes-extensores-2026-10-01.sql`. Testado numa cópia (aplicar 2x = 0 na 2ª) e pela tela.
### 2026-10-01 — Gravadores e baluns pelos datasheets; InSearch; filtros melhores
- **Gravadores em linha (33)** conferidos nos datasheets (pastas `datasheets/MHDX` e `datasheets/nvds`): resoluções de entrada, streams principal/extra (NVDs com IA ligada e desligada), bit rate, throughput, inteligências (embarcado × recebe da câmera), HDs, USB, alarmes, protocolos. 867 campos (lote "Correção pelos datasheets"). Erros corrigidos: "Interface = Preta", bit rate do MHDX 1116-C com o texto do áudio, resoluções IP erradas (MHDX 1208-C, iMHDX 3108...), streams vazios do iNVD 5232, NVD 1516/1516-P/1532 com os números da tabela de streams. **iNVD 5316 PD, MHDX 1216-C DUAL AUDIO e MHDX 3216-C DUAL AUDIO** estavam vazios → completos, com os links enviados.
- **Características novas dos gravadores**: **InSearch** (iNVD 5316 PD = "Sim (Lite)"; os outros "Não"), **Busca inteligente** (pessoas e veículos, faces, InSearch) e **Portas PoE** (quantidade, padrão e potência). Na aba DVRs as duas de NVD ficam escondidas.
- **Baluns (10)**: 24 características criadas (tipo, canais, entrada/saída, função 4x1, resolução máxima, tecnologias, alcance HDCVI/AHD/HDTVI/analógico, áudio, OSD/PTZ, alimentação, corrente, consumo, surtos, rack, material, cor, temperatura, umidade, dimensões, peso) e preenchidas pelos datasheets da pasta `datasheets/VB`, com os links enviados.
- **VB 503 B → VB 503 B G2**: o produto em linha é o G2 (código 4810040; o resumo da planilha já dizia "VB 503 B G2"; datasheet do G2 no site da Intelbras). Renomeado com os dados mantidos, e a leitura da planilha passou a preferir a geração do resumo (`interpretarProduto`), para não voltar a "VB 503 B".
- **Padronização da escrita** (gravadores): áudio "1 entrada RCA (15 kΩ)", resoluções "1920×1080 | 1280×1024", "NTSC | PAL", "IPv4"/"ONVIF", "16 Entradas"→"16", "Saidas", "técninca", "Não está claro no DataSheet"/"Informação não consta na tabela" → "Não informado", bit rate resumido, capacidades "Embarcado: ... | Recebe: ...".
- Rótulos: "HDCVI stream principal" (antes "Stream Principal"), "Processamento do reconhecimento facial", "Classificação da inteligência perimetral", "Adaptador USB Wi-Fi", "Compatível com Full Color inteligente".
- Backup antes: `back/dados/backup-antes-datasheets-gravadores-baluns-2026-10-01.sql`. Testado numa cópia (aplicar 2x = 0 mudanças na 2ª) e pelas telas (NVDs, DVRs, Baluns, filtro InSearch).
### 2026-10-01 — Câmeras IP pelos datasheets, padronização da escrita e tabela mais fácil de ler
- 43 datasheets (pasta `datasheets/cameras ips`) + links enviados: as **65 câmeras IP em linha** conferidas campo a campo, separando Bullet e Dome nos datasheets unificados (lente, ângulo, IR, full color, proteção, case, temperatura). 1.101 campos num lote só (Histórico → "Correção pelos datasheets").
- Erros que existiam: ângulos trocados entre bullet e dome (VIP 5430 TL IA / D TL IA, VIPW 1430 D, VIP 3230 FC+ AP IA), "D: 10º/12º" (VIPC 1430 B, VIPC 1220), zoom digital como óptico (VIP 5203 T IA, VIP 5180 PAN IA), throughput Wi-Fi de 114 Mbps nas VIPW 1210 C / 1410 MINI (são 12 e 24), case trocado (VIP 5430 TL), etc. 7 câmeras sem nenhum dado (VIP 1230 FC+ AP, VIP 1230 D FC+ AP, VIP 5440 FC+ IA, VIP 5440 D FC+ IA, VIP 5440 D IA, VIPW 1200 MINI SD DUAL AP, VIPW 1210 MINI DUAL) agora completas, com links.
- Preenchidos também: protocolos (com perfil ONVIF), interface de rede, microSD com a capacidade, PoE com o padrão (802.3af/at), Wi-Fi com a banda.
- Analógicas reconferidas: cada uma tem datasheet próprio, bullet e dome já estavam separadas; só VHD 1220 B/D FC+ estavam "Branca ou Preta" (a preta é outro modelo) → "Branca".
- **Característica nova "Formato"** (bullet, dome, speed dome, mini speed dome, fisheye...), preenchida em todas as câmeras pelo datasheet ou pelo nome.
- **Padronização da escrita em câmeras e gravadores** (431 equipamentos, 1.242 campos, lote "Padronização da escrita"): erros como "classiicação", "Aluminio", "metálico", "Detecção Facial", "NÃO INFORMA NA FICHA", "40º a +60ºC" (sem o menos), "MJEPG", "Juffeng", "email", "Usuario"; formatos misturados (`H.085° / V.45º`, `082º`, `2.8 mm`, `95%`/`< 95% RH`); textos longos de fluxo de vídeo resumidos (`Até 20 conexões | 4 fluxos de vídeo simultâneos | Intelbras Cloud: 2 conexões`). Nomes das colunas corrigidos (Interface, Wi-Fi, Saída spot, Quantidade de HDs, Entradas de vídeo...).
- Tabela: novo visual dos valores (selo Sim, "Não" discreto, listas), ordem das colunas pelo mais importante, ficha técnica com listas uma por linha.
- Backup antes: `back/dados/backup-antes-datasheets-ips-2026-10-01.sql`. Testado numa cópia do banco (aplicar 2x = sem mudanças na 2ª) e pelas telas.

### 2026-10-01 — Baluns e Extensores no lugar de Acessórios; Phaseout editável no admin
- **Aba Acessórios removida** → abas **Baluns** (`/baluns`, grupos Power balun com WP / Baluns comuns) e **Extensores** (`/extensores`), cada uma com **tabela própria no banco** (`baluns`, `extensores`) para ter as suas características técnicas.
- Migração automática em `banco.js` (`separarAcessorios`, numa transação): VB → `baluns`, VEX → `extensores` com todos os dados; histórico, alertas e configuração das características passam para a tabela nova; o resto (TESTER 3000 MT e TESTER 3000 RJ45) sai da tabela com cópia guardada no histórico (origem "Sistema", não aparece em Removidos) e a tabela `acessorios` é apagada. Roda sozinha também no servidor do trabalho, se lá existir `acessorios`.
- Regras da planilha: `VB` → baluns, `VEX` → extensores; `VTN` e `TESTER` deixam de entrar.
- **Página Phaseout no admin** (`/editarPhaseout`): edição direta de nome, método de recuperação e data; edição em lote com Desfazer; voltar para linha; remover. Rota nova `POST /api/admin/alterarVarios`.
- Levantamento dos métodos de recuperação: os 407 itens em phaseout têm exatamente o valor da `tabela_antiga.sql` (nenhum foi alterado pelo sistema) — os errados vêm de lá.
- Banco real: backup em `back/dados/backup-antes-baluns-extensores-2026-10-01.sql`; migração aplicada (10 baluns, 9 extensores, 2 testers guardados no histórico).
- Testado numa cópia do banco real: migração, alertas/histórico apontando para as tabelas novas, TESTER fora de Removidos e "Desfazer" com aviso claro, alteração em lote + desfazer lote, data/nome pelo phaseout, regras da planilha (VB/VEX/TESTER/VTN), análise do CSV, telas (Phaseout admin, Baluns, Home).

### 2026-09-30 — Câmeras analógicas corrigidas pelos datasheets
- 39 datasheets (pasta `datasheets/`) + links enviados: as 41 analógicas em linha conferidas campo a campo. 34 câmeras / 340 campos alterados num lote só (Histórico → "Correção pelos datasheets" → "Desfazer tudo"; backup em `back/dados/backup-antes-datasheets-analogicas-2026-09-30.sql`).
- 8 cadastros completos (estavam vazios): VHD 1220 FC+ BLACK, VHD 1220 D FC+ BLACK, VHD 1220 D G9, VHD 3220 MINI D BLACK G8, VHD 3250 VF G8, VHD 5216 SD, VHL 1120 B G2, VHL 1120 D G2 (com links).
- Correções: protocolos (AHD-M → AHD-H conforme datasheet; 3230 B SL só HDCVI), formato de vídeo (NTSC), proteção (IP67 onde faltava; "-" nos modelos de uso interno), alcance full color nos FC+, temperatura sem o sinal de menos, VHD 3150 VF G7 é 720p, umidade, cores "Branco" → "Branca".
- TESTER 3000 MT e TESTER 3000 RJ45 adicionados em Acessórios.
- Histórico: grupos de lote mostram "Correção pelos datasheets" (antes, todo lote aparecia como "Aplicação da planilha").

### 2026-09-30 — Versões do mesmo modelo em sequência
- Nova ordem padrão (`front/src/ordemModelos.js`): sigla → número → família (recursos + geração) → formato (bullet/sem letra, depois dome) → cor (branca, depois preta). Ex.: VHD 1220 B FC+, VHD 1220 FC+ BLACK, VHD 1220 D FC+, VHD 1220 D FC+ BLACK ficam juntas.
- Vale na tabela (ordem inicial e ao ordenar por Nome) e nas listas do painel (Adicionar/Alterar/Remover).

### 2026-09-30 — Excluir qualquer característica, LAB removido e crédito no canto
- Características: lixeira em todas (originais também), com os valores guardados no histórico e Desfazer que devolve tudo. O site esconde definições de colunas que não existem mais no banco (`GET /api/colunas` devolve `existentes`); adicionar/alterar ignoram campos de colunas excluídas.
- Sugestões recarregam depois de cada salvamento (antes só ao escolher o tipo); limite de 60 → 300 valores por característica.
- **Informações do laboratório removidas**: colunas `ip` ("IP no LAB") e `tem_no_lab` de câmeras e gravadores excluídas do banco real (histórico 1–4, dá para desfazer; backup completo em `back/dados/backup-antes-remover-lab-2026-09-30.sql`) e do código.
- Home: crédito no canto de baixo à direita, compacto, com o visual de antes (círculo GC, nome e matrícula).
- Testado numa cópia do banco real: excluir "Lente" (200 preenchidos) → some da tabela/formulários → alterar equipamento com o campo antigo não dá erro → Desfazer devolve os 200 valores; característica nova com "Sim em 8 canais" vira sugestão; desfazer criação de característica preenchida é recusado; colunas de controle protegidas.

### 2026-09-30 — VTN e TESTER em acessórios; grupos na aba Acessórios
- Regra: `VTN` (sem FT) e `TESTER` entram em acessórios. Planilha de setembro: VTN 2000 G2, TESTER 3000 MT, TESTER 3000 RJ45 (VTN 9000 FT fica de fora).
- Aba Acessórios separada em grupos: baluns (VB 3 dígitos), baluns tipo switch (VB 4 dígitos), extensores, mesas de controle, testadores.
- Testado numa cópia do banco real: análise com os 3 novos, aplicação, aba com 22 itens em 5 grupos, filtro por grupo.

### 2026-09-30 — Aba "Removidos" e planilha respeitando removidos
- Página "Removidos" no painel com Restaurar; a análise/aplicação da planilha não adiciona modelos que estão em Removidos e avisa (lista na análise + alerta).
- Testado em banco de teste: remover 2 → **desligar e religar o servidor** → continuam em Removidos; análise sem os 2 em "novos" e com os 2 em "removidos"; aplicar → 2 alertas e nenhum re-adicionado; Restaurar → volta com os dados técnicos (IR, lente, IP67...) e sai de Removidos.

### 2026-09-30 — Histórico com "Desfazer"
- Tabela `historico` (criada ao iniciar) e página "Histórico" no painel; "Últimas alterações" no painel inicial; botão Desfazer nos avisos de remover/adicionar/salvar/características.
- Desfazer: remoção (restaura com todos os dados), cadastro, alteração (recusa se houve mudança depois), renomear, características, e aplicação inteira da planilha ("Desfazer tudo").
- Testado em banco de teste com a tabela antiga: remover → desfazer (39 campos idênticos), desfazer o desfazer, conflito de ordem recusado, renomear, características, aplicação da planilha com 106 mudanças desfeitas sem erro; fluxo pela tela (remover → aviso → Desfazer).
- Rotas: `GET /api/admin/historico`, `POST /api/admin/historico/:id/desfazer`, `POST /api/admin/historico/desfazer-lote`. Adicionar/alterar/remover agora respondem JSON `{ mensagem, historicoId }`.
- O histórico começa a contar a partir desta versão (mudanças anteriores não estão registradas).

### 2026-09-30 — Página "Características" e crédito na Home
- Nova página do admin para reconfigurar os filtros de cada tipo (nome, categoria, esconder/mostrar, criar, excluir só vazias criadas pelo painel), com contagem de preenchimento. `colunas_personalizadas` ganhou `oculta` e `personalizada` (migração automática ao iniciar).
- Tabela pública, modal "Colunas", ficha técnica e formulários respeitam nome/categoria/escondida definidos no painel.
- Home: crédito "Tabela desenvolvida por Gabriel Luiz Capistrano · ga059385".
- Obs.: VHD 7503 MINI SD DUAL LENS é da linha de projetos (sem FT); removido manualmente antes do histórico — volta na próxima importação; removendo de novo pelo painel ele fica em Removidos e não volta mais.

### 2026-09-30 — Lista de equipamentos no painel (Adicionar / Alterar / Remover)
- Ao escolher o tipo, aparece a **lista de todos os equipamentos** daquele tipo; digitar filtra na hora (ignora maiúsculas, espaços e hífens). Em linha primeiro, depois os de phaseout (com selo).
- Alterar: clique abre o equipamento (a lista recolhe; reabre ao clicar no campo; avisa se houver alterações não salvas). Remover: clique seleciona e o botão remove (com confirmação). Adicionar: a lista do "Preencher mais rápido" copia as características com um clique.
- API `/api/buscarEquipamentos` agora devolve `{ nome, emLinha }`. Componente novo `ListaEquipamentos.jsx`.

### 2026-09-30 — Remanufaturados (REM) fora da tabela
- Modelos com "REM" são ignorados na sincronização (listados na análise como "Remanufaturados"); "REM" deixou de contar como variação do mesmo modelo.
- Removido do banco o `MHDX 1108-C REM` (adicionado na aplicação anterior); o `MHDX 1108 C` original segue no phaseout.

### 2026-09-30 — Tabela antiga restaurada e planilha aplicada (PC de testes)
- `tabela_antiga.sql` (pg_dump do servidor do trabalho, PostgreSQL 17.6) restaurado no banco `tabela`: 373 câmeras, 151 gravadores. A ferramenta de restauração agora ignora instruções só do servidor antigo (dono `hadjqhpwhiyuzl`, permissão e o gatilho `verificar_phaseout`, cuja função não vem no dump).
- Formato da tabela antiga mantido: descontinuado → `phaseout = "MM/AAAA"` + `descontinuado = 'Sim'`; em linha → `'Equipamento em linha'` + `'Não'`.
- Regra de nomes afinada com os dados reais: "FULL COLOR" = "FC", "SUPER COLOR" = "SC", "B" (bullet) opcional, "GERAÇÃO 9" da descrição → "G9"; "parecido" só aceita variações (cor, REM, MIC, DUAL AUDIO; FC+ só em DUAL AUDIO). Diferença só de cor copia os dados em vez de renomear. Câmeras BLACK/PRETA entram com cor "Preta". Cadastros em dobro são avisados na análise.
- Planilha de setembro aplicada (trava liberada após revisão): 30 nomes padronizados com dados mantidos, 47 novos (5 com dados copiados), 16 para phaseout (gerações antigas G5–G8), 13 voltaram para linha (estavam com phaseout programado mas continuam na planilha), 0 erros.
- Resultado em linha: Câmeras IP 66 (58 com dados), analógicas 45 (33), DVRs 18 (16), NVDs 16 (15), Acessórios 19 (0) → **42 para preencher** (alertas "Preencher dados" no painel). Phaseout: 407.

### 2026-09-29 — PostgreSQL no PC e restauração da tabela antiga
- PostgreSQL 17 instalado no PC de testes (winget), banco `tabela`; `.env` apontando para ele.
- `RESTAURAR_TABELA_ANTIGA.bat` + `back/ferramentas/restaurarTabelaAntiga.js` (seguro: não sobrescreve).
- Servidor com keep-alive de 65 s (corrige falha ocasional no envio da planilha).
- Teste completo no PostgreSQL real.

### 2026-09-29 — Limpeza, servidor único e ficha técnica
- Um único programa serve site + API (porta 3777, API em `/api`): sem `serve`, sem CORS, **sem IP no código**. `INICIAR.bat` liga tudo em qualquer pasta.
- `.env` só com o necessário (login, banco, porta); removidas sincronização automática, planilha fixa, colunas configuráveis e exportação para Excel.
- Removidos: cadastro antigo de admins, pacote/`ATUALIZAR.bat` do servidor (refazer no plano de implantação), `tabela.bat`, componentes/estilos sem uso, fontes e ícones não usados (~19 MB), dependências sem uso (back: bcrypt, nodemailer, cors, cookie-parser, body-parser, nodemon; front: react-query, react-modal, Vercel, testing-library).
- `banco.js` cria `cameras`/`gravadores` se não existirem (banco novo), sem tocar nas existentes.
- Tabela: **busca geral** e **ficha técnica** ao clicar no equipamento; títulos das categorias com acento.

### 2026-09-29 — Pacote de atualização do servidor (removido na limpeza; será refeito no plano de implantação)

### 2026-09-29 — Regra confirmada, dados técnicos mantidos e Home em menu
- `VIPW` como câmera IP; "F T" = FT; kits/versões: modelo em linha enquanto qualquer versão estiver na planilha.
- Renomeia o mesmo equipamento escrito diferente, copia dados de antigo parecido em phaseout, padroniza nomes.
- Home em menu direto com botão Admin discreto.

### 2026-09-29 — Planilha de preços, regra oficial, acessórios e características
- Regra do segmento, importação do CSV pelo painel (analisar → corrigir → aplicar), aba Acessórios, características novas, sugestões e "copiar características de…".

### 2026-09-29 — Sincronização com a planilha, alertas e novo visual

### 2026-09-28 — Login único, status e preparação para Excel

### 2026-09-28 — Correção de bugs
- Conexões do banco, SQL injection, erros que derrubavam o servidor, filtros, datas, renomear, mensagens de erro.

## Notas para a IA / quem for mexer no código

- Código e textos em **português**; seguir o estilo existente (React com hooks, styled-components, nomes em pt-BR).
- Cores: variáveis de `front/src/styles/GlobalStyled.js` (claro em `:root`, escuro em `:root[data-tema='escuro']`): **não usar cor fixa** nos estilos (o modo escuro quebra); cor nova = variável nova nos dois blocos. Botões `Botao` e caixas `Cartao` de `styles/Base.js`.
- Leitura de datasheet: regras em `front/src/datasheet.js` (`REGRAS`, `PALAVRAS_CHAVE`). Datasheet novo com rótulo diferente: acrescentar o rótulo na regra e conferir com `datasheets/teste-leitor/testar.mjs` (total de iguais ao banco antes e depois; ver "Testes"). Nunca deduzir: só converter o que está escrito.
- Status: usar `PHASEOUT_EM_LINHA` (`back/equipamentos.js` e `front/src/status.js` — iguais).
- Equipamentos no back só por `back/equipamentos.js`; nomes de tabela só de `TABELAS`; valores sempre como parâmetros (`$1`).
- Regras da planilha **só** em `back/sincronizacao/regras.js`. Tabela nova: `TABELAS`/`TIPO_DA_TABELA` e `banco.js` (back), `TIPOS_EQUIPAMENTO`/`colunasDoTipo`/`rotulosDoTipo` (`filtro.js`), `abas.js` e `configurarAba` (`Tabela.jsx`).
- Títulos/categorias no front: via `configuracaoDoTipo(tipo, colunasPersonalizadas)`.
- Front: chamadas de admin com `apiFetch` (`/api`), avisos com `useAviso()`, páginas de admin dentro de `<LayoutAdmin>` (`larga` para usar a tela toda).
- Texto dos valores (célula, filtro, WhatsApp/PDF): `front/src/valores.js`.
- A pasta chama `componets` (sem o "n") — manter.
- Depois de mudar `front/src`: `npm run build`.
- Nesta máquina há Node em `C:\Program Files\nodejs` (pode estar fora do PATH do terminal) e PostgreSQL 17 (`postgres`/`admin`, banco `tabela`). Para testes, criar bancos separados (ex.: `tabela_teste`) e apagar depois — nunca testar no `tabela`.
- Atualizar este README (seções afetadas + Histórico) a cada mudança.
