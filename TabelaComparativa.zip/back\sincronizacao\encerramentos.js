// Aba "Encerramentos" da Tabela de Preços Distribuição: produtos descontinuados, com o mês do encerramento
// e o substituto direto. Um código (versão) que está aqui não conta como em linha, mesmo que ainda apareça
// na aba "Tabela" (pedido em 05/10/2026). Cada código é uma versão: kit com HD, versão Manaus...
const { lerPlanilha, normalizarTexto } = require('./leitorPlanilha');
const { interpretarProduto, chaveDoModelo } = require('./regras');

const COLUNA_NOME = 'Descrição do Produto';
const COLUNA_RESUMO = 'Produto/Resumo';
const COLUNA_CODIGO = 'Código Produto';
const COLUNA_DATA = 'Data';
const COLUNA_SUBSTITUTO = 'Substituto Direto';
const COLUNA_INDICACAO = 'Indicação';

const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

// "out-26" (como vem no CSV), "10/2026", "01/10/2026" ou "2026-10-01" (xlsx) -> "2026-10"; senão null.
// A planilha só traz mês e ano: o dia nunca é inventado (a data gravada é o dia 1 e a tabela mostra "10/2026").
const mesDoEncerramento = (texto) => {
  const valor = normalizarTexto(texto);
  let partes = /^([a-z]{3})[a-z]*[-/ ](\d{2}|\d{4})$/.exec(valor);
  if (partes && MESES.includes(partes[1])) {
    const ano = partes[2].length === 2 ? `20${partes[2]}` : partes[2];
    return `${ano}-${String(MESES.indexOf(partes[1]) + 1).padStart(2, '0')}`;
  }
  partes = /^(\d{4})-(\d{2})(-\d{2})?/.exec(valor);
  if (partes) return `${partes[1]}-${partes[2]}`;
  partes = /^(?:\d{1,2}\/)?(\d{1,2})\/(\d{4})$/.exec(valor);
  if (partes) return `${partes[2]}-${partes[1].padStart(2, '0')}`;
  return null;
};

// "4301374 - VHD 5830 4K FULL COLOR+" -> "VHD 5830 4K FULL COLOR+"; " - " (vazio) -> ''.
// Quando é um modelo da nossa linha, fica só o modelo (sem o texto descritivo, kit com HD ou "AM").
const nomeDoSubstituto = (texto) => {
  const valor = String(texto || '').replace(/\s+/g, ' ').trim().replace(/^\d{5,}\s*-\s*/, '').trim();
  if (!valor || /^-+$/.test(valor)) return '';
  const produto = interpretarProduto(valor, '');
  if (produto && !produto.remanufaturado) return produto.modelo;
  return valor.split(/\s-\s|,/)[0].trim().slice(0, 80);
};

// Lê a aba e agrupa as versões por modelo da nossa linha: modelos = Map chave -> { tabela, nome, versoes: Map codigo -> versao }
// versao = { codigo, mes: 'AAAA-MM' | null, substitutos: [{ codigo, nome }], indicacoes: [{ codigo, nome }] }
const lerEncerramentos = async (arquivo) => {
  const { colunas, linhas } = await lerPlanilha({
    arquivo,
    colunaNome: COLUNA_NOME,
    colunasUteis: [COLUNA_NOME, COLUNA_RESUMO, COLUNA_CODIGO, COLUNA_DATA, COLUNA_SUBSTITUTO, COLUNA_INDICACAO],
  });
  const titulo = (nome) => colunas.find(coluna => normalizarTexto(coluna) === normalizarTexto(nome));
  const tituloCodigo = titulo(COLUNA_CODIGO);
  const tituloSubstituto = titulo(COLUNA_SUBSTITUTO);
  if (!tituloCodigo || !tituloSubstituto) {
    throw new Error(`O arquivo de Encerramentos não tem as colunas "${COLUNA_CODIGO}" e "${COLUNA_SUBSTITUTO}". Confira se exportou a aba Encerramentos.`);
  }
  const tituloNome = titulo(COLUNA_NOME);
  const tituloResumo = titulo(COLUNA_RESUMO);
  const tituloData = titulo(COLUNA_DATA);
  const tituloIndicacao = titulo(COLUNA_INDICACAO);

  // Uma célula pode ter mais de um substituto (um por linha, ou "4580346 - MHDX 1116 OU 4580347 - ..."):
  // guarda { codigo, nome } de cada um (o código serve para não indicar uma versão do próprio modelo)
  const nomes = (texto) => String(texto || '')
    .split(/\r?\n|\sOU\s(?=\d{5,}\s*-)/i)
    .map(parte => ({ codigo: (/^\s*(\d{5,})\s*-/.exec(parte) || [])[1] || '', nome: nomeDoSubstituto(parte) }))
    .filter(item => item.nome);

  const modelos = new Map();
  // Todos os códigos encerrados (de qualquer produto): é pelo código que a versão da aba Tabela é conferida
  const codigos = new Set();
  for (const linha of linhas) {
    const produto = interpretarProduto(linha[tituloNome], tituloResumo ? linha[tituloResumo] : '');
    const codigo = String(linha[tituloCodigo] || '').trim();
    if (codigo) codigos.add(codigo);
    if (!produto || produto.remanufaturado || !codigo) continue;
    const chave = chaveDoModelo(produto.modelo);
    if (!modelos.has(chave)) modelos.set(chave, { tabela: produto.tabela, nome: produto.modelo, versoes: new Map() });
    modelos.get(chave).versoes.set(codigo, {
      codigo,
      mes: tituloData ? mesDoEncerramento(linha[tituloData]) : null,
      substitutos: nomes(linha[tituloSubstituto]),
      indicacoes: tituloIndicacao ? nomes(linha[tituloIndicacao]) : [],
    });
  }
  if (codigos.size === 0) {
    throw new Error('Nenhum produto encontrado no arquivo de Encerramentos. Confira se exportou a aba certa.');
  }
  return { modelos, codigos, linhasLidas: linhas.length };
};

// Resumo do encerramento de um modelo: o mês da versão encerrada por último e o substituto direto dela.
// Sem substituto direto, usa a "Indicação" da planilha (marcada como indicação). Nunca indica o próprio modelo.
// nomeCadastrado(nome): devolve o nome usado na nossa tabela para o mesmo modelo (ou o próprio nome).
const resumoDoEncerramento = (modelo, nomeCadastrado = (nome) => nome) => {
  const versoes = [...modelo.versoes.values()].sort((a, b) => String(b.mes || '').localeCompare(String(a.mes || '')));
  const mes = versoes.find(versao => versao.mes)?.mes || null;
  const proprio = chaveDoModelo(modelo.nome);
  const deOutros = (lista) => [...new Set(lista
    .filter(({ codigo, nome }) => !modelo.versoes.has(codigo) && chaveDoModelo(nome) !== proprio)
    .map(({ nome }) => nomeCadastrado(nome)))];

  // Primeiro as versões do último encerramento; se nenhuma tiver substituto, as anteriores
  const ultimas = versoes.filter(versao => versao.mes === mes);
  const procurar = (campo) => deOutros(ultimas.flatMap(versao => versao[campo])).join(' / ') ||
    deOutros(versoes.flatMap(versao => versao[campo])).join(' / ');
  const direto = procurar('substitutos');
  const indicacao = direto ? '' : procurar('indicacoes');
  return {
    mes,
    data: mes ? `${mes}-01` : null,
    substituto: direto || (indicacao ? `Indicação: ${indicacao}` : null),
  };
};

// "2026-10" -> "10/2026" (o mesmo formato da coluna phaseout)
const mesParaTexto = (mes) => (mes ? `${mes.slice(5, 7)}/${mes.slice(0, 4)}` : '');

module.exports = { lerEncerramentos, resumoDoEncerramento, mesDoEncerramento, nomeDoSubstituto, mesParaTexto };
