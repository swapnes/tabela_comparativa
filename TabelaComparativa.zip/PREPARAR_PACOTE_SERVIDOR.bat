@echo off
rem Rode NO PC DE TESTES: exporta o banco e monta PACOTE_SERVIDOR\TabelaComparativa para levar ao servidor.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\preparar-pacote.ps1"
echo.
pause
