// =====================================================================
//  REGRAS DA PLANILHA DE PREÇOS — o que é da nossa linha e onde entra.
// =====================================================================
//
// A planilha (Tabela de Preços Distribuição) lista todos os produtos em linha da empresa.
// Um produto é da nossa linha quando a descrição tem uma das siglas abaixo seguida do número do modelo
// (ex.: "Câmera Bullet VIP 1230 B G5, 2MP..." -> modelo "VIP 1230 B G5").

// Ordem importa: siglas maiores primeiro. "exibicao" = como o nome é gravado na tabela.
const SIGLAS = [
  { sigla: 'IMHDX', tabela: 'gravadores', exibicao: 'iMHDX' }, // DVR
  { sigla: 'MHDX', tabela: 'gravadores' },                     // DVR
  { sigla: 'INVD', tabela: 'gravadores', exibicao: 'iNVD' },   // NVD
  { sigla: 'NVD', tabela: 'gravadores' },                      // NVD
  { sigla: 'VIPC', tabela: 'cameras' },                        // câmera IP
  { sigla: 'VIPW', tabela: 'cameras' },                        // câmera IP Wi-Fi
  { sigla: 'VIP', tabela: 'cameras' },                         // câmera IP
  { sigla: 'VLP', tabela: 'cameras' },                         // câmera IP
  { sigla: 'VHD', tabela: 'cameras' },                         // câmera analógica
  { sigla: 'VHL', tabela: 'cameras' },                         // câmera analógica
  { sigla: 'VHC', tabela: 'cameras' },                         // câmera analógica
  { sigla: 'VEX', tabela: 'extensores' },                      // extensores
  { sigla: 'VB', tabela: 'baluns' },                           // baluns (com WP = power balun)
];
// (VTN e TESTER ficaram de fora em 01/10/2026, quando a aba Acessórios virou Baluns e Extensores.)

// Sigla + número do modelo + o que vier até vírgula, ponto e vírgula ou parêntese
const REGEX_MODELO = new RegExp(
  `(?:^|[^A-Za-z0-9])((${SIGLAS.map(s => s.sigla).join('|')})\\s*-?\\s*\\d[^,;()]*)`,
  'i'
);

// Partes da descrição que não fazem parte do modelo:
// kits com HD/SSD ("C/HD 1TB"), versão Manaus, e o começo do texto descritivo
// (07/10/2026, nomes antigos da aba Encerramentos: "NVD 1204 COM HD 1TB", "NVD 1404 C/ 3TB", "VHD 3012 SD C/ SUPORTE",
//  "VIP 7460 IA 4MP COM INTELIGÊNCIA ARTIFICIAL": "C/" e "COM" sempre começam a descrição; "4MP" também)
const REGEX_SUFIXOS = /\s(C\/.*|CHD|COM|\d+\s?MP|C[ÂAâa]MERA|GRAVADOR|MULTI-VIEWER|MANAUS)(\s|$).*$/i;

// Lente no fim do nome antigo ("VHD 1010 B 3.6MM"; com vírgula a descrição já é cortada e sobra "VHD 3120 B 3"):
// a lente não faz parte do modelo
const REGEX_LENTE_NO_FIM = /\s\d+([.,]\d+)?\s?MM$|\s\d$/i;

// Linha Future (outro segmento): modelo com "FT" (ou "F T", erro de digitação que aparece na planilha)
const ehLinhaFuture = (modelo) => /(^|\s)FT(\s|$)/i.test(modelo) || /(^|\s)F\sT$/i.test(modelo);

// Versão remanufaturada: modelo com "REM" (ex.: "MHDX 1108-C REM"). Não entra na tabela.
const ehRemanufaturado = (modelo) => /(^|\s)REM(\s|$)/i.test(modelo);

// Extrai o modelo de um texto da planilha.
// Retorna { modelo, tabela, future, remanufaturado } ou null (não é da nossa linha).
const extrairModelo = (texto) => {
  const encontrado = REGEX_MODELO.exec(String(texto || ''));
  if (!encontrado) return null;

  const sigla = SIGLAS.find(item => item.sigla === encontrado[2].toUpperCase());

  let modelo = encontrado[1].split(/\s-|-\s/)[0];       // corta em " - " (começo da descrição)
  modelo = modelo.replace(REGEX_SUFIXOS, '');
  modelo = modelo.replace(/\s+/g, ' ').trim().replace(/[.\-\s]+$/, '').trim();
  modelo = modelo.replace(REGEX_LENTE_NO_FIM, '').trim();
  modelo = modelo.replace(/\sAM$/i, '');                // "AM" = fabricado em Manaus, mesmo modelo
  modelo = modelo.toUpperCase();
  if (sigla.exibicao) {
    modelo = sigla.exibicao + modelo.slice(sigla.sigla.length);
  }

  // "VHD 1220 D - GERAÇÃO 9 - CÂMERA..." -> "VHD 1220 D G9" (a geração faz parte do modelo)
  const geracao = /GERA[ÇC][ÃA]O\s*(\d+)/i.exec(encontrado[1]);
  if (geracao && !/(^|\s)G\d+(\s|$)/i.test(modelo)) {
    modelo = `${modelo} G${geracao[1]}`;
  }

  modelo = NOMES_DO_DATASHEET[modelo] || modelo;

  return { modelo, tabela: sigla.tabela, future: ehLinhaFuture(modelo), remanufaturado: ehRemanufaturado(modelo) };
};

// Modelos que a planilha escreve diferente do datasheet: na tabela vale o nome do datasheet
// (pedido em 01/10/2026; sem isso a importação voltaria o nome ou mandaria para phaseout)
// "VEX 3004 HDMI" é o "VEX 3004 HDMI MULTI-VIEWER" (código 4780039) sem o sufixo; até 28/10/2026 virava o
// VEX 3004 SWITCH (4780044), outro produto, e o Multi-viewer não aparecia no phaseout
const NOMES_DO_DATASHEET = {
  'VEX 3004 HDMI': 'VEX 3004 MULTI-VIEWER',
  'VEX 3120 G2 4K': 'VEX 3120 HDMI G2 4K',
};

// Procura o modelo na descrição e, se não achar, no resumo
// Quando o resumo traz a geração que falta na descrição ("VB 503 B" / "VB 503 B G2"), vale o resumo
const interpretarProduto = (descricao, resumo) => {
  const daDescricao = extrairModelo(descricao);
  const doResumo = extrairModelo(resumo);
  if (daDescricao && doResumo && doResumo.modelo.startsWith(`${daDescricao.modelo} `) &&
      /^ G\d+$/.test(doResumo.modelo.slice(daDescricao.modelo.length))) {
    return doResumo;
  }
  return daDescricao || doResumo;
};

// Palavras do modelo em forma padronizada, para comparar nomes escritos de jeitos diferentes:
// - "FULL COLOR +" / "FULL COLOR+" / "FC +" = "FC+"; "FULL COLOR" = "FC"; "SUPER COLOR" = "SC"; "DUAL COLOR" = "DC"
// - "B" (bullet) é ignorado: câmera sem "D" já é bullet ("VHD 1220 B FC" = "VHD 1220 FC"). "D" (dome) conta.
const tokensDoModelo = (nome) => String(nome ?? '')
  .toUpperCase()
  .replace(/-/g, ' ')
  .replace(/FULL\s*COLOR\s*\+/g, 'FC+')
  .replace(/FULL\s*COLOR/g, 'FC')
  .replace(/SUPER\s*COLOR/g, 'SC')
  .replace(/DUAL\s*COLOR\s*\+/g, 'DC+')
  .replace(/DUAL\s*COLOR/g, 'DC')
  .replace(/\s+\+/g, '+')
  .split(/\s+/)
  .filter(token => token && token !== 'B');

// Chave usada para comparar nomes: palavras padronizadas, só letras, números e "+".
// "MHDX 1108-C", "mhdx 1108 c" e "MHDX1108C" viram a mesma chave; "VHD 3240 Full Color +" = "VHD 3240 FC+".
const chaveDoModelo = (nome) => tokensDoModelo(nome).join('').replace(/[^A-Z0-9+]/g, '');

// Palavras que indicam só uma variação do mesmo equipamento (mesmas especificações técnicas)
const CORES = ['BLACK', 'PRETA', 'PRETO', 'BRANCA', 'BRANCO', 'WHITE'];
const VARIACOES = [...CORES, 'MIC', 'DUAL', 'AUDIO'];

// Compara dois nomes: é o mesmo equipamento (ou uma variação dele)? Ex.: "VIP 1230 B G4" e "VIP 1230 B BLACK G4".
// Regras (de propósito rígidas, para não misturar produtos diferentes):
// - mesma sigla (primeira palavra);
// - as partes com número são exatamente as mesmas (1230, G4, 4K...): gerações diferentes nunca combinam;
// - um nome contém todas as palavras do outro, e as palavras a mais são só variações (cor, MIC, DUAL AUDIO).
//   "FC+" a mais só é aceito nas câmeras DUAL AUDIO (que já são full color). Nunca aceita palavras trocadas (D ≠ Z).
// Retorna { nota (0 a 1; 0 = não combina), soCor (a diferença é só de cor) }.
const compararModelos = (nomeA, nomeB) => {
  const naoCombina = { nota: 0, soCor: false };
  const a = tokensDoModelo(nomeA);
  const b = tokensDoModelo(nomeB);
  if (a.length === 0 || b.length === 0 || a[0] !== b[0]) return naoCombina;

  const comNumero = (tokens) => tokens.filter(token => /\d/.test(token)).sort().join(' ');
  if (comNumero(a) !== comNumero(b)) return naoCombina;

  const letrasA = new Set(a.filter(token => !/\d/.test(token)));
  const letrasB = new Set(b.filter(token => !/\d/.test(token)));
  const [menor, maior] = letrasA.size <= letrasB.size ? [letrasA, letrasB] : [letrasB, letrasA];
  for (const token of menor) {
    if (!maior.has(token)) return naoCombina;
  }

  const aMais = [...maior].filter(token => !menor.has(token));
  const variacaoAceita = (token) => VARIACOES.includes(token) || (token === 'FC+' && menor.has('DUAL'));
  if (!aMais.every(variacaoAceita)) return naoCombina;

  const todos = new Set([...a, ...b]);
  const comuns = a.filter(token => b.includes(token)).length;
  return { nota: comuns / todos.size, soCor: aMais.length > 0 && aMais.every(token => CORES.includes(token)) };
};

const semelhancaEntreModelos = (nomeA, nomeB) => compararModelos(nomeA, nomeB).nota;

module.exports = { SIGLAS, extrairModelo, interpretarProduto, chaveDoModelo, ehLinhaFuture, ehRemanufaturado, compararModelos, semelhancaEntreModelos };
