@echo off
setlocal
title Tabela Comparativa
rem ==================================================================
rem  Liga a Tabela Comparativa (site + painel admin) e abre no navegador.
rem  Funciona em qualquer pasta: usa o lugar onde este arquivo esta.
rem  Para desligar: feche esta janela.
rem ==================================================================

set "PASTA=%~dp0"

rem No servidor a tabela ja roda sozinha (INSTALAR_NO_SERVIDOR.bat): so abre o navegador
schtasks /query /tn "Tabela Comparativa" >nul 2>nul
if not errorlevel 1 (
  set "PORTA=3777"
  for /f "tokens=1,* delims==" %%a in ('findstr /b "PORTA=" "%PASTA%back\.env" 2^>nul') do set "PORTA=%%b"
  call echo A tabela ja roda como servico neste PC: abrindo http://localhost:%%PORTA%%
  call start "" http://localhost:%%PORTA%%
  exit /b
)

rem Node.js: usa o do PATH ou o da instalacao padrao
set "NODE=node"
where node >nul 2>nul
if errorlevel 1 set "NODE=C:\Program Files\nodejs\node.exe"
if not exist "%NODE%" if "%NODE%" NEQ "node" (
  echo ERRO: Node.js nao encontrado. Instale em https://nodejs.org e rode de novo.
  pause
  exit /b 1
)

if not exist "%PASTA%back\node_modules" (
  echo Instalando dependencias do sistema, so na primeira vez...
  pushd "%PASTA%back"
  call npm install --omit=dev
  popd
)

if not exist "%PASTA%front\build\index.html" (
  echo ERRO: o site nao foi gerado. Rode "npm run build" na pasta front.
  pause
  exit /b 1
)

rem Porta definida no back\.env - padrao 3777
set "PORTA=3777"
for /f "tokens=1,* delims==" %%a in ('findstr /b "PORTA=" "%PASTA%back\.env" 2^>nul') do set "PORTA=%%b"

echo.
echo  Tabela Comparativa: http://localhost:%PORTA%
echo  Para desligar, feche esta janela.
echo.
start "" /min cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:%PORTA%"
cd /d "%PASTA%back"
"%NODE%" index.js
pause
