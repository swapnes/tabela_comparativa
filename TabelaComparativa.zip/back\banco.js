// Cria as tabelas do sistema, se ainda não existirem (roda ao iniciar o servidor).
// Num banco que já tem a tabela antiga (servidor do trabalho), nada existente é alterado:
// "CREATE TABLE IF NOT EXISTS" só cria o que falta. Num banco novo (PC de testes), cria tudo vazio.
const pool = require('./db');

// Colunas das tabelas de equipamentos (as mesmas da tabela antiga). Todas texto, menos "data".
// (As colunas do laboratório, "ip" e "tem_no_lab", foram retiradas em 30/09/2026.)
const COLUNAS_COMUNS = ['nome', 'phaseout', 'descontinuado', 'link', 'metodos_de_recuperacao', 'interface'];

const COLUNAS_CAMERAS = [
  'autotracking', 'contagem_pessoas', 'deteccao_estacionamento', 'deteccao_facial', 'deteccao_inteligente',
  'inteligencia_perimetral', 'mapa_calor', 'compressao_video', 'formato_video', 'tecnologia_video', 'resolucao_video',
  'angulo_abertura', 'full_color', 'full_color_inteligente', 'ir', 'lente', 'starlight', 'zoom_optico', 'zoom_varifocal',
  'fluxo_video', 'throughput', 'throughput_wifi', 'poe', 'quantidade_de_streams', 'wifi', 'protocolos', 'alarme', 'case',
  'cores', 'temperatura_de_operacao', 'microfone', 'microsd', 'protecao', 'umidade_relativa_de_operacao',
];

const COLUNAS_GRAVADORES = [
  'entradas', 'entrada_de_audio', 'saida_de_audio', 'audio_bidirecional', 'camera_com_audio', 'compressao_audio',
  'saida_de_video', 'resolucao_saida_de_video_hdmi', 'resolucao_saida_de_video_vga', 'resolucao_saida_bnc',
  'resolucao_entrada_hdcvi', 'resolucao_entrada_hdtvi', 'resolucao_entrada_ahd', 'resolucao_entrada_analogica',
  'resolucao_entrada_ip', 'hdcvi_stream_principal', 'hdtvi_stream_principal', 'ahd_stream_principal',
  'analogico_stream_principal', 'ip_stream_principal', 'hdcvi_stream_extra', 'hdtvi_stream_extra', 'ahd_stream_extra',
  'analogico_stream_extra', 'ip_stream_extra', 'compressao_video', 'bit_rate_canal', 'interface_usb', 'interface_rs485',
  'interface_rs232', 'entrada_alarme', 'saida_alarme', 'multibox', 'quantidade_de_hd', 'capacidade_do_hd', 'saida_spot',
  'adaptador_usb_wireless', 'entrada_de_rede', 'throughput', 'funcoes_protocolos', 'conexao_simultaneas', 'pos',
  'compatibilidade_fc_inteligente', 'leitura_placa', 'deteccao_inteligente', 'deteccao_face_capacidade',
  'reconhecimento_facial_capacidade', 'reconhecimento_facial_processamento', 'inteligencia_perimetral_capacidade',
  'inteligencia_perimetral_classificacao', 'analise_comportamental', 'aglomeracao', 'contagem_pessoas', 'mapa_calor',
  'bateria', 'cloud',
];

const criarTabelaDeEquipamentos = (tabela, colunas) => {
  const definicoes = [...COLUNAS_COMUNS, ...colunas].map(coluna => `"${coluna}" TEXT`);
  definicoes.splice(1, 0, '"data" DATE');
  return pool.query(`CREATE TABLE IF NOT EXISTS ${tabela} (${definicoes.join(', ')});`);
};

const prepararBanco = async () => {
  await criarTabelaDeEquipamentos('cameras', COLUNAS_CAMERAS);
  await criarTabelaDeEquipamentos('gravadores', COLUNAS_GRAVADORES);

  // Baluns (VB) e extensores (VEX): cada um na sua tabela, com as suas características técnicas
  // (criadas pelo painel ou pelos datasheets). Até 01/10/2026 os dois ficavam juntos em "acessorios".
  for (const tabela of ['baluns', 'extensores']) {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ${tabela} (
        nome TEXT NOT NULL,
        phaseout TEXT,
        data DATE,
        link TEXT,
        metodos_de_recuperacao TEXT
      );
    `);
  }

  // Substituto direto do equipamento descontinuado (aba Encerramentos da planilha ou digitado no painel), desde 05/10/2026
  for (const tabela of ['cameras', 'gravadores', 'baluns', 'extensores']) {
    await pool.query(`ALTER TABLE ${tabela} ADD COLUMN IF NOT EXISTS substituto TEXT`);
  }

  // Configuração das características (colunas/filtros) feita pelo painel do admin:
  // - personalizada = true: característica criada pelo painel (a coluna foi criada no banco pelo sistema)
  // - personalizada = false: ajuste de uma característica original (nome, categoria ou escondida)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS colunas_personalizadas (
      id SERIAL PRIMARY KEY,
      tabela TEXT NOT NULL,
      coluna TEXT NOT NULL,
      rotulo TEXT NOT NULL,
      categoria TEXT,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      UNIQUE (tabela, coluna)
    );
  `);
  await pool.query(`
    ALTER TABLE colunas_personalizadas
      ADD COLUMN IF NOT EXISTS oculta BOOLEAN NOT NULL DEFAULT false,
      ADD COLUMN IF NOT EXISTS personalizada BOOLEAN NOT NULL DEFAULT true;
  `);

  // Alertas mostrados no painel do admin (ex.: preencher dados técnicos de um equipamento novo)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS alertas (
      id SERIAL PRIMARY KEY,
      tipo TEXT NOT NULL,
      tabela TEXT,
      nome TEXT,
      mensagem TEXT NOT NULL,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      resolvido_em TIMESTAMPTZ
    );
  `);

  // Histórico de alterações (para consultar e desfazer): cópia dos dados antes e depois de cada mudança
  // - origem: 'admin' (painel), 'planilha' (aplicação da planilha) ou 'desfazer' (um "desfazer" também é registrado)
  // - lote: agrupa as mudanças de uma mesma aplicação da planilha (dá para desfazer todas de uma vez)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS historico (
      id SERIAL PRIMARY KEY,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      acao TEXT NOT NULL,
      tabela TEXT,
      nome TEXT,
      descricao TEXT NOT NULL,
      antes JSONB,
      depois JSONB,
      origem TEXT NOT NULL DEFAULT 'admin',
      lote TEXT,
      desfeito_em TIMESTAMPTZ,
      desfeito_por INTEGER
    );
  `);
  await pool.query(`CREATE INDEX IF NOT EXISTS historico_lote_idx ON historico (lote)`);

  // Histórico das análises/aplicações da planilha
  await pool.query(`
    CREATE TABLE IF NOT EXISTS sincronizacoes (
      id SERIAL PRIMARY KEY,
      iniciada_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      finalizada_em TIMESTAMPTZ,
      modo TEXT NOT NULL,
      sucesso BOOLEAN,
      resumo JSONB
    );
  `);

  // Selo "Novo" escolhido pelo admin (página Produtos): mostrar = true marca como novo até "ate";
  // mostrar = false tira o selo automático (o que entrou na tabela nos últimos 30 dias). Sem linha = automático.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS selo_novo (
      tabela TEXT NOT NULL,
      nome TEXT NOT NULL,
      mostrar BOOLEAN NOT NULL,
      desde DATE NOT NULL DEFAULT CURRENT_DATE,
      ate DATE,
      alterado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (tabela, nome)
    );
  `);

  await separarAcessorios();
  // Correções de dados que vieram com a atualização do sistema (rodam uma vez só; ver correcoes.js)
  await require('./correcoes').aplicarCorrecoes();
};

// Migração (01/10/2026): a antiga tabela "acessorios" vira "baluns" (VB) e "extensores" (VEX).
// Os equipamentos passam com todos os dados (e as características criadas pelo painel); o histórico,
// os alertas e a configuração das características passam a apontar para a tabela nova.
// O que não for VB nem VEX (TESTER, VTN...) sai da tabela, mas fica guardado no histórico (origem "sistema").
// Tudo numa transação: se algo falhar, nada muda. Sem a tabela "acessorios", não faz nada.
const DESTINOS_DOS_ACESSORIOS = [
  { tabela: 'baluns', padrao: '^VB' },
  { tabela: 'extensores', padrao: '^VEX' },
];

const separarAcessorios = async () => {
  const existe = (await pool.query(`SELECT to_regclass('acessorios') IS NOT NULL AS existe`)).rows[0].existe;
  if (!existe) return;

  const cliente = await pool.connect();
  try {
    await cliente.query('BEGIN');
    const colunasDe = async (tabela) => (await cliente.query(
      `SELECT a.attname AS coluna, format_type(a.atttypid, a.atttypmod) AS tipo
       FROM pg_attribute a WHERE a.attrelid = $1::regclass AND a.attnum > 0 AND NOT a.attisdropped ORDER BY a.attnum`,
      [tabela]
    )).rows;
    const colunasAcessorios = await colunasDe('acessorios');

    for (const { tabela, padrao } of DESTINOS_DOS_ACESSORIOS) {
      // Características criadas pelo painel em acessórios passam a existir também na tabela nova
      const existentes = (await colunasDe(tabela)).map(item => item.coluna);
      for (const { coluna, tipo } of colunasAcessorios) {
        if (!existentes.includes(coluna)) {
          await cliente.query(`ALTER TABLE ${tabela} ADD COLUMN "${coluna.replace(/"/g, '""')}" ${tipo}`);
        }
      }
      const lista = colunasAcessorios.map(({ coluna }) => `"${coluna.replace(/"/g, '""')}"`).join(', ');
      await cliente.query(
        `INSERT INTO ${tabela} (${lista}) SELECT ${lista} FROM acessorios a
         WHERE a.nome ~* $1 AND NOT EXISTS (SELECT 1 FROM ${tabela} t WHERE t.nome = a.nome)`,
        [padrao]
      );
      await cliente.query(`DELETE FROM acessorios WHERE nome ~* $1`, [padrao]);
      await cliente.query(`UPDATE historico SET tabela = $1 WHERE tabela = 'acessorios' AND nome ~* $2`, [tabela, padrao]);
      await cliente.query(`UPDATE alertas SET tabela = $1 WHERE tabela = 'acessorios' AND nome ~* $2`, [tabela, padrao]);
      await cliente.query(
        `INSERT INTO colunas_personalizadas (tabela, coluna, rotulo, categoria, oculta, personalizada)
         SELECT $1, coluna, rotulo, categoria, oculta, personalizada FROM colunas_personalizadas WHERE tabela = 'acessorios'
         ON CONFLICT (tabela, coluna) DO NOTHING`,
        [tabela]
      );
    }

    // O que sobrou (TESTER, VTN...): guarda a cópia completa no histórico e tira da tabela
    const sobras = (await cliente.query(`SELECT * FROM acessorios`)).rows;
    for (const linha of sobras) {
      await cliente.query(
        `INSERT INTO historico (acao, tabela, nome, descricao, antes, origem) VALUES ('remover', 'acessorios', $1, $2, $3, 'sistema')`,
        [linha.nome, `Retirado: ${linha.nome} (a aba Acessórios virou Baluns e Extensores)`, JSON.stringify(linha)]
      );
    }
    await cliente.query(`UPDATE alertas SET resolvido_em = now() WHERE tabela = 'acessorios' AND resolvido_em IS NULL`);
    await cliente.query(`DELETE FROM colunas_personalizadas WHERE tabela = 'acessorios'`);
    await cliente.query(`DROP TABLE acessorios`);
    await cliente.query('COMMIT');
    console.log(`Acessórios separados em baluns e extensores (${sobras.length} retirado(s) e guardado(s) no histórico).`);
  } catch (err) {
    await cliente.query('ROLLBACK').catch(() => {});
    console.log('Erro ao separar os acessórios (nada foi alterado):', err.message);
  } finally {
    cliente.release();
  }
};

module.exports = { prepararBanco };
