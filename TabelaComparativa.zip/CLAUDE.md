# Instrucoes do projeto (carregadas automaticamente em toda sessao)

@CLAUDE.coding.md

## Projeto
- Responder em portugues.
- README.md e o diario do projeto: ler as secoes relevantes antes de mexer e atualizar a cada mudanca.
- Producao: servidor 10.1.45.193:49152 (banco oficial la). Este PC e de testes.
- Testar sempre numa copia (tabela_teste), nunca no banco real `tabela`. Nao imprimir o back/.env.
- Dados tecnicos: so o que esta escrito no datasheet. Nunca inventar dados nem links.
- Mudanca de dados para o servidor: back/correcoes.js. Entrega: PREPARAR_ATUALIZACAO.bat + PACOTE_ATUALIZACAO\TabelaComparativa.zip.
