﻿# Roda NO PC DE TESTES: exporta o banco e monta a pasta PACOTE_SERVIDOR\TabelaComparativa para levar ao servidor.
. "$PSScriptRoot\comum.ps1"
$destino = Join-Path $Pasta 'PACOTE_SERVIDOR\TabelaComparativa'

Write-Host '== Exportando o banco deste PC'
$pgDump = Achar-Postgres 'pg_dump.exe'
if (-not $pgDump) { throw 'pg_dump.exe não encontrado.' }
$b = Ler-Banco
$env:PGPASSWORD = $b.Senha
New-Item -ItemType Directory -Force (Join-Path $PSScriptRoot 'banco') | Out-Null
$arquivo = Join-Path $PSScriptRoot 'banco\tabela.sql'
$bruto = "$arquivo.tmp"
& $pgDump -U $b.Usuario -h $b.Servidor -p $b.Porta -d $b.Banco --no-owner --no-privileges -f $bruto
if ($LASTEXITCODE -ne 0) { throw 'Falha ao exportar o banco.' }
# Tira comandos que só existem no PostgreSQL 17 (o servidor pode ter versão mais antiga)
$linhas = [IO.File]::ReadAllLines($bruto) | Where-Object { $_ -notmatch '^SET transaction_timeout' -and $_ -notmatch '^\\(un)?restrict ' }
[IO.File]::WriteAllLines($arquivo, $linhas, (New-Object Text.UTF8Encoding $false))
Remove-Item $bruto
Write-Host "   OK  $arquivo ($([math]::Round((Get-Item $arquivo).Length / 1MB, 1)) MB)"

Write-Host '== Montando a pasta do pacote'
if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
& robocopy $Pasta $destino /E /NFL /NDL /NJH /NJS /NP `
  /XD (Join-Path $Pasta 'PACOTE_SERVIDOR') (Join-Path $Pasta 'PACOTE_ATUALIZACAO') (Join-Path $Pasta 'front\node_modules') (Join-Path $Pasta 'datasheets') (Join-Path $Pasta 'back\dados\logs') (Join-Path $Pasta 'back\dados\backups') `
  /XF 'tabela_antiga.sql' '*.csv.tmp' 'backup-antes-*.sql' 'Tabela de Pre*.csv' | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Falha ao copiar (robocopy $LASTEXITCODE)." }
$tamanho = [math]::Round(((Get-ChildItem $destino -Recurse -File | Measure-Object Length -Sum).Sum) / 1MB, 1)
Write-Host "   OK  $destino ($tamanho MB)"
Write-Host ''
Write-Host 'Leve a pasta TabelaComparativa para o servidor (ex.: C:\TabelaComparativa) e rode INSTALAR_NO_SERVIDOR.bat como administrador.' -ForegroundColor Green
