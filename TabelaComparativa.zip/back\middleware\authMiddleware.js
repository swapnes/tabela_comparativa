const jwt = require('jsonwebtoken');
const config = require('../config');

// Login vale 7 dias e é renovado enquanto o admin usa o painel (a partir de 12 h de uso,
// cada resposta traz um token novo no cabeçalho X-Novo-Token, que o site guarda sozinho).
const VALIDADE = '7d';
const RENOVAR_APOS_SEGUNDOS = 12 * 60 * 60;

// Libera a rota só para quem fez login: espera o cabeçalho "Authorization: Bearer <token>"
function authenticateToken(req, res, next) {
  const cabecalho = req.headers.authorization || '';
  const token = cabecalho.startsWith('Bearer ') ? cabecalho.slice(7) : null;

  if (!token) {
    return res.status(401).send('Acesso negado. Faça login.');
  }

  jwt.verify(token, config.jwtSecret, (err, usuario) => {
    if (err) {
      return res.status(401).send('Login expirado. Entre novamente.');
    }
    req.user = usuario;
    if (Date.now() / 1000 - usuario.iat > RENOVAR_APOS_SEGUNDOS) {
      res.set('X-Novo-Token', jwt.sign({ usuario: usuario.usuario }, config.jwtSecret, { expiresIn: VALIDADE }));
    }
    next();
  });
}

authenticateToken.VALIDADE = VALIDADE;
module.exports = authenticateToken;
