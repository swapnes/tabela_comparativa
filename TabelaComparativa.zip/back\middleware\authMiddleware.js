const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const config = require('../config');

// Login vale 12 horas e é renovado enquanto o admin usa o painel (depois de 1 h, cada resposta traz um token novo no
// cabeçalho X-Novo-Token, que o site guarda sozinho): parado por 12 h, pede a senha de novo (antes eram 7 dias).
// O token leva uma marca do usuário e da senha do back/.env: trocou a senha, todo login antigo deixa de valer.
const VALIDADE = '12h';
const RENOVAR_APOS_SEGUNDOS = 60 * 60;
const MARCA_DO_LOGIN = crypto.createHash('sha256').update(`${config.adminUsuario}\n${config.adminSenha}`).digest('hex').slice(0, 16);

const assinar = (usuario) => jwt.sign({ usuario, v: MARCA_DO_LOGIN }, config.jwtSecret, { algorithm: 'HS256', expiresIn: VALIDADE });

// Libera a rota só para quem fez login: espera o cabeçalho "Authorization: Bearer <token>"
function authenticateToken(req, res, next) {
  const cabecalho = req.headers.authorization || '';
  const token = cabecalho.startsWith('Bearer ') ? cabecalho.slice(7) : null;

  if (!token) {
    return res.status(401).send('Acesso negado. Faça login.');
  }

  jwt.verify(token, config.jwtSecret, { algorithms: ['HS256'] }, (err, usuario) => {
    if (err || !config.adminSenha || usuario.v !== MARCA_DO_LOGIN || usuario.usuario !== config.adminUsuario) {
      return res.status(401).send('Login expirado. Entre novamente.');
    }
    req.user = usuario;
    if (Date.now() / 1000 - usuario.iat > RENOVAR_APOS_SEGUNDOS) {
      res.set('X-Novo-Token', assinar(usuario.usuario));
    }
    next();
  });
}

authenticateToken.assinar = assinar;
module.exports = authenticateToken;
