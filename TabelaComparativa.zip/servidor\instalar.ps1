﻿# Instala a Tabela Comparativa como serviço deste PC (roda sozinha ao ligar, sem janela aberta).
# Chamado pelo INSTALAR_NO_SERVIDOR.bat (como administrador). Pode rodar de novo sem problema.
param([int]$PortaSite = 49152)
. "$PSScriptRoot\comum.ps1"

function Passo($texto) { Write-Host ''; Write-Host "== $texto" -ForegroundColor Cyan }
function Ok($texto) { Write-Host "   OK  $texto" -ForegroundColor Green }
function Aviso($texto) { Write-Host "   !!  $texto" -ForegroundColor Yellow }

Exigir-Administrador
Write-Host "Tabela Comparativa - instalação no servidor ($Pasta)"
if ($Pasta -match 'OneDrive') { Aviso 'A pasta está dentro do OneDrive. Recomendado: copiar para C:\TabelaComparativa e instalar de lá.' }

Passo 'Node.js'
$node = "$env:ProgramFiles\nodejs\node.exe"
if (-not (Test-Path $node)) { $c = Get-Command node -ErrorAction SilentlyContinue; if ($c) { $node = $c.Source } else { throw 'Node.js não encontrado. Instale a versão LTS de https://nodejs.org (para todos os usuários) e rode de novo.' } }
Ok "$node ($(& $node --version))"

Passo 'Arquivos do sistema'
if (-not (Test-Path (Join-Path $Pasta 'front\build\index.html'))) { throw 'Falta front\build (o site). Copie a pasta inteira gerada pelo PREPARAR_PACOTE_SERVIDOR.bat.' }
if (-not (Test-Path (Join-Path $Pasta 'back\node_modules'))) {
  Aviso 'back\node_modules não encontrado: instalando (precisa de internet)...'
  Push-Location (Join-Path $Pasta 'back'); & "$(Split-Path $node)\npm.cmd" install --omit=dev; Pop-Location
}
if (-not (Test-Path $Env)) { Copy-Item (Join-Path $Pasta 'back\.env.example') $Env; Aviso 'back\.env criado a partir do exemplo: confira usuário/senha do admin e DATABASE_URL.' }
Ok 'site, programa e back\.env presentes'

Passo "Porta $PortaSite"
Gravar-Env 'PORTA' $PortaSite
$ocupada = Get-NetTCPConnection -LocalPort $PortaSite -State Listen -ErrorAction SilentlyContinue
if ($ocupada) {
  $proc = Get-Process -Id $ocupada[0].OwningProcess -ErrorAction SilentlyContinue
  if ($proc -and $proc.Name -ne 'node') { throw "A porta $PortaSite já está em uso por '$($proc.Name)'. Escolha outra: INSTALAR_NO_SERVIDOR.bat 49153" }
}
Ok "PORTA=$PortaSite gravada no back\.env"

Passo 'PostgreSQL'
$servicoPg = Get-Service 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $servicoPg) { throw 'Serviço do PostgreSQL não encontrado neste PC.' }
Set-Service $servicoPg.Name -StartupType Automatic
if ($servicoPg.Status -ne 'Running') { Start-Service $servicoPg.Name }
& sc.exe failure $servicoPg.Name reset= 86400 actions= restart/10000/restart/10000/restart/60000 | Out-Null
Ok "$($servicoPg.Name): automático, rodando e religa sozinho se cair"

$psql = Achar-Postgres 'psql.exe'
if (-not $psql) { throw 'psql.exe não encontrado (C:\Program Files\PostgreSQL\<versão>\bin).' }
$b = Ler-Banco
$env:PGPASSWORD = $b.Senha
$conexao = @('-U', $b.Usuario, '-h', $b.Servidor, '-p', $b.Porta)
$existe = (& $psql @conexao -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '$($b.Banco)'")
if ($LASTEXITCODE -ne 0) { throw "Não consegui entrar no PostgreSQL com o usuário '$($b.Usuario)'. Confira a senha no DATABASE_URL do back\.env." }
$arquivoBanco = Join-Path $PSScriptRoot 'banco\tabela.sql'
if ("$existe".Trim() -ne '1') {
  if (-not (Test-Path $arquivoBanco)) { throw "O banco '$($b.Banco)' não existe e não há servidor\banco\tabela.sql para importar." }
  Write-Host "   Criando o banco '$($b.Banco)' e importando os dados (servidor\banco\tabela.sql)..."
  & $psql @conexao -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE `"$($b.Banco)`" ENCODING 'UTF8' TEMPLATE template0" | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar o banco.' }
  & $psql @conexao -d $b.Banco -q -v ON_ERROR_STOP=1 -f $arquivoBanco | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Falha ao importar o banco (nada foi apagado; veja a mensagem acima).' }
  Ok "banco '$($b.Banco)' criado e importado"
} else {
  Ok "banco '$($b.Banco)' já existe: mantido como está (nada é sobrescrito)"
}
$contagem = (& $psql @conexao -d $b.Banco -tAc "SELECT (SELECT count(*) FROM cameras) || ' cameras, ' || (SELECT count(*) FROM gravadores) || ' gravadores, ' || (SELECT count(*) FROM baluns) || ' baluns, ' || (SELECT count(*) FROM extensores) || ' extensores'")
Ok "no banco: $contagem"

Passo 'Firewall (acesso pela rede)'
Get-NetFirewallRule -DisplayName $NomeRegraFirewall -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $NomeRegraFirewall -Direction Inbound -Protocol TCP -LocalPort $PortaSite -Action Allow -Profile Any | Out-Null
Ok "entrada liberada na porta TCP $PortaSite"

Passo 'Ligar sozinha com o Windows'
Parar-Tabela
$configuracoes = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
  -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
$sistema = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$aoLigar = New-ScheduledTaskTrigger -AtStartup
$aoLigar.Delay = 'PT20S'
$acao = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$(Join-Path $PSScriptRoot 'servico.cmd')`"" -WorkingDirectory (Join-Path $Pasta 'back')
Register-ScheduledTask -TaskName $NomeTarefa -Action $acao -Trigger $aoLigar -Principal $sistema -Settings $configuracoes `
  -Description 'Tabela Comparativa Intelbras (site na rede). Liga ao iniciar o Windows e religa sozinha se cair.' -Force | Out-Null
Ok "tarefa '$NomeTarefa' (ao ligar o PC, como SYSTEM, sem janela)"

$diario = New-ScheduledTaskTrigger -Daily -At '12:30'
$acaoBackup = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $PSScriptRoot 'backup.ps1')`""
$configBackup = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName $NomeTarefaBackup -Action $acaoBackup -Trigger $diario -Principal $sistema -Settings $configBackup `
  -Description 'Cópia diária do banco da Tabela Comparativa (back\dados\backups, guarda 30 dias).' -Force | Out-Null
Ok "tarefa '$NomeTarefaBackup' (todo dia 12:30; se o PC estiver desligado, roda quando ligar)"

Passo 'Não dormir'
& powercfg /change standby-timeout-ac 0
& powercfg /change hibernate-timeout-ac 0
Ok 'suspensão e hibernação desligadas (na tomada)'

Passo 'Ligando agora'
Start-ScheduledTask -TaskName $NomeTarefa
if (Esperar-Tabela $PortaSite 90) {
  Ok 'a tabela respondeu'
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'backup.ps1') | Out-Null
  Ok 'primeiro backup feito em back\dados\backups'
  Write-Host ''
  Write-Host 'PRONTO! Endereços para o pessoal acessar:' -ForegroundColor Green
  Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
    ForEach-Object { Write-Host "   http://$($_.IPAddress):$PortaSite" -ForegroundColor Green }
  Write-Host '   (neste PC: http://localhost:' -NoNewline; Write-Host "$PortaSite)"
} else {
  Aviso "A tabela não respondeu em 90 s. Veja o registro: $(Join-Path $Pasta 'back\dados\logs\servidor.log')"
}
