@echo off
rem Rode NO PC DE TESTES depois de mudar o sistema: monta PACOTE_ATUALIZACAO\TabelaComparativa
rem (so programa e site; sem .env, sem dados, sem banco). No servidor: copiar por cima e REINICIAR_TABELA.bat.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\preparar-atualizacao.ps1"
echo.
pause
