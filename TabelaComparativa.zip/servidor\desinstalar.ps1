﻿# Para a Tabela Comparativa e tira do início automático. NÃO apaga o banco, os dados nem a pasta.
. "$PSScriptRoot\comum.ps1"
Exigir-Administrador
Parar-Tabela
Unregister-ScheduledTask -TaskName $NomeTarefa -Confirm:$false -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $NomeTarefaBackup -Confirm:$false -ErrorAction SilentlyContinue
Get-NetFirewallRule -DisplayName $NomeRegraFirewall -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Write-Host 'Tabela parada e retirada do início automático. Banco e arquivos continuam intactos.' -ForegroundColor Green
