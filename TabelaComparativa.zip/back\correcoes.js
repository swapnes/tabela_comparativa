// Correções de dados que acompanham uma atualização do sistema.
// Rodam sozinhas, UMA vez, no banco onde a tabela estiver (ex.: o servidor), ao ligar a tabela.
// Segurança:
// - cada valor só é trocado se ainda estiver com o valor errado conhecido ("de");
//   se alguém já corrigiu pelo painel, aquele item fica como está;
// - tudo vai para o Histórico (lote "correcao:<id>", dá para desfazer tudo de uma vez);
// - a tabela "correcoes_aplicadas" guarda o que já rodou (não roda de novo).
const pool = require('./db');

const GENERICO = 'https://www.intelbras.com/pt-br/seguranca-eletronica';
const SITE = 'https://www.intelbras.com/pt-br/';

// Links conferidos no site da Intelbras em 03/10/2026 (cada página aberta no navegador)
const link = (tabela, nome, de, para) => ({ tabela, nome, coluna: 'link', de: [].concat(de), para: SITE + para });

// Característica a excluir (os valores ficam guardados no Histórico; o Desfazer recria a coluna com eles)
const excluirColuna = (tabela, coluna, rotulo) => ({ tipo: 'excluirColuna', tabela, coluna, nome: rotulo, rotulo });

const CORRECOES = [
  {
    id: '2026-10-03-links',
    descricao: 'Links das páginas dos produtos conferidos no site da Intelbras',
    itens: [
      // Estavam na página genérica "Segurança eletrônica" (links enviados pelo Gabriel)
      link('cameras', 'VIPW 1210 MINI DUAL', [GENERICO, null, ''], 'camera-ip-wi-fi-profissional-vipw-1210-mini-dual'),
      link('cameras', 'VIPW 1200 MINI SD DUAL AP', [GENERICO, null, ''], 'camera-ip-wi-fi-profissional-vipw-1200-mini-sd-dual-ap'),
      // A Intelbras mudou o endereço da página
      link('cameras', 'VHL 1220 B G9', SITE + 'camera-full-color-vhl-1220-b-g9', 'camera-full-hd-vhl-1220-b-g9'),
      link('cameras', 'VHL 1220 D G9', SITE + 'camera-full-color-com-resolucao-full-hd-vhl-1220-d-g9', 'camera-resolucao-full-hd-vhl-1220-d-g9'),
      link('gravadores', 'iNVD 5232-16P', SITE + 'gravador-digital-de-video-com-32-canais-ip-invd-523216-p', 'gravador-digital-de-video-com-32-canais-ip-invd-5232-16p'),
      // A página de produto saiu do site; o endereço antigo leva para a página de suporte/download
      link('cameras', 'VIPC 1220 D FC+', SITE + 'camera-ip-da-serie-1000-com-full-color-e-ir-vip-1220-d-fc', 'ajuda-download/download/camera-ip-da-serie-1000-com-full-color-e-ir-vip-1220-d-fc'),
      link('cameras', 'VIPW 1220 D FC+', SITE + 'camera-ip-wi-fi-profissional-com-full-color-e-ir-vipw-1220-d-fc', 'ajuda-download/download/camera-ip-wi-fi-profissional-com-full-color-e-ir-vipw-1220-d-fc'),
      link('gravadores', 'iMHDX 3116', SITE + 'gravador-digital-de-video-inteligente-de-16-canais-imhdx-3116', 'ajuda-download/download/gravador-digital-de-video-inteligente-de-16-canais-imhdx-3116'),
      link('gravadores', 'NVD 1404', SITE + 'gravador-digital-de-video-nvr-nvd-1404', 'ajuda-download/download/gravador-digital-de-video-nvr-nvd-1404'),
      link('gravadores', 'NVD 1408', SITE + 'gravador-digital-de-video-nvr-nvd-1408', 'ajuda-download/download/gravador-digital-de-video-nvr-nvd-1408'),
      link('gravadores', 'NVD 3316-PLUS', SITE + 'gravador-digital-de-video-em-rede-nvd-3316-plus', 'ajuda-download/download/gravador-digital-de-video-em-rede-nvd-3316-plus'),
    ],
  },
  {
    // Pedido do Gabriel em 03/10/2026: stream extra e classificação da inteligência perimetral saem da tabela
    id: '2026-10-03-remover-colunas',
    descricao: 'Características retiradas da tabela',
    itens: [
      excluirColuna('gravadores', 'ip_stream_extra', 'IP stream extra'),
      excluirColuna('gravadores', 'hdcvi_stream_extra', 'HDCVI stream extra'),
      excluirColuna('gravadores', 'ahd_stream_extra', 'AHD stream extra'),
      excluirColuna('gravadores', 'hdtvi_stream_extra', 'HDTVI stream extra'),
      excluirColuna('gravadores', 'analogico_stream_extra', 'Analógico stream extra'),
      excluirColuna('gravadores', 'inteligencia_perimetral_classificacao', 'Classificação da inteligência perimetral'),
    ],
  },
  {
    // Pedido do Gabriel em 05/10/2026: produto novo só aparece na tabela depois de preenchido e liberado.
    // Os que já estão em linha sem nenhum dado técnico vão para a página "Revisão".
    id: '2026-10-05-revisao-sem-dados',
    descricao: 'Em linha sem dados técnicos: enviado para revisão',
    itens: [{ tipo: 'revisarSemDados', nome: 'em linha sem dados técnicos' }],
  },
  {
    // Pedido do Gabriel em 07/10/2026: preencher pelos datasheets (pasta datasheets) e liberar na tabela.
    // Links enviados por ele. VIP 3430 SC IA e iMHDX 3232 DUAL AUDIO continuam na Revisão (ainda sem página no site).
    // Só o que está escrito no datasheet; o que ele não informa fica vazio.
    id: '2026-10-07-revisao-datasheets',
    descricao: 'Dados técnicos pelo datasheet',
    itens: [
      {
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VIP 1230 SC',
        link: SITE + 'camera-ip-bullet-com-tecnologia-super-color-vip-1230-sc',
        dados: {
          formato: 'Bullet', tecnologia_video: 'IP',
          resolucao_video: '2MP (1920×1080) | 1.3MP (1280×960) | 1MP (1280×720) | D1 (704×480) | VGA (640×480) | CIF (352×240)',
          lente: '3,6 mm', angulo_abertura: 'H: 81° | V: 44° | D: 95°', full_color: '30 m',
          deteccao_inteligente: 'Sim (pessoas e veículos)', quantidade_de_streams: '2',
          compressao_video: 'H.265 | H.264 | H.264H | H.264B | MJPEG', formato_video: 'NTSC | PAL',
          fluxo_video: 'Até 20 conexões', throughput: '24 Mbps', poe: 'Sim (802.3af)', microfone: 'Sim',
          protecao: 'IP67', case: 'Plástico e metal', temperatura_de_operacao: '-40°C a 60°C', umidade_relativa_de_operacao: 'Até 95% RH',
          protocolos: 'ONVIF (Perfil S e T), Intelbras-1, Intelbras Cloud, ARP, CGI, DHCP, DDNS, DNS, FTP, Filtro IP, HTTP, HTTPS, ICMP, IGMP, IPv4, IPv6, Multicast, NTP, Registro Automático, RTP, RTCP, RTMP, RTSP, SMTP, TCP, UDP, QoS, NFS, P2P, 802.1x',
        },
      },
      {
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VIP 1230 D SC',
        link: SITE + 'camera-ip-dome-com-tecnologia-super-color-vip-1230-d-sc',
        dados: {
          formato: 'Dome', tecnologia_video: 'IP',
          resolucao_video: '2MP (1920×1080) | 1.3MP (1280×960) | 1MP (1280×720) | D1 (704×480) | VGA (640×480) | CIF (352×240)',
          lente: '2,8 mm', angulo_abertura: 'H: 101° | V: 53° | D: 119°', full_color: '30 m',
          deteccao_inteligente: 'Sim (pessoas e veículos)', quantidade_de_streams: '2',
          compressao_video: 'H.265 | H.264 | H.264H | H.264B | MJPEG', formato_video: 'NTSC | PAL',
          fluxo_video: 'Até 20 conexões', throughput: '24 Mbps', poe: 'Sim (802.3af)', microfone: 'Sim',
          protecao: 'IP67', case: 'Plástico e metal', temperatura_de_operacao: '-40°C a 60°C', umidade_relativa_de_operacao: 'Até 95% RH',
          protocolos: 'ONVIF (Perfil S e T), Intelbras-1, Intelbras Cloud, ARP, CGI, DHCP, DDNS, DNS, FTP, Filtro IP, HTTP, HTTPS, ICMP, IGMP, IPv4, IPv6, Multicast, NTP, Registro Automático, RTP, RTCP, RTMP, RTSP, SMTP, TCP, UDP, QoS, NFS, P2P, 802.1x',
        },
      },
      {
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VIPW 3200 MINI SD SC IA',
        link: SITE + 'camera-ip-wi-fi-profissional-vipw-3200-mini-sd-sc-ia',
        dados: {
          formato: 'Mini speed dome', tecnologia_video: 'IP',
          resolucao_video: '2MP (1920×1080) | 1.3MP (1280×960) | 1MP (1280×720) | D1 (704×576/704×480) | VGA (640×480) | CIF (352×288/352×240)',
          lente: '3,6 mm', angulo_abertura: 'H: 81,6° | V: 44,3° | D: 96,4°', ir: '-', full_color: '30 m', full_color_inteligente: 'Sim',
          autotracking: 'Sim (Lite: pessoas e veículos)', deteccao_inteligente: 'Sim (pessoas e veículos)',
          inteligencia_perimetral: 'Sim (linha e cerca virtual)', alarme: 'Sonoro', quantidade_de_streams: '2',
          compressao_video: 'H.265 | H.264B | H.264M | H.264H | MJPEG', formato_video: 'NTSC | PAL',
          fluxo_video: 'Até 20 conexões', throughput: '100 Mbps', throughput_wifi: '229 Mbps', wifi: 'Sim (2,4 GHz, Wi-Fi 6)',
          poe: '-', microfone: 'Sim (bidirecional)', microsd: 'Sim (até 256 GB)',
          protecao: 'IP56', case: 'Plástico', temperatura_de_operacao: '-30°C a 55°C', umidade_relativa_de_operacao: 'Até 95% RH',
          protocolos: 'ONVIF (Perfil S, G e T), HTTP, HTTPS, TCP/IP, IPv4, IPv6, RTSP, UDP, NTP, DHCP, DNS, DDNS, SSL, QoS, FTP, ICMP, IGMP, ARP, RTCP, RTP, RTMP',
        },
      },
      {
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VIPW 3200 MINI SD DUAL SC IA',
        link: SITE + 'camera-ip-wi-fi-profissional-vipw-3200-mini-sd-dual-sc-ia',
        dados: {
          formato: 'Mini speed dome com 2 lentes', tecnologia_video: 'IP',
          resolucao_video: '2 lentes de 2MP (1920×1080) | 1.3MP (1280×960) | 1MP (1280×720) | D1 (704×576/704×480) | VGA (640×480) | CIF (352×288/352×240)',
          lente: 'Fixa: 2,8 mm | Móvel: 6 mm', angulo_abertura: 'Fixa: H: 89° V: 48° D: 105° | Móvel: H: 52° V: 29° D: 60°',
          ir: '30 m', full_color: '30 m', full_color_inteligente: 'Sim', zoom_optico: '-',
          autotracking: 'Sim (Lite: pessoas e veículos)', deteccao_inteligente: 'Sim (pessoas e veículos)',
          inteligencia_perimetral: 'Sim (linha e cerca virtual)', alarme: 'Sonoro', quantidade_de_streams: '2',
          compressao_video: 'H.265 | H.264 | H.264H | H.264B | MJPEG', formato_video: 'NTSC | PAL',
          fluxo_video: 'Até 20 conexões', throughput: '100 Mbps', throughput_wifi: '229 Mbps', wifi: 'Sim (2,4 GHz, Wi-Fi 6)',
          poe: '-', microfone: 'Sim (bidirecional)', microsd: 'Sim (até 256 GB)',
          protecao: 'IP56', case: 'Plástico', temperatura_de_operacao: '-20°C a 50°C', umidade_relativa_de_operacao: 'Até 95% RH',
          protocolos: 'ONVIF (Perfil S, G e T), Intelbras-1, Intelbras Cloud, CGI, IPv4, IPv6, HTTP, HTTPS, TCP, UDP, RTSP, DDNS, ARP, Registro Automático, P2P, RTMP, Multicast, DHCP, DNS, NTP',
        },
      },
      {
        // O datasheet traz "Throughput Máximo (Cabo): 12 Mbps (??)": não preenchido até confirmar
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VIPW 3230 BULLET FC+ AP IA',
        link: SITE + 'camera-ip-bullet-wi-fi-profissional-vipw-3230-fc-ap-ia',
        dados: {
          formato: 'Bullet', tecnologia_video: 'IP',
          resolucao_video: '2MP (1920×1080) | 1.3MP (1280×960) | 1MP (1280×720) | VGA (640×480) | CIF (352×240)',
          lente: '3,6 mm', angulo_abertura: 'H: 85° | V: 46° | D: 100°', ir: '30 m', full_color: '30 m',
          deteccao_inteligente: 'Sim', alarme: 'Sonoro e luminoso', quantidade_de_streams: '2',
          compressao_video: 'H.264 | H.264B | H.264H | H.265', formato_video: 'NTSC',
          fluxo_video: 'Até 20 conexões', throughput_wifi: '50 Mbps', wifi: 'Sim (2,4 GHz, Wi-Fi 6)',
          poe: '-', microfone: 'Sim (bidirecional)', microsd: 'Sim (até 256 GB)',
          protecao: 'IP67', case: 'Plástico', cores: 'Branca e preta', temperatura_de_operacao: '-10°C a 50°C', umidade_relativa_de_operacao: 'Até 95% RH',
          protocolos: 'ONVIF (Perfil S, T e G), Intelbras-1, Intelbras Cloud, IPv4, IPv6, HTTP, HTTPS, TCP, UDP, ARP, RTP, RTSP, RTCP, DHCP, DNS, NTP, Multicast, RTMP, IEEE 802.1x',
        },
      },
      {
        tipo: 'preencherELiberar', tabela: 'cameras', nome: 'VHD 5830 4K FULL COLOR+',
        link: SITE + 'camera-bullet-full-color-com-microfone-embutido-vhd-5830-b-4k-fc',
        dados: {
          formato: 'Bullet', tecnologia_video: 'HDCVI | AHD | HDTVI', resolucao_video: '8MP (3840×2160)',
          lente: '2,8 mm', angulo_abertura: 'H: 105,5° | V: 56,5°', ir: '30 m', full_color: '30 m', full_color_inteligente: 'Sim',
          formato_video: 'NTSC | PAL', microfone: 'Sim (alcance de 8 m)',
          protecao: 'IP67', case: 'Plástico', cores: 'Branca e preta', temperatura_de_operacao: '-40°C a 60°C', umidade_relativa_de_operacao: 'Abaixo de 95% RH',
        },
      },
    ],
  },
  {
    // Regra nova de 07/10/2026: modelo que está só nos Encerramentos entra direto no phaseout (ex.: VHC 1120 B/D).
    // Usa a planilha já importada no servidor, para não depender de uma nova importação. Se ainda não houver
    // a aba Encerramentos importada, não faz nada (a próxima importação faz).
    id: '2026-10-07-encerrados-no-phaseout',
    descricao: 'Encerrados que não estavam cadastrados adicionados ao phaseout',
    itens: [{ tipo: 'encerradosNoPhaseout', nome: 'encerrados da planilha já importada' }],
  },
];

// Produto da Revisão preenchido pelo datasheet: só grava nos campos vazios (nunca troca um dado já preenchido;
// "cores" com o padrão do banco 'Branco' conta como vazio) e, se ainda estiver em revisão, libera na tabela.
const preencherELiberar = async (equipamentos, correcao, item, resumo) => {
  const atual = await equipamentos.buscarPorNome(item.tabela, item.nome).catch(() => null);
  if (!atual) {
    resumo.mantidos.push(`${item.nome} (não encontrado)`);
    return;
  }
  const vazio = (coluna) => {
    const valor = atual[coluna];
    if (coluna === 'cores' && valor === 'Branco') return true;
    if (coluna === 'link' && /\/seguranca-eletronica$/.test(String(valor || ''))) return true;
    return valor === null || valor === undefined || String(valor).trim() === '';
  };
  const campos = Object.fromEntries(Object.entries({ link: item.link, ...item.dados }).filter(([coluna]) => vazio(coluna)));
  const opcoes = { origem: 'sistema', lote: `correcao:${correcao.id}`, descricao: `${correcao.descricao}: ${item.nome}` };
  if (Object.keys(campos).length > 0) await equipamentos.alterar(item.tabela, item.nome, campos, opcoes);
  if (atual.phaseout === equipamentos.PHASEOUT_EM_REVISAO) {
    await equipamentos.alterar(item.tabela, item.nome, { status: equipamentos.STATUS.EM_LINHA },
      { ...opcoes, descricao: `Liberado na tabela (datasheet preenchido): ${item.nome}` });
    await require('./alertas').resolverDoEquipamento(item.tabela, item.nome).catch(() => {});
  }
  resumo.trocados.push(item.nome);
};

// Equipamentos em linha sem nenhuma característica técnica preenchida -> status "em revisão"
const revisarSemDados = async (equipamentos, correcao, resumo) => {
  for (const tabela of equipamentos.TABELAS) {
    const linhas = (await pool.query(`SELECT * FROM ${tabela} WHERE phaseout = $1`, [equipamentos.PHASEOUT_EM_LINHA]).catch(() => ({ rows: [] }))).rows;
    for (const linha of linhas) {
      if (equipamentos.contarDadosTecnicos(linha) > 0) continue;
      await equipamentos.alterar(tabela, linha.nome, { status: equipamentos.STATUS.REVISAO }, {
        origem: 'sistema',
        lote: `correcao:${correcao.id}`,
        descricao: `${correcao.descricao}: ${linha.nome}`,
      });
      resumo.trocados.push(linha.nome);
    }
  }
};

const aplicarCorrecoes = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS correcoes_aplicadas (
      id TEXT PRIMARY KEY,
      aplicada_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      resumo JSONB
    );
  `);
  const equipamentos = require('./equipamentos');
  const colunas = require('./colunas');
  for (const correcao of CORRECOES) {
    const ja = await pool.query(`SELECT 1 FROM correcoes_aplicadas WHERE id = $1`, [correcao.id]);
    if (ja.rowCount > 0) continue;

    const resumo = { trocados: [], mantidos: [] };
    for (const item of correcao.itens) {
      if (item.tipo === 'encerradosNoPhaseout') {
        const { adicionados, motivo } = await require('./sincronizacao/sincronizador').adicionarEncerradosNoPhaseout(
          { origem: 'sistema', lote: `correcao:${correcao.id}` });
        resumo.trocados.push(...adicionados);
        if (motivo) resumo.mantidos.push(motivo);
        continue;
      }
      if (item.tipo === 'preencherELiberar') {
        await preencherELiberar(equipamentos, correcao, item, resumo);
        continue;
      }
      if (item.tipo === 'revisarSemDados') {
        await revisarSemDados(equipamentos, correcao, resumo);
        continue;
      }
      if (item.tipo === 'excluirColuna') {
        const existe = (await colunas.colunasExistentes())[item.tabela]?.includes(item.coluna);
        if (!existe) {
          resumo.mantidos.push(`${item.rotulo} (já não existia)`);
          continue;
        }
        await colunas.excluir(item.tabela, item.coluna, { origem: 'sistema', lote: `correcao:${correcao.id}`, rotulo: item.rotulo });
        resumo.trocados.push(item.rotulo);
        continue;
      }
      const atual = await equipamentos.buscarPorNome(item.tabela, item.nome).catch(() => null);
      const valor = atual ? (atual[item.coluna] ?? null) : undefined;
      const errado = atual && item.de.some(de => (de === null ? valor === null : String(valor ?? '') === de));
      if (!errado) {
        resumo.mantidos.push(`${item.nome} (${atual ? 'já estava diferente' : 'não encontrado'})`);
        continue;
      }
      await equipamentos.alterar(item.tabela, item.nome, { [item.coluna]: item.para }, {
        origem: 'sistema',
        lote: `correcao:${correcao.id}`,
        descricao: `${correcao.descricao}: ${item.nome}`,
      });
      resumo.trocados.push(item.nome);
    }
    await pool.query(`INSERT INTO correcoes_aplicadas (id, resumo) VALUES ($1, $2)`, [correcao.id, JSON.stringify(resumo)]);
    console.log(`Correção "${correcao.id}": ${resumo.trocados.length} trocados, ${resumo.mantidos.length} mantidos.`);
  }
};

module.exports = { aplicarCorrecoes, CORRECOES };
