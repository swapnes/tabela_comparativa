const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Carrega o back/.env (formato CHAVE=valor) sem precisar de dependência extra.
// Variáveis já definidas no ambiente têm prioridade sobre o arquivo.
const carregarEnv = () => {
  const caminho = path.join(__dirname, '.env');
  if (!fs.existsSync(caminho)) return;

  const linhas = fs.readFileSync(caminho, 'utf8').replace(/^﻿/, '').split(/\r?\n/);
  for (const linha of linhas) {
    const texto = linha.trim();
    if (!texto || texto.startsWith('#')) continue;

    const separador = texto.indexOf('=');
    if (separador === -1) continue;

    const chave = texto.slice(0, separador).trim();
    let valor = texto.slice(separador + 1).trim();
    if ((valor.startsWith('"') && valor.endsWith('"')) || (valor.startsWith("'") && valor.endsWith("'"))) {
      valor = valor.slice(1, -1);
    }
    if (process.env[chave] === undefined) {
      process.env[chave] = valor;
    }
  }
};

carregarEnv();

if (!process.env.ADMIN_USUARIO || !process.env.ADMIN_SENHA) {
  console.warn('ADMIN_USUARIO/ADMIN_SENHA não definidos no back/.env: o login do admin está desativado.');
}

if (!process.env.JWT_SECRET) {
  console.warn('JWT_SECRET não definido no back/.env: usando uma chave temporária (o login cai sempre que o servidor reiniciar).');
} else if (process.env.JWT_SECRET.length < 32) {
  console.warn('JWT_SECRET do back/.env é curto: use 32 caracteres ou mais (ex.: letras e números aleatórios).');
}

if (process.env.ADMIN_SENHA && process.env.ADMIN_SENHA.length < 10) {
  console.warn('ADMIN_SENHA do back/.env é curta: use 10 caracteres ou mais, misturando letras, números e símbolos.');
}

module.exports = {
  // Porta do site (tabela + painel + API em /api)
  porta: Number(process.env.PORTA) || 3777,
  databaseUrl: process.env.DATABASE_URL || 'postgres://postgres:admin@localhost:5432/postgres',
  adminUsuario: process.env.ADMIN_USUARIO || '',
  adminSenha: process.env.ADMIN_SENHA || '',
  jwtSecret: process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex'),
};
