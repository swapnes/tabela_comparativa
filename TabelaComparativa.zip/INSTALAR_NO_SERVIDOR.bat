@echo off
rem ==================================================================
rem  Instala a Tabela Comparativa NO SERVIDOR (PC da rede do trabalho).
rem  Rode UMA vez. Depois ela liga sozinha sempre que o PC ligar,
rem  sem janela aberta e sem ninguem logado.
rem  Porta padrao: 49152. Outra porta: INSTALAR_NO_SERVIDOR.bat 8080
rem ==================================================================
net session >nul 2>&1
if errorlevel 1 (
  echo Pedindo permissao de administrador...
  if "%~1"=="" (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs") else (powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs")
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\instalar.ps1" %1
echo.
pause
