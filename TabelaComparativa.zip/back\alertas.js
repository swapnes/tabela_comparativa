// Alertas do painel do admin
const pool = require('./db');

const TIPOS_ALERTA = {
  DADOS_PENDENTES: 'dados_pendentes',               // equipamento novo veio da planilha sem dados técnicos
  PHASEOUT_AUTOMATICO: 'phaseout_automatico',       // saiu da planilha e foi para o phaseout
  VOLTOU_LINHA: 'voltou_linha',                     // estava em phaseout e voltou a aparecer na planilha
  SINCRONIZACAO_BLOQUEADA: 'sincronizacao_bloqueada', // trava de segurança do phaseout acionada
  ERRO_SINCRONIZACAO: 'erro_sincronizacao',
  RESUMO_SINCRONIZACAO: 'resumo_sincronizacao',     // quantos foram adicionados/removidos numa aplicação
  RENOMEADO_AUTOMATICO: 'renomeado_automatico',     // cadastrado com nome diferente, passou a usar o nome da planilha
  REMOVIDO_NA_PLANILHA: 'removido_na_planilha',     // está na planilha, mas foi removido pelo admin: não volta sozinho
};

// Não duplica: se já existe um alerta aberto igual (mesmo tipo e equipamento, ou mesma mensagem), não cria outro
const criarAlerta = async ({ tipo, tabela = null, nome = null, mensagem }) => {
  const existente = await pool.query(
    `SELECT id FROM alertas
     WHERE resolvido_em IS NULL
       AND tipo = $1::text
       AND tabela IS NOT DISTINCT FROM $2::text
       AND nome IS NOT DISTINCT FROM $3::text
       AND ($3::text IS NOT NULL OR mensagem = $4::text)
     LIMIT 1`,
    [tipo, tabela, nome, mensagem]
  );
  if (existente.rows.length > 0) return;

  await pool.query(
    `INSERT INTO alertas (tipo, tabela, nome, mensagem) VALUES ($1, $2, $3, $4)`,
    [tipo, tabela, nome, mensagem]
  );
};

const listarAbertos = async () => {
  const result = await pool.query(`SELECT * FROM alertas WHERE resolvido_em IS NULL ORDER BY criado_em DESC, id DESC`);
  return result.rows;
};

const resolver = async (id) => {
  const result = await pool.query(`UPDATE alertas SET resolvido_em = now() WHERE id = $1 AND resolvido_em IS NULL`, [id]);
  return result.rowCount > 0;
};

// Equipamento removido: os alertas dele não fazem mais sentido
const resolverDoEquipamento = (tabela, nome) =>
  pool.query(`UPDATE alertas SET resolvido_em = now() WHERE resolvido_em IS NULL AND tabela = $1 AND nome = $2`, [tabela, nome]);

// Equipamento renomeado pelo admin: mantém os alertas apontando para o nome certo
const renomearEquipamento = (tabela, nomeAntigo, nomeNovo) =>
  pool.query(`UPDATE alertas SET nome = $3 WHERE tabela = $1 AND nome = $2`, [tabela, nomeAntigo, nomeNovo]);

module.exports = {
  TIPOS_ALERTA,
  criarAlerta,
  listarAbertos,
  resolver,
  resolverDoEquipamento,
  renomearEquipamento,
};
