// Avisos de rotina do painel: última aplicação da planilha e último backup diário
// (feito por servidor\backup.ps1 em back\dados\backups\tabela-AAAA-MM-DD.sql).
const fs = require('fs');
const path = require('path');
const { ultimaAplicacao } = require('./sincronizacao/sincronizador');

const PASTA_BACKUPS = path.join(__dirname, 'dados', 'backups');

const ultimoBackup = () => {
  let arquivos = [];
  try {
    arquivos = fs.readdirSync(PASTA_BACKUPS).filter(nome => /^tabela-\d{4}-\d{2}-\d{2}\.sql$/.test(nome)).sort();
  } catch {
    // Pasta ainda não existe (PC sem a tarefa de backup)
  }
  if (arquivos.length === 0) return { quantidade: 0, ultimo: null };
  const arquivo = arquivos[arquivos.length - 1];
  const estatisticas = fs.statSync(path.join(PASTA_BACKUPS, arquivo));
  return { quantidade: arquivos.length, ultimo: { arquivo, em: estatisticas.mtime, tamanho: estatisticas.size } };
};

const obterRotina = async () => ({ planilha: await ultimaAplicacao(), backup: ultimoBackup() });

module.exports = { obterRotina };
