// Regras e consultas de equipamentos (câmeras, gravadores, baluns e extensores).
// Tudo que lê/grava equipamentos passa por aqui: as rotas da API e a sincronização com a planilha de preços.
const pool = require('./db');
const historico = require('./historico');

const TABELAS = ['cameras', 'gravadores', 'baluns', 'extensores'];

// Nome de cada tabela na coluna "Tipo" da aba de Phaseout
const TIPO_DA_TABELA = {
  cameras: 'Câmera',
  gravadores: 'Gravador',
  baluns: 'Balun',
  extensores: 'Extensor',
};

// Colunas que não entram em sugestões de preenchimento nem são copiadas entre equipamentos
const COLUNAS_DE_CONTROLE = ['nome', 'link', 'phaseout', 'data', 'descontinuado', 'substituto'];

// Valor da coluna "phaseout" que marca o equipamento como em linha.
// Qualquer outro valor (ou vazio) = descontinuado: some das tabelas e fica só na página de phaseout.
// Precisa ser igual ao PHASEOUT_EM_LINHA do front (front/src/status.js).
const PHASEOUT_EM_LINHA = 'Equipamento em linha';

// Valor da coluna "phaseout" de um produto novo da planilha que ainda não foi liberado (página "Revisão" do admin):
// não aparece nas tabelas nem no phaseout até o admin preencher os dados técnicos e liberar. Igual ao front (status.js).
const PHASEOUT_EM_REVISAO = 'Em revisão';

// Colunas que não contam como dado técnico ao conferir se um equipamento foi preenchido
// ("cores" tem o padrão 'Branco' no banco antigo; método de recuperação não é característica técnica)
const NAO_SAO_DADOS_TECNICOS = ['metodos_de_recuperacao', 'cores'];

// Quantas características técnicas estão preenchidas
const contarDadosTecnicos = (linha) => Object.entries(linha || {}).filter(([coluna, valor]) =>
  !COLUNAS_DE_CONTROLE.includes(coluna) && !NAO_SAO_DADOS_TECNICOS.includes(coluna) &&
  valor !== null && valor !== undefined && String(valor).trim() !== '' && typeof valor !== 'object'
).length;

// Tabelas que têm a coluna "descontinuado" da tabela antiga ('Sim' / 'Não')
const TABELAS_COM_DESCONTINUADO = ['cameras', 'gravadores'];

// Como a tabela antiga escreve o phaseout de um descontinuado: "MM/AAAA" (a partir da data)
const phaseoutDaData = (data) => {
  const partes = /^(\d{4})-(\d{2})/.exec(String(data || ''));
  return partes ? `${partes[2]}/${partes[1]}` : 'Descontinuado';
};

// Status usado pelo admin; é traduzido para as colunas phaseout/data do banco em aplicarStatus()
const STATUS = {
  EM_LINHA: 'em_linha',
  DESCONTINUADO: 'descontinuado',
  REVISAO: 'revisao',
};

// Erro com mensagem que pode ser mostrada para o usuário (a rota responde com o status informado)
class ErroEquipamento extends Error {
  constructor(mensagem, status = 400) {
    super(mensagem);
    this.status = status;
  }
}

const tabelaValida = (tabela) => TABELAS.includes(tabela);

const validarTabela = (tabela) => {
  if (!tabelaValida(tabela)) {
    throw new ErroEquipamento('Tabela inválida', 404);
  }
};

// Coloca o nome da coluna entre aspas escapando aspas internas, para não permitir SQL injection pelo nome da coluna
const colunaSegura = (coluna) => `"${String(coluna).replace(/"/g, '""')}"`;

// Escapa os caracteres especiais do SIMILAR TO para o modelo ser buscado literalmente
const escaparSimilarTo = (texto) => texto.replace(/[\\%_|*+?{}()[\]]/g, '\\$&');

// Tira os campos de colunas que não existem na tabela (ex.: característica excluída pelo painel
// enquanto um formulário estava aberto, ou dados antigos de um equipamento removido)
const soColunasExistentes = async (tabela, dados) => {
  const existentes = (await pool.query(
    `SELECT column_name FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = $1`,
    [tabela]
  )).rows.map(item => item.column_name);
  return Object.fromEntries(Object.entries(dados).filter(([coluna]) => existentes.includes(coluna)));
};

const vaziosParaNull = (campos) => {
  const resultado = {};
  for (const key in campos) {
    resultado[key] = campos[key] === '' ? null : campos[key];
  }
  return resultado;
};

// Traduz o campo "status" para as colunas do banco, no mesmo formato da tabela antiga:
// - em linha: phaseout = 'Equipamento em linha', data = null, substituto = null, descontinuado = 'Não'
// - descontinuado: exige a data; phaseout = "MM/AAAA" da data, descontinuado = 'Sim'
// - revisão: phaseout = 'Em revisão' (fora das tabelas e do phaseout até ser liberado)
const aplicarStatus = (tabela, campos) => {
  const { status, ...resto } = campos;
  const comDescontinuado = TABELAS_COM_DESCONTINUADO.includes(tabela);

  if (status === undefined || status === null) {
    return resto;
  }
  if (status === STATUS.EM_LINHA) {
    return { ...resto, phaseout: PHASEOUT_EM_LINHA, data: null, substituto: null, ...(comDescontinuado ? { descontinuado: 'Não' } : {}) };
  }
  if (status === STATUS.REVISAO) {
    return { ...resto, phaseout: PHASEOUT_EM_REVISAO, data: null, substituto: null, ...(comDescontinuado ? { descontinuado: 'Não' } : {}) };
  }
  if (status === STATUS.DESCONTINUADO) {
    if (!resto.data) {
      throw new ErroEquipamento('Informe a data de phaseout do equipamento descontinuado');
    }
    return { ...resto, phaseout: phaseoutDaData(resto.data), ...(comDescontinuado ? { descontinuado: 'Sim' } : {}) };
  }
  throw new ErroEquipamento('Status inválido');
};

// Selo "Novo" na tabela: produto que entrou em linha (adicionado em linha ou liberado da Revisão) nos últimos DIAS_NOVO dias.
// Automático: só lê o histórico; "desfazer" (ex.: restaurar um removido) não conta como novo; renomeado depois de
// entrar continua novo. O admin pode marcar ou tirar o selo na página Produtos (tabela selo_novo; tirar vale até o
// produto entrar de novo na tabela). Devolve Map nome -> { desde, ate, manual } dos que estão com o selo hoje
const DIAS_NOVO = 30;
const novosDaTabela = async (tabela) => {
  const automaticos = (await pool.query(
    `SELECT nome, max(criado_em) AS em,
            to_char(max(criado_em), 'YYYY-MM-DD') AS desde,
            to_char(max(criado_em) + make_interval(days => $2), 'YYYY-MM-DD') AS ate
       FROM historico
      WHERE tabela = $1 AND desfeito_em IS NULL AND origem <> 'desfazer'
        AND criado_em > now() - make_interval(days => $2)
        AND depois->>'phaseout' = $3
        AND (acao = 'adicionar' OR (acao = 'alterar' AND antes->>'phaseout' = $4))
      GROUP BY nome;`,
    [tabela, DIAS_NOVO, PHASEOUT_EM_LINHA, PHASEOUT_EM_REVISAO]
  )).rows;
  const novos = new Map(automaticos.map(({ nome, em, desde, ate }) => [nome, { em, desde, ate, manual: false }]));

  const renomeados = (await pool.query(
    `SELECT antes->>'nome' AS de, depois->>'nome' AS para, criado_em FROM historico
      WHERE tabela = $1 AND acao = 'alterar' AND desfeito_em IS NULL AND antes ? 'nome'
        AND criado_em > now() - make_interval(days => $2)
      ORDER BY criado_em, id;`,
    [tabela, DIAS_NOVO]
  )).rows;
  for (const { de, para, criado_em } of renomeados) {
    if (novos.has(de) && novos.get(de).em <= criado_em) novos.set(para, novos.get(de));
  }

  const manuais = (await pool.query(
    `SELECT nome, mostrar, alterado_em, ate >= CURRENT_DATE AS valendo,
            to_char(desde, 'YYYY-MM-DD') AS desde, to_char(ate, 'YYYY-MM-DD') AS ate
       FROM selo_novo WHERE tabela = $1;`,
    [tabela]
  )).rows;
  for (const { nome, mostrar, alterado_em, valendo, desde, ate } of manuais) {
    if (mostrar && valendo) novos.set(nome, { desde, ate, manual: true });
    else if (!mostrar && novos.has(nome) && novos.get(nome).em <= alterado_em) novos.delete(nome);
  }
  return novos;
};

const marcarNovos = async (tabela, linhas) => {
  try {
    const novos = await novosDaTabela(tabela);
    return linhas.map(linha => novos.has(linha.nome)
      ? { ...linha, novo_desde: novos.get(linha.nome).desde, novo_ate: novos.get(linha.nome).ate }
      : linha);
  } catch (err) {
    // A tabela continua aparecendo, só sem o selo
    console.log('Erro ao buscar os produtos novos no histórico:', err.message);
    return linhas;
  }
};

// Equipamentos em linha de uma tabela, opcionalmente filtrados por parte do nome (ex.: ['VHD', 'VHL'])
const listarEmLinha = async (tabela, modelos = []) => {
  validarTabela(tabela);
  const filtros = modelos.map(modelo => modelo.trim()).filter(Boolean);

  if (filtros.length > 0) {
    const padrao = `%(${filtros.map(escaparSimilarTo).join('|')})%`;
    const result = await pool.query(
      `SELECT * FROM ${tabela} WHERE nome SIMILAR TO $1 AND phaseout = $2 ORDER BY nome ASC;`,
      [padrao, PHASEOUT_EM_LINHA]
    );
    return marcarNovos(tabela, result.rows);
  }

  const result = await pool.query(`SELECT * FROM ${tabela} WHERE phaseout = $1 ORDER BY nome ASC;`, [PHASEOUT_EM_LINHA]);
  return marcarNovos(tabela, result.rows);
};

// Consulta que junta todas as tabelas: se uma tabela ainda não existir no banco, é pulada
const consultarTabela = async (tabela, sql, parametros = []) => {
  try {
    return (await pool.query(sql, parametros)).rows;
  } catch (err) {
    if (err.code === '42P01') {
      console.log(`Tabela "${tabela}" não existe no banco; ignorada.`);
      return [];
    }
    throw err;
  }
};

// Equipamentos descontinuados de todas as tabelas: aba de Phaseout e página "Phaseout" do admin
// (tipo = nome mostrado; tabela = onde o equipamento está, usado para editar)
const listarDescontinuados = async () => {
  const descontinuados = [];
  for (const tabela of TABELAS) {
    const linhas = await consultarTabela(
      tabela,
      `SELECT nome, phaseout, data, substituto, metodos_de_recuperacao, link FROM ${tabela} WHERE phaseout IS DISTINCT FROM $1 AND phaseout IS DISTINCT FROM $2;`,
      [PHASEOUT_EM_LINHA, PHASEOUT_EM_REVISAO]
    );
    descontinuados.push(...linhas.map(linha => ({ tipo: TIPO_DA_TABELA[tabela], tabela, ...linha })));
  }
  return descontinuados.sort((a, b) => String(a.nome ?? '').localeCompare(String(b.nome ?? ''), 'pt-BR', { numeric: true }));
};

// Produtos novos da planilha aguardando liberação (página "Revisão" do admin), com quantos dados técnicos já têm
const listarEmRevisao = async () => {
  const lista = [];
  for (const tabela of TABELAS) {
    const linhas = await consultarTabela(tabela, `SELECT * FROM ${tabela} WHERE phaseout = $1;`, [PHASEOUT_EM_REVISAO]);
    lista.push(...linhas.map(linha => ({
      tipo: TIPO_DA_TABELA[tabela],
      tabela,
      nome: linha.nome,
      link: linha.link,
      dadosTecnicos: contarDadosTecnicos(linha),
    })));
  }
  return lista.sort((a, b) => String(a.nome ?? '').localeCompare(String(b.nome ?? ''), 'pt-BR', { numeric: true }));
};

// Valores já usados em cada coluna da tabela (os mais comuns primeiro), para sugerir no formulário do admin
const valoresPorColuna = async (tabela) => {
  validarTabela(tabela);
  const result = await pool.query(`SELECT * FROM ${tabela};`);
  const contagem = {};
  for (const linha of result.rows) {
    for (const [coluna, valor] of Object.entries(linha)) {
      if (COLUNAS_DE_CONTROLE.includes(coluna) || valor === null || valor === '' || typeof valor === 'object') continue;
      const texto = String(valor);
      contagem[coluna] = contagem[coluna] || new Map();
      contagem[coluna].set(texto, (contagem[coluna].get(texto) || 0) + 1);
    }
  }
  const valores = {};
  for (const [coluna, mapa] of Object.entries(contagem)) {
    valores[coluna] = [...mapa.entries()].sort((a, b) => b[1] - a[1]).slice(0, 300).map(([texto]) => texto);
  }
  return valores;
};

// Nome, status, mês de phaseout ("AAAA-MM") e substituto de todos os equipamentos (usado na sincronização com a planilha)
const listarResumo = async () => {
  const resumo = [];
  for (const tabela of TABELAS) {
    const linhas = await consultarTabela(tabela, `SELECT nome, phaseout, to_char(data, 'YYYY-MM') AS mes, substituto FROM ${tabela} WHERE nome IS NOT NULL;`);
    resumo.push(...linhas.map(linha => ({ tabela, ...linha })));
  }
  return resumo;
};

// Nomes (e se está em linha) de todos os equipamentos da tabela, para as listas do painel do admin
const listarNomes = async (tabela) => {
  validarTabela(tabela);
  const result = await pool.query(
    `SELECT nome, phaseout = $1 AS em_linha, phaseout = $2 AS em_revisao FROM ${tabela} ORDER BY nome ASC;`,
    [PHASEOUT_EM_LINHA, PHASEOUT_EM_REVISAO]
  );
  const novos = await novosDaTabela(tabela).catch(() => new Map());
  return result.rows.map(linha => ({
    nome: linha.nome,
    emLinha: linha.em_linha === true,
    emRevisao: linha.em_revisao === true,
    novo: linha.em_linha === true && novos.has(linha.nome) ? novos.get(linha.nome).ate : null,
  }));
};

// Selo "Novo" de um produto (página Produtos): o que vale hoje ({ desde, ate, manual } ou null) e a escolha do admin
const seloNovo = async (tabela, nome) => {
  validarTabela(tabela);
  const atual = (await novosDaTabela(tabela)).get(nome) || null;
  const escolha = (await pool.query(
    `SELECT mostrar, to_char(desde, 'YYYY-MM-DD') AS desde, to_char(ate, 'YYYY-MM-DD') AS ate
       FROM selo_novo WHERE tabela = $1 AND nome = $2;`,
    [tabela, nome]
  )).rows[0] || null;
  return { atual: atual && { desde: atual.desde, ate: atual.ate, manual: atual.manual }, escolha };
};

// acao: 'marcar' (novo por DIAS_NOVO dias a partir de hoje), 'tirar' (sem selo, mesmo que tenha entrado agora)
// ou 'automatico' (volta à regra do histórico)
const definirSeloNovo = async (tabela, nome, acao) => {
  validarTabela(tabela);
  if (!await buscarPorNome(tabela, nome)) {
    throw new ErroEquipamento('Equipamento não encontrado', 404);
  }
  if (acao === 'automatico') {
    await pool.query(`DELETE FROM selo_novo WHERE tabela = $1 AND nome = $2`, [tabela, nome]);
  } else if (acao === 'marcar' || acao === 'tirar') {
    await pool.query(
      `INSERT INTO selo_novo (tabela, nome, mostrar, desde, ate, alterado_em)
       VALUES ($1, $2, $3, CURRENT_DATE, CASE WHEN $3 THEN CURRENT_DATE + $4::int END, now())
       ON CONFLICT (tabela, nome) DO UPDATE
         SET mostrar = EXCLUDED.mostrar, desde = EXCLUDED.desde, ate = EXCLUDED.ate, alterado_em = EXCLUDED.alterado_em;`,
      [tabela, nome, acao === 'marcar', DIAS_NOVO]
    );
  } else {
    throw new ErroEquipamento('Ação inválida');
  }
  return seloNovo(tabela, nome);
};

const buscarPorNome = async (tabela, nome) => {
  validarTabela(tabela);
  const result = await pool.query(`SELECT * FROM ${tabela} WHERE nome = $1`, [nome]);
  return result.rows[0] || null;
};

// opcoes (todas as operações abaixo): { origem: 'admin' | 'planilha' | 'desfazer', lote, descricao }
// Cada operação registra no histórico e devolve o id do registro (para o botão "Desfazer").

const adicionar = async (tabela, campos, opcoes = {}) => {
  validarTabela(tabela);
  const dados = await soColunasExistentes(tabela, aplicarStatus(tabela, vaziosParaNull(campos)));

  if (!dados.nome) {
    throw new ErroEquipamento('Informe o nome do equipamento');
  }
  if (await buscarPorNome(tabela, dados.nome)) {
    throw new ErroEquipamento('Já existe um equipamento com esse nome', 409);
  }
  // Sem status informado, o equipamento entra como em linha
  if (!('phaseout' in dados)) {
    dados.phaseout = PHASEOUT_EM_LINHA;
  }

  const colunas = Object.keys(dados);
  const query = `INSERT INTO ${tabela} (${colunas.map(colunaSegura).join(', ')}) VALUES (${colunas.map((_, index) => `$${index + 1}`).join(', ')})`;
  await pool.query(query, Object.values(dados));

  return historico.registrar({
    acao: historico.ACOES.ADICIONAR,
    tabela,
    nome: dados.nome,
    descricao: opcoes.descricao || `Adicionado: ${dados.nome}`,
    depois: await buscarPorNome(tabela, dados.nome),
    origem: opcoes.origem,
    lote: opcoes.lote,
  });
};

// Coloca de volta um equipamento removido, com todos os dados que ele tinha (usado pelo "Desfazer").
// Colunas que foram excluídas depois são ignoradas (ver soColunasExistentes).
const restaurar = async (tabela, linha, opcoes = {}) => {
  validarTabela(tabela);
  return adicionar(tabela, { ...(linha || {}) }, opcoes);
};

// nomeAtual é o nome que está no banco hoje (o campo "nome" em campos pode ser um nome novo)
const alterar = async (tabela, nomeAtual, campos, opcoes = {}) => {
  validarTabela(tabela);
  const atual = await buscarPorNome(tabela, nomeAtual);
  if (!atual) {
    throw new ErroEquipamento('Equipamento não encontrado', 404);
  }

  const dados = await soColunasExistentes(tabela, aplicarStatus(tabela, vaziosParaNull(campos)));
  if ('nome' in dados) {
    if (!dados.nome) {
      throw new ErroEquipamento('O nome não pode ficar vazio');
    }
    if (dados.nome !== nomeAtual && await buscarPorNome(tabela, dados.nome)) {
      throw new ErroEquipamento('Já existe um equipamento com esse nome', 409);
    }
  }

  const colunas = Object.keys(dados);
  if (colunas.length === 0) {
    throw new ErroEquipamento('Nenhuma alteração informada');
  }

  const setClause = colunas.map((coluna, index) => `${colunaSegura(coluna)} = $${index + 1}`).join(', ');
  const query = `UPDATE ${tabela} SET ${setClause} WHERE nome = $${colunas.length + 1}`;
  await pool.query(query, [...Object.values(dados), nomeAtual]);
  // O selo "Novo" escolhido pelo admin acompanha o nome novo
  if (dados.nome && dados.nome !== nomeAtual) {
    await pool.query(`UPDATE selo_novo SET nome = $1 WHERE tabela = $2 AND nome = $3`, [dados.nome, tabela, nomeAtual]);
  }

  // Histórico: só as colunas que mudaram de verdade, com o valor de antes e o de depois
  const nomeFinal = dados.nome || nomeAtual;
  const depois = await buscarPorNome(tabela, nomeFinal);
  const mudaram = colunas.filter(coluna => historico.normalizarValor(atual[coluna]) !== historico.normalizarValor(depois[coluna]));
  if (mudaram.length === 0) return null;

  const pegar = (linha) => Object.fromEntries(mudaram.map(coluna => [coluna, linha[coluna]]));
  let descricao = `Alterado: ${nomeFinal}`;
  if (mudaram.includes('phaseout')) {
    descricao = depois.phaseout === PHASEOUT_EM_LINHA ? `Voltou para linha: ${nomeFinal}` : `Movido para phaseout: ${nomeFinal}`;
    if (depois.phaseout === PHASEOUT_EM_LINHA && atual.phaseout === PHASEOUT_EM_REVISAO) descricao = `Liberado na tabela (saiu da revisão): ${nomeFinal}`;
    if (depois.phaseout === PHASEOUT_EM_REVISAO) descricao = `Enviado para revisão: ${nomeFinal}`;
  }
  if (mudaram.includes('nome')) {
    descricao = `Renomeado: ${nomeAtual} → ${nomeFinal}`;
  }
  return historico.registrar({
    acao: historico.ACOES.ALTERAR,
    tabela,
    nome: nomeFinal,
    descricao: opcoes.descricao || descricao,
    antes: pegar(atual),
    depois: pegar(depois),
    origem: opcoes.origem,
    lote: opcoes.lote,
  });
};

const remover = async (tabela, nome, opcoes = {}) => {
  validarTabela(tabela);
  // Guarda o equipamento inteiro antes de apagar: é o que permite desfazer a remoção
  const atual = await buscarPorNome(tabela, nome);
  if (!atual) {
    throw new ErroEquipamento('Equipamento não encontrado', 404);
  }
  await pool.query(`DELETE FROM ${tabela} WHERE nome = $1`, [nome]);

  return historico.registrar({
    acao: historico.ACOES.REMOVER,
    tabela,
    nome,
    descricao: opcoes.descricao || `Removido: ${nome}`,
    antes: atual,
    origem: opcoes.origem,
    lote: opcoes.lote,
  });
};

// Mesma alteração em vários equipamentos de uma vez (ex.: método de recuperação na página "Phaseout" do admin).
// itens = [{ tabela, nome }]. Fica tudo num lote só no histórico ("Desfazer tudo" volta todos).
const alterarVarios = async (itens, campos, opcoes = {}) => {
  if (!Array.isArray(itens) || itens.length === 0) {
    throw new ErroEquipamento('Escolha pelo menos um equipamento');
  }
  if (!campos || Object.keys(campos).length === 0) {
    throw new ErroEquipamento('Nenhuma alteração informada');
  }
  if ('nome' in campos) {
    throw new ErroEquipamento('O nome não pode ser alterado em vários equipamentos de uma vez');
  }
  const lote = `painel:${new Date().toISOString()}`;
  let alterados = 0;
  const erros = [];
  for (const { tabela, nome } of itens) {
    try {
      if (await alterar(tabela, nome, campos, { ...opcoes, lote })) alterados++;
    } catch (err) {
      if (!(err instanceof ErroEquipamento)) throw err;
      erros.push(`${nome}: ${err.message}`);
    }
  }
  return { alterados, erros, lote };
};

// Atalho para trocar só o status (usado pela sincronização com a planilha)
const definirStatus = (tabela, nome, status, data = null, opcoes = {}) => alterar(tabela, nome, { status, data }, opcoes);

module.exports = {
  TABELAS,
  COLUNAS_DE_CONTROLE,
  STATUS,
  PHASEOUT_EM_LINHA,
  PHASEOUT_EM_REVISAO,
  contarDadosTecnicos,
  ErroEquipamento,
  tabelaValida,
  listarEmLinha,
  listarDescontinuados,
  listarEmRevisao,
  listarResumo,
  listarNomes,
  seloNovo,
  definirSeloNovo,
  valoresPorColuna,
  buscarPorNome,
  adicionar,
  restaurar,
  alterar,
  alterarVarios,
  remover,
  definirStatus,
};
