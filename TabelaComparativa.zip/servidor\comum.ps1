﻿# Funções usadas pelos scripts da pasta "servidor" (instalar, reiniciar, desinstalar, backup).
$ErrorActionPreference = 'Stop'
$Pasta = Split-Path -Parent $PSScriptRoot          # pasta principal da tabela
$Env = Join-Path $Pasta 'back\.env'
$NomeTarefa = 'Tabela Comparativa'
$NomeTarefaBackup = 'Tabela Comparativa - Backup'
$NomeRegraFirewall = 'Tabela Comparativa'

function Ler-Env([string]$chave) {
  if (-not (Test-Path $Env)) { return $null }
  foreach ($linha in [IO.File]::ReadAllLines($Env)) {
    $t = $linha.Trim()
    if ($t.StartsWith('#') -or -not $t.Contains('=')) { continue }
    $i = $t.IndexOf('=')
    if ($t.Substring(0, $i).Trim() -eq $chave) { return $t.Substring($i + 1).Trim().Trim('"').Trim("'") }
  }
  return $null
}

function Gravar-Env([string]$chave, [string]$valor) {
  $linhas = [Collections.Generic.List[string]]([IO.File]::ReadAllLines($Env))
  $achou = $false
  for ($i = 0; $i -lt $linhas.Count; $i++) {
    if ($linhas[$i] -match "^\s*$chave\s*=") { $linhas[$i] = "$chave=$valor"; $achou = $true }
  }
  if (-not $achou) { $linhas.Add("$chave=$valor") }
  [IO.File]::WriteAllLines($Env, $linhas, (New-Object Text.UTF8Encoding $false))
}

# postgres://usuario:senha@servidor:5432/banco -> partes
function Ler-Banco {
  $url = Ler-Env 'DATABASE_URL'
  if (-not $url) { $url = 'postgres://postgres:admin@localhost:5432/postgres' }
  $u = [Uri]$url
  $usuario, $senha = $u.UserInfo.Split(':', 2)
  return @{
    Usuario = [Uri]::UnescapeDataString($usuario); Senha = [Uri]::UnescapeDataString($senha)
    Servidor = $u.Host; Porta = $(if ($u.Port -gt 0) { $u.Port } else { 5432 }); Banco = $u.AbsolutePath.TrimStart('/')
  }
}

# psql.exe / pg_dump.exe da maior versão instalada do PostgreSQL
function Achar-Postgres([string]$programa) {
  $achado = Get-ChildItem "$env:ProgramFiles\PostgreSQL\*\bin\$programa" -ErrorAction SilentlyContinue |
    Sort-Object { [int]($_.Directory.Parent.Name -replace '\D', '') } -Descending | Select-Object -First 1
  if ($achado) { return $achado.FullName }
  $cmd = Get-Command $programa -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}

# Encerra a tabela (o vigia e o node que ele ligou)
function Parar-Tabela {
  Stop-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue
  $indice = (Join-Path $Pasta 'back\index.js')
  Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='cmd.exe'" |
    Where-Object { $_.CommandLine -and ($_.CommandLine.Contains($indice) -or $_.CommandLine.Contains((Join-Path $PSScriptRoot 'servico.cmd'))) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

# Espera a tabela responder; devolve $true se respondeu
function Esperar-Tabela([int]$porta, [int]$segundos = 60) {
  for ($i = 0; $i -lt $segundos; $i += 2) {
    try {
      $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 "http://localhost:$porta/api/colunas"
      if ($r.StatusCode -eq 200) { return $true }
    } catch {}
    Start-Sleep 2
  }
  return $false
}

function Exigir-Administrador {
  $eu = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
  if (-not $eu.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Execute como administrador (botão direito no .bat > Executar como administrador).'
  }
}
