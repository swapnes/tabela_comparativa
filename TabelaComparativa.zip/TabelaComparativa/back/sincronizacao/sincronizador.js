// Sincronização da tabela com a planilha de preços (abas "Tabela" e "Encerramentos").
// Um modelo está EM LINHA quando tem pelo menos uma versão (código) na aba Tabela que não está em Encerramentos.
// (Se todas as versões que aparecem na Tabela também estão em Encerramentos, ele foi descontinuado.)
// - modelo em linha na planilha e fora do banco               -> adicionado EM REVISÃO (fora das tabelas) + alerta;
//   o admin preenche os dados técnicos e libera na página "Revisão" (ou remove, se não for nosso)
//   (modelos da linha Future/FT não são adicionados: aparecem na análise para adicionar manualmente, se quiser;
//    versões remanufaturadas "REM" são ignoradas; modelos com todas as versões encerradas não são adicionados)
// - equipamento em linha no banco que não está mais em linha  -> movido para phaseout + alerta
//   (com o mês e o substituto direto da aba Encerramentos; sem ela, a data de hoje)
// - equipamento em phaseout que voltou a estar em linha        -> volta para em linha + alerta
// - equipamento em phaseout que está em Encerramentos          -> data de phaseout e substituto conforme a planilha
const pool = require('../db');
const equipamentos = require('../equipamentos');
const historico = require('../historico');
const { TIPOS_ALERTA, criarAlerta, renomearEquipamento } = require('../alertas');
const { lerPlanilha, normalizarTexto } = require('./leitorPlanilha');
const { caminhoDaPlanilha, caminhoDosEncerramentos, infoDaPlanilha, infoDosEncerramentos } = require('./arquivoPlanilha');
const { interpretarProduto, chaveDoModelo, compararModelos } = require('./regras');
const { lerEncerramentos, resumoDoEncerramento, mesParaTexto } = require('./encerramentos');

// Colunas que não são copiadas de um equipamento antigo para um novo (identidade e status)
const NAO_COPIAR = equipamentos.COLUNAS_DE_CONTROLE;

// Liga cada modelo novo da planilha ao equipamento cadastrado mais parecido (que não está na planilha),
// para manter os dados técnicos em vez de cadastrar do zero. Cada equipamento é usado uma vez só.
const parearComCadastrados = (novos, cadastradosForaDaPlanilha) => {
  const candidatos = [];
  for (const novo of novos) {
    for (const antigo of cadastradosForaDaPlanilha) {
      if (antigo.tabela !== novo.tabela) continue;
      const { nota, soCor } = compararModelos(novo.nome, antigo.nome);
      if (nota > 0) candidatos.push({ novo, antigo, nota, soCor });
    }
  }
  candidatos.sort((a, b) => b.nota - a.nota);

  const pares = [];
  const novosUsados = new Set();
  const antigosUsados = new Set();
  for (const candidato of candidatos) {
    if (novosUsados.has(candidato.novo) || antigosUsados.has(candidato.antigo)) continue;
    novosUsados.add(candidato.novo);
    antigosUsados.add(candidato.antigo);
    pares.push(candidato);
  }
  return pares;
};

// Colunas usadas da "Tabela de Preços Distribuição" (o cabeçalho é encontrado sozinho)
const COLUNA_NOME = 'Descrição do Produto';
const COLUNA_RESUMO = 'Produto/Resumo';
const COLUNA_CODIGO = 'Código Produto';

// Trava de segurança: acima disso, o phaseout só acontece se o admin confirmar no painel
const LIMITE_PHASEOUT = 10;

let emAndamento = false;

const hojeISO = () => {
  const hoje = new Date();
  const mes = String(hoje.getMonth() + 1).padStart(2, '0');
  const dia = String(hoje.getDate()).padStart(2, '0');
  return `${hoje.getFullYear()}-${mes}-${dia}`;
};

const acharColuna = (colunas, nome) => colunas.find(coluna => normalizarTexto(coluna) === normalizarTexto(nome));

const ordenarPorTabelaENome = (lista) =>
  lista.sort((a, b) => a.tabela.localeCompare(b.tabela) || a.nome.localeCompare(b.nome, 'pt-BR', { numeric: true }));

// Compara a planilha com o banco e devolve o que precisa mudar (não altera nada)
const calcularMudancas = async () => {
  const { colunas, linhas } = await lerPlanilha({
    arquivo: caminhoDaPlanilha(),
    colunaNome: COLUNA_NOME,
    colunasUteis: [COLUNA_NOME, COLUNA_RESUMO, COLUNA_CODIGO],
  });

  const tituloNome = acharColuna(colunas, COLUNA_NOME);
  if (!tituloNome) {
    throw new Error(`Coluna "${COLUNA_NOME}" não encontrada na planilha. Colunas encontradas: ${colunas.join(', ') || '(nenhuma)'}`);
  }
  const tituloResumo = acharColuna(colunas, COLUNA_RESUMO);
  const tituloCodigo = acharColuna(colunas, COLUNA_CODIGO);

  // Aba Encerramentos (opcional: sem ela, vale só a aba Tabela, como antes)
  const arquivoEncerramentos = caminhoDosEncerramentos();
  const encerramentos = arquivoEncerramentos ? await lerEncerramentos(arquivoEncerramentos) : null;
  const codigoEncerrado = (codigo) => Boolean(encerramentos && codigo && encerramentos.codigos.has(String(codigo).trim()));

  // Um modelo aparece em várias linhas (uma por estado, kits com HD, versão Manaus...): agrupa pela chave
  const naTabela = new Map();
  // Versões remanufaturadas ("REM") não entram na tabela nem contam como "em linha": só aparecem na análise
  const remanufaturados = new Map();
  for (const linha of linhas) {
    const produto = interpretarProduto(linha[tituloNome], tituloResumo ? linha[tituloResumo] : '');
    if (!produto) continue;

    const chave = chaveDoModelo(produto.modelo);
    if (produto.remanufaturado) {
      remanufaturados.set(chave, { tabela: produto.tabela, nome: produto.modelo });
      continue;
    }
    if (!naTabela.has(chave)) {
      naTabela.set(chave, { nome: produto.modelo, tabela: produto.tabela, future: produto.future, codigos: new Set(), ativo: false });
    }
    const modelo = naTabela.get(chave);
    const codigo = tituloCodigo ? linha[tituloCodigo] : '';
    if (codigo) modelo.codigos.add(codigo);
    // Em linha: pelo menos uma versão que não está em Encerramentos (linha sem código conta como em linha)
    if (!codigoEncerrado(codigo)) modelo.ativo = true;
  }

  // Só os modelos em linha valem como "na planilha"; os que têm todas as versões encerradas ficam à parte
  const modelos = new Map([...naTabela].filter(([, modelo]) => modelo.ativo));
  const encerradosNaTabela = [...naTabela].filter(([, modelo]) => !modelo.ativo);

  // Planilha errada ou vazia: não mexe em nada para não mandar tudo para phaseout
  if (modelos.size === 0) {
    throw new Error('Nenhum produto da nossa linha encontrado na planilha. Sincronização cancelada por segurança.');
  }

  const todosCadastrados = await equipamentos.listarResumo();
  const chavesCadastradas = new Set(todosCadastrados.map(equipamento => chaveDoModelo(equipamento.nome)));
  const emLinha = (equipamento) => equipamento.phaseout === equipamentos.PHASEOUT_EM_LINHA;
  // Em revisão (produto novo ainda não liberado): a planilha não muda o status dele; só o admin libera ou remove
  const emRevisao = (equipamento) => equipamento.phaseout === equipamentos.PHASEOUT_EM_REVISAO;

  // Data e substituto direto de um modelo encerrado (null se não está na aba Encerramentos).
  // O substituto aparece com o nome usado na nossa tabela, quando o modelo está cadastrado.
  const nomePorChave = new Map();
  for (const equipamento of todosCadastrados) {
    const chave = chaveDoModelo(equipamento.nome);
    if (!nomePorChave.has(chave) || emLinha(equipamento)) nomePorChave.set(chave, equipamento.nome);
  }
  const nomeCadastrado = (nome) => nomePorChave.get(chaveDoModelo(nome)) || nome;
  const encerramentoDe = (nome) => {
    const modelo = encerramentos && encerramentos.modelos.get(chaveDoModelo(nome));
    return modelo ? resumoDoEncerramento(modelo, nomeCadastrado) : null;
  };

  // A tabela antiga tem alguns modelos cadastrados duas vezes com grafias diferentes ("NVD 1404 P" em linha e
  // "NVD 1404-P" em phaseout). Usa um só (o em linha, se houver) e avisa dos outros, sem mexer neles.
  const porChave = new Map();
  for (const equipamento of todosCadastrados) {
    const chave = `${equipamento.tabela}|${chaveDoModelo(equipamento.nome)}`;
    if (!porChave.has(chave)) porChave.set(chave, []);
    porChave.get(chave).push(equipamento);
  }
  const cadastrados = [];
  const duplicados = [];
  for (const grupo of porChave.values()) {
    const principal = grupo.find(emLinha) || grupo[0];
    cadastrados.push(principal);
    grupo.filter(equipamento => equipamento !== principal)
      .forEach(equipamento => duplicados.push({ tabela: equipamento.tabela, nome: equipamento.nome, principal: principal.nome }));
  }
  const nomeJaUsado = (tabela, nome) => todosCadastrados.some(equipamento => equipamento.tabela === tabela && equipamento.nome === nome);

  // Equipamentos que o admin removeu no painel: se aparecerem na planilha, NÃO voltam sozinhos (ficam em Removidos)
  const removidosPorChave = new Map(
    (await historico.listarRemovidos()).map(registro => [chaveDoModelo(registro.nome), registro])
  );

  const novos = [];
  const futureIgnorados = [];
  const removidosNaPlanilha = [];
  for (const [chave, modelo] of modelos) {
    if (chavesCadastradas.has(chave)) continue;
    const item = { tabela: modelo.tabela, nome: modelo.nome, codigos: [...modelo.codigos] };
    const removido = removidosPorChave.get(chave);
    if (removido) {
      removidosNaPlanilha.push({ ...item, removidoComo: removido.nome, removidoEm: removido.criado_em, historicoId: removido.id });
      continue;
    }
    (modelo.future ? futureIgnorados : novos).push(item);
  }

  const estaNaPlanilha = (equipamento) => modelos.has(chaveDoModelo(equipamento.nome));

  // Já reconhecido, mas escrito diferente da planilha ("MHDX 1116 C", "VHD 3240 Full Color +"): padroniza o nome.
  // Se o nome da planilha já estiver em uso (cadastro em dobro), mantém o nome atual.
  const renomeados = [];
  const nomeFinal = new Map(); // equipamento -> nome depois da padronização
  for (const equipamento of cadastrados) {
    const modelo = modelos.get(chaveDoModelo(equipamento.nome));
    nomeFinal.set(equipamento, equipamento.nome);
    if (modelo && modelo.nome !== equipamento.nome && !nomeJaUsado(equipamento.tabela, modelo.nome)) {
      renomeados.push({ tabela: equipamento.tabela, de: equipamento.nome, para: modelo.nome });
      nomeFinal.set(equipamento, modelo.nome);
    }
  }

  // Vai para phaseout com o mês e o substituto da aba Encerramentos (sem ela: data de hoje, sem substituto)
  let paraPhaseout = cadastrados
    .filter(equipamento => emLinha(equipamento) && !estaNaPlanilha(equipamento))
    .map(({ tabela, nome }) => {
      const encerramento = encerramentoDe(nome);
      return {
        tabela,
        nome,
        data: encerramento?.data || hojeISO(),
        mes: encerramento?.mes ? mesParaTexto(encerramento.mes) : null,
        substituto: encerramento?.substituto || null,
      };
    });

  // Usa o nome depois da padronização: é por ele que o equipamento é encontrado na hora de aplicar
  const voltaram = cadastrados
    .filter(equipamento => !emLinha(equipamento) && !emRevisao(equipamento) && estaNaPlanilha(equipamento))
    .map(equipamento => ({ tabela: equipamento.tabela, nome: nomeFinal.get(equipamento) }));

  // Já em phaseout e na aba Encerramentos: corrige o mês de phaseout e preenche o substituto direto.
  // Só mexe no que mudou (o dia de uma data digitada no painel é mantido se o mês for o mesmo);
  // um substituto digitado no painel só é trocado quando a planilha traz outro.
  const atualizadosPeloEncerramento = [];
  for (const equipamento of cadastrados) {
    if (emLinha(equipamento) || emRevisao(equipamento) || estaNaPlanilha(equipamento)) continue;
    const encerramento = encerramentoDe(equipamento.nome);
    if (!encerramento) continue;
    const item = { tabela: equipamento.tabela, nome: nomeFinal.get(equipamento) };
    if (encerramento.mes && equipamento.mes !== encerramento.mes) {
      Object.assign(item, { data: encerramento.data, mes: mesParaTexto(encerramento.mes), mesAntes: equipamento.phaseout || null });
    }
    if (encerramento.substituto && encerramento.substituto !== equipamento.substituto) {
      Object.assign(item, { substituto: encerramento.substituto, substitutoAntes: equipamento.substituto || null });
    }
    if (item.data || item.substituto) atualizadosPeloEncerramento.push(item);
  }

  // Na aba Tabela, mas com todas as versões encerradas e fora do nosso cadastro: não são adicionados
  const encerradosNaoAdicionados = encerradosNaTabela
    .filter(([chave, modelo]) => !chavesCadastradas.has(chave) && !modelo.future)
    .map(([, modelo]) => {
      const encerramento = encerramentoDe(modelo.nome);
      return { tabela: modelo.tabela, nome: modelo.nome, mes: encerramento?.mes ? mesParaTexto(encerramento.mes) : null, substituto: encerramento?.substituto || null };
    });

  // Modelos novos que parecem um equipamento cadastrado que saiu da planilha (nome diferente ou variação):
  // - diferença só de cor: cadastra o novo copiando os dados (a outra cor pode ser outro produto)
  // - cadastrado em linha: é o mesmo equipamento -> renomeia para o nome da planilha (mantém tudo),
  //   a não ser que ele esteja na aba Encerramentos (aí foi descontinuado de verdade: só copia os dados)
  // - cadastrado em phaseout: cadastra o novo copiando os dados técnicos do antigo
  const foraDaPlanilha = cadastrados.filter(equipamento => !estaNaPlanilha(equipamento) && !emRevisao(equipamento));

  // Em revisão, mas não está mais em linha na planilha (saiu da aba Tabela ou foi encerrado): só avisa na análise
  const revisaoForaDaPlanilha = cadastrados
    .filter(equipamento => emRevisao(equipamento) && !estaNaPlanilha(equipamento))
    .map(({ tabela, nome }) => ({ tabela, nome }));
  for (const { novo, antigo, soCor } of parearComCadastrados(novos, foraDaPlanilha)) {
    if (emLinha(antigo) && !soCor && !encerramentoDe(antigo.nome)) {
      renomeados.push({ tabela: novo.tabela, de: antigo.nome, para: novo.nome });
      novos.splice(novos.indexOf(novo), 1);
      paraPhaseout = paraPhaseout.filter(item => !(item.tabela === antigo.tabela && item.nome === antigo.nome));
    } else {
      novo.copiarDe = antigo.nome;
    }
  }

  return {
    linhasLidas: linhas.length,
    produtosNaPlanilha: modelos.size,
    semEncerramentos: !encerramentos,
    modelosEncerrados: encerramentos ? encerramentos.modelos.size : 0,
    encerradosNaoAdicionados: ordenarPorTabelaENome(encerradosNaoAdicionados),
    atualizadosPeloEncerramento: ordenarPorTabelaENome(atualizadosPeloEncerramento),
    revisaoForaDaPlanilha: ordenarPorTabelaENome(revisaoForaDaPlanilha),
    novos: ordenarPorTabelaENome(novos),
    duplicados,
    renomeados: renomeados.sort((a, b) => a.para.localeCompare(b.para, 'pt-BR', { numeric: true })),
    futureIgnorados: ordenarPorTabelaENome(futureIgnorados),
    removidosNaPlanilha: ordenarPorTabelaENome(removidosNaPlanilha),
    remanufaturadosIgnorados: ordenarPorTabelaENome([...remanufaturados.values()]),
    paraPhaseout: ordenarPorTabelaENome(paraPhaseout),
    voltaram: ordenarPorTabelaENome(voltaram),
  };
};

// Dados técnicos de um equipamento cadastrado, para copiar num modelo novo
const dadosTecnicosDe = async (tabela, nome) => {
  const antigo = await equipamentos.buscarPorNome(tabela, nome);
  const dados = {};
  if (!antigo) return dados;
  for (const [coluna, valor] of Object.entries(antigo)) {
    if (NAO_COPIAR.includes(coluna) || valor === null || valor === '' || typeof valor === 'object') continue;
    dados[coluna] = valor;
  }
  return dados;
};

const registrar = (inicio, modo, sucesso, resumo) =>
  pool.query(
    `INSERT INTO sincronizacoes (iniciada_em, finalizada_em, modo, sucesso, resumo) VALUES ($1, now(), $2, $3, $4)`,
    [inicio, modo, sucesso, JSON.stringify(resumo)]
  );

// aplicar = false: só analisa (mostra o que mudaria, sem alterar nada)
// ignorarLimite = true: aplica o phaseout mesmo acima de EXCEL_LIMITE_PHASEOUT (confirmado pelo admin)
const sincronizar = async ({ aplicar, ignorarLimite = false }) => {
  if (emAndamento) {
    throw new equipamentos.ErroEquipamento('Já existe uma sincronização em andamento', 409);
  }
  emAndamento = true;

  const inicio = new Date();
  const modo = aplicar ? 'aplicada' : 'simulacao';
  const planilha = infoDaPlanilha();
  const arquivoEncerramentos = infoDosEncerramentos();
  const resumo = {
    planilha: planilha ? planilha.nome : null,
    encerramentos: arquivoEncerramentos ? arquivoEncerramentos.nome : null,
    aplicado: false,
    bloqueado: false,
    limitePhaseout: LIMITE_PHASEOUT,
    erros: [],
  };

  try {
    Object.assign(resumo, await calcularMudancas());
    resumo.bloqueado = !ignorarLimite && resumo.paraPhaseout.length > LIMITE_PHASEOUT;

    if (aplicar) {
      // Todas as mudanças desta aplicação ficam no mesmo lote do histórico (desfazer tudo de uma vez)
      const doLote = { origem: 'planilha', lote: `planilha:${inicio.toISOString()}` };
      resumo.lote = doLote.lote;
      const adicionados = [];
      const movidos = [];
      const retornados = [];
      const renomeados = [];

      // Mesmo equipamento com o nome escrito diferente: passa a usar o nome da planilha (dados mantidos)
      for (const { tabela, de, para } of resumo.renomeados) {
        try {
          await equipamentos.alterar(tabela, de, { nome: para }, { ...doLote, descricao: `Nome padronizado pela planilha: ${de} → ${para}` });
          await renomearEquipamento(tabela, de, para);
          renomeados.push(para);
          await criarAlerta({
            tipo: TIPOS_ALERTA.RENOMEADO_AUTOMATICO,
            tabela,
            nome: para,
            mensagem: `${de} agora se chama ${para} (nome da planilha). Os dados técnicos foram mantidos.`,
          });
        } catch (err) {
          resumo.erros.push(`Renomear ${de} para ${para}: ${err.message}`);
        }
      }

      for (const { tabela, nome, copiarDe } of resumo.novos) {
        try {
          const dadosCopiados = copiarDe ? await dadosTecnicosDe(tabela, copiarDe) : {};
          // Câmera "BLACK"/"PRETA": a cor da case é preta (senão o banco antigo preenche "Branco" por padrão)
          if (tabela === 'cameras' && /(^|\s)(BLACK|PRETA)(\s|$)/i.test(nome)) {
            dadosCopiados.cores = 'Preta';
          }
          // Entra em revisão: só aparece na tabela depois que o admin preencher os dados e liberar
          // (às vezes o produto aparece na planilha antes do lançamento de verdade, ou nem é da nossa linha)
          await equipamentos.adicionar(tabela, { ...dadosCopiados, nome, status: equipamentos.STATUS.REVISAO }, { ...doLote, descricao: `Adicionado pela planilha (em revisão): ${nome}${copiarDe ? ` (dados de ${copiarDe})` : ''}` });
          adicionados.push(nome);
          await criarAlerta({
            tipo: TIPOS_ALERTA.DADOS_PENDENTES,
            tabela,
            nome,
            mensagem: copiarDe
              ? `${nome} apareceu na planilha e está em Revisão, com os dados técnicos de ${copiarDe}. Confira, complete e libere na tabela (ou remova, se não for nosso).`
              : `${nome} apareceu na planilha e está em Revisão. Preencha os dados técnicos e libere na tabela (ou remova, se não for nosso).`,
          });
        } catch (err) {
          resumo.erros.push(`Adicionar ${nome}: ${err.message}`);
        }
      }

      // Na planilha, mas removido pelo admin: não volta; só avisa (um alerta por equipamento, sem repetir)
      for (const { tabela, nome, removidoComo, removidoEm } of resumo.removidosNaPlanilha) {
        const quando = new Date(removidoEm).toLocaleDateString('pt-BR');
        await criarAlerta({
          tipo: TIPOS_ALERTA.REMOVIDO_NA_PLANILHA,
          tabela,
          nome: removidoComo,
          mensagem: `${nome} está na planilha de preços, mas você removeu ${removidoComo} em ${quando}. Ele NÃO foi adicionado de novo e continua em Removidos. Se foi engano, restaure em Removidos.`,
        }).catch(err => resumo.erros.push(`Alerta de ${nome}: ${err.message}`));
      }

      if (resumo.bloqueado) {
        await criarAlerta({
          tipo: TIPOS_ALERTA.SINCRONIZACAO_BLOQUEADA,
          mensagem: `A planilha tiraria ${resumo.paraPhaseout.length} equipamentos de linha de uma vez (limite: ${LIMITE_PHASEOUT}). Nenhum foi movido para phaseout. Confira a análise no painel.`,
        });
      } else {
        for (const { tabela, nome, data, mes, substituto } of resumo.paraPhaseout) {
          try {
            await equipamentos.alterar(
              tabela,
              nome,
              { status: equipamentos.STATUS.DESCONTINUADO, data, ...(substituto ? { substituto } : {}) },
              { ...doLote, descricao: `Movido para phaseout pela planilha: ${nome}${mes ? ` (encerrado em ${mes})` : ''}` }
            );
            movidos.push(nome);
            await criarAlerta({
              tipo: TIPOS_ALERTA.PHASEOUT_AUTOMATICO,
              tabela,
              nome,
              mensagem: mes
                ? `${nome} está nos Encerramentos (${mes}) e foi movido para o phaseout.${substituto ? ` Substituto: ${substituto}.` : ''}`
                : `${nome} saiu da planilha e foi movido para o phaseout.`,
            });
          } catch (err) {
            resumo.erros.push(`Phaseout de ${nome}: ${err.message}`);
          }
        }
      }

      for (const { tabela, nome } of resumo.voltaram) {
        try {
          await equipamentos.definirStatus(tabela, nome, equipamentos.STATUS.EM_LINHA, null, { ...doLote, descricao: `Voltou para linha pela planilha: ${nome}` });
          retornados.push(nome);
          await criarAlerta({
            tipo: TIPOS_ALERTA.VOLTOU_LINHA,
            tabela,
            nome,
            mensagem: `${nome} voltou a aparecer na planilha e está em linha de novo.`,
          });
        } catch (err) {
          resumo.erros.push(`Voltar ${nome} para linha: ${err.message}`);
        }
      }

      // Phaseout já existente: mês e substituto conforme a aba Encerramentos (um alerta só, no resumo)
      let atualizados = 0;
      for (const { tabela, nome, data, mes, substituto } of resumo.atualizadosPeloEncerramento) {
        try {
          const campos = {
            ...(data ? { status: equipamentos.STATUS.DESCONTINUADO, data } : {}),
            ...(substituto ? { substituto } : {}),
          };
          const partes = [mes && `phaseout ${mes}`, substituto && `substituto ${substituto}`].filter(Boolean).join(', ');
          if (await equipamentos.alterar(tabela, nome, campos, { ...doLote, descricao: `Encerramentos da planilha: ${nome} (${partes})` })) {
            atualizados++;
          }
        } catch (err) {
          resumo.erros.push(`Atualizar o phaseout de ${nome}: ${err.message}`);
        }
      }

      if (adicionados.length + movidos.length + retornados.length + renomeados.length + atualizados > 0) {
        await criarAlerta({
          tipo: TIPOS_ALERTA.RESUMO_SINCRONIZACAO,
          mensagem: `Planilha aplicada em ${inicio.toLocaleString('pt-BR')}: ${adicionados.length} novos na Revisão, ${renomeados.length} renomeados (dados mantidos), ${movidos.length} movidos para phaseout, ${retornados.length} voltaram para linha, ${atualizados} no phaseout com data/substituto atualizados pelos Encerramentos.`,
        });
      }

      resumo.aplicado = true;
    }

    await registrar(inicio, modo, resumo.erros.length === 0, resumo);
    return resumo;
  } catch (err) {
    resumo.erro = err.message;
    await registrar(inicio, modo, false, resumo).catch(erro => console.log('Erro ao registrar sincronização:', erro));
    if (aplicar) {
      await criarAlerta({
        tipo: TIPOS_ALERTA.ERRO_SINCRONIZACAO,
        mensagem: `Falha na sincronização com a planilha: ${err.message}`,
      }).catch(erro => console.log('Erro ao criar alerta:', erro));
    }
    throw err;
  } finally {
    emAndamento = false;
  }
};

const obterStatus = async () => {
  const ultima = await pool.query(`SELECT * FROM sincronizacoes ORDER BY id DESC LIMIT 1`);
  const planilha = infoDaPlanilha();
  return {
    configurada: Boolean(planilha),
    planilha,
    encerramentos: infoDosEncerramentos(),
    limitePhaseout: LIMITE_PHASEOUT,
    emAndamento,
    ultima: ultima.rows[0] || null,
  };
};

module.exports = { sincronizar, obterStatus };
