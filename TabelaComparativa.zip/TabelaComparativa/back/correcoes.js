// Correções de dados que acompanham uma atualização do sistema.
// Rodam sozinhas, UMA vez, no banco onde a tabela estiver (ex.: o servidor), ao ligar a tabela.
// Segurança:
// - cada valor só é trocado se ainda estiver com o valor errado conhecido ("de");
//   se alguém já corrigiu pelo painel, aquele item fica como está;
// - tudo vai para o Histórico (lote "correcao:<id>", dá para desfazer tudo de uma vez);
// - a tabela "correcoes_aplicadas" guarda o que já rodou (não roda de novo).
const pool = require('./db');

const GENERICO = 'https://www.intelbras.com/pt-br/seguranca-eletronica';
const SITE = 'https://www.intelbras.com/pt-br/';

// Links conferidos no site da Intelbras em 03/10/2026 (cada página aberta no navegador)
const link = (tabela, nome, de, para) => ({ tabela, nome, coluna: 'link', de: [].concat(de), para: SITE + para });

// Característica a excluir (os valores ficam guardados no Histórico; o Desfazer recria a coluna com eles)
const excluirColuna = (tabela, coluna, rotulo) => ({ tipo: 'excluirColuna', tabela, coluna, nome: rotulo, rotulo });

const CORRECOES = [
  {
    id: '2026-10-03-links',
    descricao: 'Links das páginas dos produtos conferidos no site da Intelbras',
    itens: [
      // Estavam na página genérica "Segurança eletrônica" (links enviados pelo Gabriel)
      link('cameras', 'VIPW 1210 MINI DUAL', [GENERICO, null, ''], 'camera-ip-wi-fi-profissional-vipw-1210-mini-dual'),
      link('cameras', 'VIPW 1200 MINI SD DUAL AP', [GENERICO, null, ''], 'camera-ip-wi-fi-profissional-vipw-1200-mini-sd-dual-ap'),
      // A Intelbras mudou o endereço da página
      link('cameras', 'VHL 1220 B G9', SITE + 'camera-full-color-vhl-1220-b-g9', 'camera-full-hd-vhl-1220-b-g9'),
      link('cameras', 'VHL 1220 D G9', SITE + 'camera-full-color-com-resolucao-full-hd-vhl-1220-d-g9', 'camera-resolucao-full-hd-vhl-1220-d-g9'),
      link('gravadores', 'iNVD 5232-16P', SITE + 'gravador-digital-de-video-com-32-canais-ip-invd-523216-p', 'gravador-digital-de-video-com-32-canais-ip-invd-5232-16p'),
      // A página de produto saiu do site; o endereço antigo leva para a página de suporte/download
      link('cameras', 'VIPC 1220 D FC+', SITE + 'camera-ip-da-serie-1000-com-full-color-e-ir-vip-1220-d-fc', 'ajuda-download/download/camera-ip-da-serie-1000-com-full-color-e-ir-vip-1220-d-fc'),
      link('cameras', 'VIPW 1220 D FC+', SITE + 'camera-ip-wi-fi-profissional-com-full-color-e-ir-vipw-1220-d-fc', 'ajuda-download/download/camera-ip-wi-fi-profissional-com-full-color-e-ir-vipw-1220-d-fc'),
      link('gravadores', 'iMHDX 3116', SITE + 'gravador-digital-de-video-inteligente-de-16-canais-imhdx-3116', 'ajuda-download/download/gravador-digital-de-video-inteligente-de-16-canais-imhdx-3116'),
      link('gravadores', 'NVD 1404', SITE + 'gravador-digital-de-video-nvr-nvd-1404', 'ajuda-download/download/gravador-digital-de-video-nvr-nvd-1404'),
      link('gravadores', 'NVD 1408', SITE + 'gravador-digital-de-video-nvr-nvd-1408', 'ajuda-download/download/gravador-digital-de-video-nvr-nvd-1408'),
      link('gravadores', 'NVD 3316-PLUS', SITE + 'gravador-digital-de-video-em-rede-nvd-3316-plus', 'ajuda-download/download/gravador-digital-de-video-em-rede-nvd-3316-plus'),
    ],
  },
  {
    // Pedido do Gabriel em 03/10/2026: stream extra e classificação da inteligência perimetral saem da tabela
    id: '2026-10-03-remover-colunas',
    descricao: 'Características retiradas da tabela',
    itens: [
      excluirColuna('gravadores', 'ip_stream_extra', 'IP stream extra'),
      excluirColuna('gravadores', 'hdcvi_stream_extra', 'HDCVI stream extra'),
      excluirColuna('gravadores', 'ahd_stream_extra', 'AHD stream extra'),
      excluirColuna('gravadores', 'hdtvi_stream_extra', 'HDTVI stream extra'),
      excluirColuna('gravadores', 'analogico_stream_extra', 'Analógico stream extra'),
      excluirColuna('gravadores', 'inteligencia_perimetral_classificacao', 'Classificação da inteligência perimetral'),
    ],
  },
  {
    // Pedido do Gabriel em 05/10/2026: produto novo só aparece na tabela depois de preenchido e liberado.
    // Os que já estão em linha sem nenhum dado técnico vão para a página "Revisão".
    id: '2026-10-05-revisao-sem-dados',
    descricao: 'Em linha sem dados técnicos: enviado para revisão',
    itens: [{ tipo: 'revisarSemDados', nome: 'em linha sem dados técnicos' }],
  },
];

// Equipamentos em linha sem nenhuma característica técnica preenchida -> status "em revisão"
const revisarSemDados = async (equipamentos, correcao, resumo) => {
  for (const tabela of equipamentos.TABELAS) {
    const linhas = (await pool.query(`SELECT * FROM ${tabela} WHERE phaseout = $1`, [equipamentos.PHASEOUT_EM_LINHA]).catch(() => ({ rows: [] }))).rows;
    for (const linha of linhas) {
      if (equipamentos.contarDadosTecnicos(linha) > 0) continue;
      await equipamentos.alterar(tabela, linha.nome, { status: equipamentos.STATUS.REVISAO }, {
        origem: 'sistema',
        lote: `correcao:${correcao.id}`,
        descricao: `${correcao.descricao}: ${linha.nome}`,
      });
      resumo.trocados.push(linha.nome);
    }
  }
};

const aplicarCorrecoes = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS correcoes_aplicadas (
      id TEXT PRIMARY KEY,
      aplicada_em TIMESTAMPTZ NOT NULL DEFAULT now(),
      resumo JSONB
    );
  `);
  const equipamentos = require('./equipamentos');
  const colunas = require('./colunas');
  for (const correcao of CORRECOES) {
    const ja = await pool.query(`SELECT 1 FROM correcoes_aplicadas WHERE id = $1`, [correcao.id]);
    if (ja.rowCount > 0) continue;

    const resumo = { trocados: [], mantidos: [] };
    for (const item of correcao.itens) {
      if (item.tipo === 'revisarSemDados') {
        await revisarSemDados(equipamentos, correcao, resumo);
        continue;
      }
      if (item.tipo === 'excluirColuna') {
        const existe = (await colunas.colunasExistentes())[item.tabela]?.includes(item.coluna);
        if (!existe) {
          resumo.mantidos.push(`${item.rotulo} (já não existia)`);
          continue;
        }
        await colunas.excluir(item.tabela, item.coluna, { origem: 'sistema', lote: `correcao:${correcao.id}`, rotulo: item.rotulo });
        resumo.trocados.push(item.rotulo);
        continue;
      }
      const atual = await equipamentos.buscarPorNome(item.tabela, item.nome).catch(() => null);
      const valor = atual ? (atual[item.coluna] ?? null) : undefined;
      const errado = atual && item.de.some(de => (de === null ? valor === null : String(valor ?? '') === de));
      if (!errado) {
        resumo.mantidos.push(`${item.nome} (${atual ? 'já estava diferente' : 'não encontrado'})`);
        continue;
      }
      await equipamentos.alterar(item.tabela, item.nome, { [item.coluna]: item.para }, {
        origem: 'sistema',
        lote: `correcao:${correcao.id}`,
        descricao: `${correcao.descricao}: ${item.nome}`,
      });
      resumo.trocados.push(item.nome);
    }
    await pool.query(`INSERT INTO correcoes_aplicadas (id, resumo) VALUES ($1, $2)`, [correcao.id, JSON.stringify(resumo)]);
    console.log(`Correção "${correcao.id}": ${resumo.trocados.length} trocados, ${resumo.mantidos.length} mantidos.`);
  }
};

module.exports = { aplicarCorrecoes, CORRECOES };
