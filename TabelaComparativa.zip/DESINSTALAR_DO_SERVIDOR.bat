@echo off
rem Para a tabela e tira do inicio automatico. NAO apaga o banco nem os arquivos.
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\desinstalar.ps1"
echo.
pause
