// Guarda os arquivos da planilha importados pelo painel do admin em back/dados/:
// - planilha.*      aba "Tabela" (produtos à venda)
// - encerramentos.* aba "Encerramentos" (produtos descontinuados, com data e substituto direto)
// O tipo é descoberto pelo conteúdo (a aba Encerramentos tem a coluna "Substituto Direto"),
// então não importa em que ordem os arquivos são escolhidos.
const fs = require('fs');
const path = require('path');
const { ErroEquipamento } = require('../equipamentos');
const { decodificar, normalizarTexto } = require('./leitorPlanilha');

const PASTA = path.join(__dirname, '..', 'dados');
const EXTENSOES = ['.csv', '.xlsx', '.xlsm'];
const TAMANHO_MAXIMO = 200 * 1024 * 1024; // 200 MB

const TIPOS = {
  tabela: { base: 'planilha', info: 'planilha.json' },
  encerramentos: { base: 'encerramentos', info: 'encerramentos.json' },
};

const caminhoDe = (tipo) => {
  for (const extensao of EXTENSOES) {
    const caminho = path.join(PASTA, `${TIPOS[tipo].base}${extensao}`);
    if (fs.existsSync(caminho)) return caminho;
  }
  return '';
};

const caminhoDaPlanilha = () => caminhoDe('tabela');
const caminhoDosEncerramentos = () => caminhoDe('encerramentos');

const infoDe = (tipo) => {
  const caminho = caminhoDe(tipo);
  if (!caminho) return null;

  let info = {};
  try {
    info = JSON.parse(fs.readFileSync(path.join(PASTA, TIPOS[tipo].info), 'utf8'));
  } catch {
    info = {};
  }
  const estatisticas = fs.statSync(caminho);
  return {
    nome: info.nomeOriginal || path.basename(caminho),
    atualizadaEm: info.enviadaEm || estatisticas.mtime,
    tamanho: estatisticas.size,
  };
};

const infoDaPlanilha = () => infoDe('tabela');
const infoDosEncerramentos = () => infoDe('encerramentos');

// Aba Encerramentos? CSV: procura a coluna "Substituto Direto" no começo do arquivo; xlsx: pelo nome do arquivo
const descobrirTipo = (arquivo, nomeOriginal) => {
  if (path.extname(arquivo).toLowerCase() !== '.csv') {
    return /encerramento/.test(normalizarTexto(nomeOriginal)) ? 'encerramentos' : 'tabela';
  }
  const inicio = Buffer.alloc(64 * 1024);
  const descritor = fs.openSync(arquivo, 'r');
  const lidos = fs.readSync(descritor, inicio, 0, inicio.length, 0);
  fs.closeSync(descritor);
  return normalizarTexto(decodificar(inicio.subarray(0, lidos))).includes('substituto direto') ? 'encerramentos' : 'tabela';
};

// Grava o arquivo enviado no corpo da requisição no lugar do anterior do mesmo tipo. Devolve o tipo.
const salvarPlanilhaEnviada = (req, nomeOriginal) => new Promise((resolve, reject) => {
  const extensao = path.extname(nomeOriginal || '').toLowerCase();
  if (!EXTENSOES.includes(extensao)) {
    return reject(new ErroEquipamento('Envie um arquivo .csv ou .xlsx'));
  }
  if (Number(req.headers['content-length']) > TAMANHO_MAXIMO) {
    return reject(new ErroEquipamento('Arquivo muito grande (máximo 200 MB)', 413));
  }

  fs.mkdirSync(PASTA, { recursive: true });
  const temporario = path.join(PASTA, `envio-${Date.now()}${extensao}`);
  const destino = fs.createWriteStream(temporario);
  let tamanho = 0;
  let cancelado = false;

  const cancelar = (erro) => {
    if (cancelado) return;
    cancelado = true;
    destino.destroy();
    fs.unlink(temporario, () => {});
    reject(erro);
  };

  req.on('data', parte => { tamanho += parte.length; });
  req.on('aborted', () => cancelar(new ErroEquipamento('Envio do arquivo interrompido')));
  req.on('error', cancelar);
  destino.on('error', cancelar);

  destino.on('finish', () => {
    if (cancelado) return;
    if (tamanho === 0) {
      return cancelar(new ErroEquipamento('O arquivo enviado está vazio'));
    }
    try {
      const tipo = descobrirTipo(temporario, nomeOriginal);
      const { base, info } = TIPOS[tipo];
      // Troca o arquivo anterior do mesmo tipo pelo novo
      for (const outra of EXTENSOES) {
        const antiga = path.join(PASTA, `${base}${outra}`);
        if (fs.existsSync(antiga)) fs.unlinkSync(antiga);
      }
      fs.renameSync(temporario, path.join(PASTA, `${base}${extensao}`));
      fs.writeFileSync(path.join(PASTA, info), JSON.stringify({ nomeOriginal: nomeOriginal, enviadaEm: new Date().toISOString() }));
      resolve(tipo);
    } catch (err) {
      cancelar(err);
    }
  });

  req.pipe(destino);
});

module.exports = { caminhoDaPlanilha, caminhoDosEncerramentos, infoDaPlanilha, infoDosEncerramentos, salvarPlanilhaEnviada };
