﻿# Cópia do banco da Tabela Comparativa em back\dados\backups (tabela-AAAA-MM-DD.sql). Guarda os 30 mais recentes.
# Roda todo dia pela tarefa "Tabela Comparativa - Backup"; pode rodar na mão também (BACKUP_AGORA.bat).
. "$PSScriptRoot\comum.ps1"
$pasta = Join-Path $Pasta 'back\dados\backups'
New-Item -ItemType Directory -Force $pasta | Out-Null
$pgDump = Achar-Postgres 'pg_dump.exe'
if (-not $pgDump) { throw 'pg_dump.exe não encontrado.' }
$b = Ler-Banco
$env:PGPASSWORD = $b.Senha
$arquivo = Join-Path $pasta ("tabela-{0:yyyy-MM-dd}.sql" -f (Get-Date))
& $pgDump -U $b.Usuario -h $b.Servidor -p $b.Porta -d $b.Banco --no-owner --no-privileges -f $arquivo
if ($LASTEXITCODE -ne 0) { throw 'Falha no backup.' }
Get-ChildItem $pasta -Filter 'tabela-*.sql' | Sort-Object Name -Descending | Select-Object -Skip 30 | Remove-Item -Force
Write-Host "Backup salvo: $arquivo"
