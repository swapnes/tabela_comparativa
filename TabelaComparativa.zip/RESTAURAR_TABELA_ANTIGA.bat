@echo off
setlocal
title Restaurar tabela antiga
rem ==================================================================
rem  Coloca os dados da tabela antiga (copia feita com pg_dump no
rem  servidor do trabalho) no banco deste computador.
rem  Uso: deixe o arquivo tabela_antiga.sql nesta pasta e de dois
rem  cliques aqui, ou arraste o arquivo .sql sobre este .bat.
rem  So funciona se a tabela daqui ainda estiver vazia.
rem ==================================================================

set "PASTA=%~dp0"
set "NODE=node"
where node >nul 2>nul
if errorlevel 1 set "NODE=C:\Program Files\nodejs\node.exe"

set "ARQUIVO=%~1"
if "%ARQUIVO%"=="" set "ARQUIVO=%PASTA%tabela_antiga.sql"

cd /d "%PASTA%back"
"%NODE%" ferramentas\restaurarTabelaAntiga.js "%ARQUIVO%"
echo.
pause
