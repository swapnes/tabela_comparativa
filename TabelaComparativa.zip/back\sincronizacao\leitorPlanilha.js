// Lê a planilha de produtos (.csv ou .xlsx) e devolve { colunas, linhas },
// onde cada linha é um objeto { 'Título da coluna': 'valor em texto' }.
// - Acha sozinho a linha do cabeçalho (a planilha de preços tem 2 linhas de título antes dele).
// - CSV em UTF-8 ou Windows-1252 (o padrão do Excel em português).
// - colunasUteis: se informado, só essas colunas são guardadas (a planilha de preços tem ~90 mil linhas).
const fs = require('fs');
const path = require('path');

// Sem acentos, minúsculo e sem espaços nas pontas: "Descrição do Produto" = "descricao do produto"
const normalizarTexto = (texto) => String(texto ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

const LIMITE_BUSCA_CABECALHO = 50;

const criarSeletorDeColunas = (colunasUteis) => {
  if (!colunasUteis || colunasUteis.length === 0) return () => true;
  const uteis = new Set(colunasUteis.filter(Boolean).map(normalizarTexto));
  return (titulo) => uteis.has(normalizarTexto(titulo));
};

// Linha do cabeçalho: a informada no .env ou a primeira que tiver a coluna do nome do produto
const criarDetectorDeCabecalho = (linhaCabecalho, colunaNome) => {
  const alvo = normalizarTexto(colunaNome);
  return (valores, numeroLinha) => {
    if (linhaCabecalho > 0) return numeroLinha === linhaCabecalho;
    return valores.some(valor => normalizarTexto(valor) === alvo);
  };
};

const erroCabecalho = (colunaNome) =>
  new Error(`Não encontrei o cabeçalho da planilha (coluna "${colunaNome}") nas primeiras ${LIMITE_BUSCA_CABECALHO} linhas.`);

// ---------- CSV ----------

const decodificar = (buffer) => {
  if (buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    return buffer.toString('utf8', 3);
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  } catch {
    // Não é UTF-8: CSV salvo pelo Excel em português (Windows-1252)
    try {
      return new TextDecoder('windows-1252').decode(buffer);
    } catch {
      return buffer.toString('latin1');
    }
  }
};

// Percorre o CSV chamando aoRegistro(campos) para cada linha. Respeita campos entre aspas ("a; b" e "").
const percorrerCsv = (texto, separador, aoRegistro) => {
  const tamanho = texto.length;
  let registro = [];
  let i = 0;

  while (i < tamanho) {
    let campo;
    if (texto[i] === '"') {
      let inicio = i + 1;
      campo = '';
      for (;;) {
        const aspa = texto.indexOf('"', inicio);
        if (aspa === -1) {
          campo += texto.slice(inicio);
          i = tamanho;
          break;
        }
        campo += texto.slice(inicio, aspa);
        if (texto[aspa + 1] === '"') {
          campo += '"';
          inicio = aspa + 2;
        } else {
          i = aspa + 1;
          break;
        }
      }
    } else {
      const inicio = i;
      while (i < tamanho && texto[i] !== separador && texto[i] !== '\n' && texto[i] !== '\r') i++;
      campo = texto.slice(inicio, i);
    }

    // Ignora qualquer coisa entre a aspa de fechamento e o próximo separador
    while (i < tamanho && texto[i] !== separador && texto[i] !== '\n' && texto[i] !== '\r') i++;
    registro.push(campo);

    if (i >= tamanho) break;
    if (texto[i] === separador) {
      i++;
      continue;
    }
    // Fim de linha (\n ou \r\n)
    if (texto[i] === '\r' && texto[i + 1] === '\n') i++;
    i++;
    if (aoRegistro(registro) === false) return;
    registro = [];
  }

  if (registro.length > 0) aoRegistro(registro);
};

const lerCsv = (arquivo, { linhaCabecalho, colunaNome, colunasUteis }) => {
  const conteudo = decodificar(fs.readFileSync(arquivo));

  // Separador que mais aparece no começo do arquivo (Excel em português usa ";")
  const amostra = conteudo.slice(0, 5000);
  const separador = [';', '\t', ','].reduce((melhor, atual) =>
    amostra.split(atual).length > amostra.split(melhor).length ? atual : melhor
  );

  const ehCabecalho = criarDetectorDeCabecalho(linhaCabecalho, colunaNome);
  const colunaUtil = criarSeletorDeColunas(colunasUteis);
  let cabecalho = null;
  let indices = [];
  let numeroLinha = 0;
  const linhas = [];

  percorrerCsv(conteudo, separador, (valores) => {
    numeroLinha++;
    if (!cabecalho) {
      if (ehCabecalho(valores, numeroLinha)) {
        cabecalho = valores.map(titulo => titulo.trim());
        indices = cabecalho
          .map((titulo, indice) => ({ titulo, indice }))
          .filter(({ titulo }) => titulo && colunaUtil(titulo));
      }
      return numeroLinha < LIMITE_BUSCA_CABECALHO || cabecalho !== null;
    }

    if (!valores.some(valor => valor.trim() !== '')) return true;
    const linha = {};
    for (const { titulo, indice } of indices) {
      linha[titulo] = (valores[indice] || '').trim();
    }
    linhas.push(linha);
    return true;
  });

  if (!cabecalho) throw erroCabecalho(colunaNome);
  return { colunas: cabecalho.filter(Boolean), linhas };
};

// ---------- XLSX ----------

// Converte o conteúdo de uma célula do exceljs em texto
const textoDaCelula = (valor) => {
  if (valor === null || valor === undefined) return '';
  if (valor instanceof Date) return valor.toISOString().slice(0, 10);
  if (typeof valor === 'object') {
    if (Array.isArray(valor.richText)) return valor.richText.map(parte => parte.text).join('');
    if (valor.text !== undefined) return textoDaCelula(valor.text);       // link
    if (valor.result !== undefined) return textoDaCelula(valor.result);   // fórmula
    return '';
  }
  return String(valor);
};

const lerXlsx = async (arquivo, { aba, linhaCabecalho, colunaNome, colunasUteis }) => {
  let ExcelJS;
  try {
    ExcelJS = require('exceljs');
  } catch {
    throw new Error('Biblioteca "exceljs" não instalada: rode "npm install" na pasta back');
  }

  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(arquivo);

  const planilha = aba ? workbook.getWorksheet(aba) : workbook.worksheets[0];
  if (!planilha) {
    const abas = workbook.worksheets.map(w => w.name).join(', ');
    throw new Error(aba ? `Aba "${aba}" não encontrada. Abas da planilha: ${abas}` : 'A planilha não tem abas');
  }

  const ehCabecalho = criarDetectorDeCabecalho(linhaCabecalho, colunaNome);
  const colunaUtil = criarSeletorDeColunas(colunasUteis);
  let linhaDoCabecalho = 0;
  let cabecalho = [];

  for (let numero = 1; numero <= Math.min(planilha.rowCount, LIMITE_BUSCA_CABECALHO); numero++) {
    const valores = [];
    planilha.getRow(numero).eachCell({ includeEmpty: true }, (celula, coluna) => {
      valores[coluna] = textoDaCelula(celula.value).trim();
    });
    if (ehCabecalho(valores.map(valor => valor || ''), numero)) {
      linhaDoCabecalho = numero;
      cabecalho = valores;
      break;
    }
  }
  if (!linhaDoCabecalho) throw erroCabecalho(colunaNome);

  const linhas = [];
  planilha.eachRow({ includeEmpty: false }, (row, numeroLinha) => {
    if (numeroLinha <= linhaDoCabecalho) return;
    const linha = {};
    row.eachCell({ includeEmpty: true }, (celula, numeroColuna) => {
      const titulo = cabecalho[numeroColuna];
      if (titulo && colunaUtil(titulo)) {
        linha[titulo] = textoDaCelula(celula.value).trim();
      }
    });
    linhas.push(linha);
  });

  return { colunas: cabecalho.filter(Boolean), linhas };
};

// opcoes: { arquivo, aba, linhaCabecalho (0 = automático), colunaNome, colunasUteis }
const lerPlanilha = async (opcoes) => {
  const { arquivo } = opcoes;
  if (!arquivo || !fs.existsSync(arquivo)) {
    throw new Error('Nenhuma planilha encontrada. Importe a planilha pelo painel do admin.');
  }

  const extensao = path.extname(arquivo).toLowerCase();
  if (extensao === '.xlsx' || extensao === '.xlsm') {
    return lerXlsx(arquivo, opcoes);
  }
  if (extensao === '.csv' || extensao === '.txt') {
    return lerCsv(arquivo, opcoes);
  }
  throw new Error('Formato de planilha não suportado. Use .csv ou .xlsx (arquivos .xls antigos: salve como .xlsx)');
};

module.exports = { lerPlanilha, normalizarTexto, decodificar };
