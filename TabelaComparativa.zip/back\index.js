// Servidor da Tabela Comparativa: um único programa serve o site (front/build) e a API (/api).
// Acesse http://localhost:3777 (ou http://IP-DA-MAQUINA:3777 na rede).
const path = require('path');
const fs = require('fs');
const express = require('express');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const config = require('./config');
const pool = require('./db');
const equipamentos = require('./equipamentos');
const alertas = require('./alertas');
const colunas = require('./colunas');
const historico = require('./historico');
const { prepararBanco } = require('./banco');
const { obterRotina } = require('./rotina');
const { sincronizar, obterStatus, ultimaAplicacao } = require('./sincronizacao/sincronizador');
const { salvarPlanilhaEnviada } = require('./sincronizacao/arquivoPlanilha');
const authenticateToken = require('./middleware/authMiddleware');

const app = express();
const api = express.Router();

api.use(express.json());
// Respostas da API nunca ficam guardadas no navegador: depois de salvar, sempre aparece o dado novo
api.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// Erros de validação (ErroEquipamento) vão com a mensagem para o usuário; o resto é logado
const responderErro = (res, err, mensagemPadrao) => {
  if (err instanceof equipamentos.ErroEquipamento) {
    return res.status(err.status).send(err.message);
  }
  console.log(err);
  res.status(500).send(mensagemPadrao);
}

// Erros da planilha (arquivo, colunas...) têm mensagens úteis para o admin: vão para o front
const responderErroSincronizacao = (res, err) => {
  if (err instanceof equipamentos.ErroEquipamento) {
    return res.status(err.status).send(err.message);
  }
  console.log(err);
  res.status(500).send(err.message || 'Erro na sincronização');
};

// Compara textos em tempo constante (evita descobrir a senha medindo o tempo de resposta)
const textoIgual = (a, b) => {
  const hashA = crypto.createHash('sha256').update(String(a ?? '')).digest();
  const hashB = crypto.createHash('sha256').update(String(b ?? '')).digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

const esperar = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const idValido = (valor) => Number.isInteger(Number(valor)) ? Number(valor) : null;

// ---------- Login (usuário e senha únicos definidos no back/.env) ----------

api.post('/login', async (req, res) => {
  const { usuario, senha } = req.body || {};

  if (!config.adminUsuario || !config.adminSenha) {
    return res.status(503).send('Login não configurado: defina ADMIN_USUARIO e ADMIN_SENHA no back/.env');
  }

  const usuarioCorreto = textoIgual(usuario, config.adminUsuario);
  const senhaCorreta = textoIgual(senha, config.adminSenha);
  if (!usuarioCorreto || !senhaCorreta) {
    // Atraso para dificultar tentativas repetidas de senha
    await esperar(1000);
    return res.status(401).send('Usuário ou senha inválidos');
  }

  const token = jwt.sign({ usuario: config.adminUsuario }, config.jwtSecret, { expiresIn: authenticateToken.VALIDADE });
  res.status(200).json({ token });
});

// ---------- Tabela (pública) ----------

// Características criadas pelo painel (nome amigável e categoria), usadas na tabela e nos formulários
api.get('/colunas', async (req, res) => {
  try {
    res.status(200).json({ colunas: await colunas.listar(), existentes: await colunas.colunasExistentes() });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar as características');
  }
});

// Quando a planilha de preços foi aplicada por último ("Atualizada em" no topo da tabela)
api.get('/atualizacao', async (req, res) => {
  try {
    res.status(200).json({ ultima: await ultimaAplicacao() });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar a data de atualização');
  }
});

// Contador de acessos (Home): o site soma 1 a cada carregamento da página e mostra o total
api.post('/acessos', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `INSERT INTO contador_acessos (id, total) VALUES (1, 1)
       ON CONFLICT (id) DO UPDATE SET total = contador_acessos.total + 1 RETURNING total`
    );
    res.status(200).json({ total: Number(rows[0].total) });
  } catch (err) {
    responderErro(res, err, 'Erro ao contar o acesso');
  }
});

// Aba de Phaseout: só equipamentos descontinuados
api.get('/phaseout_senhas', async (req, res) => {
  try {
    res.status(200).json({ 'tabela': await equipamentos.listarDescontinuados() });
  } catch (err) {
    responderErro(res, err, 'Erro ao fazer pesquisa');
  }
})

// Ficha técnica de um descontinuado (aba Phaseout): o cadastro inteiro, com os dados técnicos de quando estava em linha
api.get('/phaseout_senhas/:tabela/:nome', async (req, res) => {
  try {
    const equipamento = await equipamentos.buscarPorNome(req.params.tabela, req.params.nome);
    const descontinuado = equipamento && ![equipamentos.PHASEOUT_EM_LINHA, equipamentos.PHASEOUT_EM_REVISAO].includes(equipamento.phaseout);
    if (!descontinuado) return res.status(404).send('Equipamento não encontrado no phaseout');
    res.status(200).json(equipamento);
  } catch (err) {
    responderErro(res, err, 'Erro ao fazer pesquisa');
  }
})

// ---------- Recuperação de senha (aba pública) ----------
// A página chama os serviços da Intelbras direto do navegador (como o site antigo do 10.1.45.193:8053). Se o
// navegador for bloqueado (CORS, por estar em outro endereço), ela chama por aqui: o servidor só encaminha
// para estes endereços e devolve a resposta como veio.
const DESTINOS_DA_RECUPERACAO = [
  'https://apim.intelbras.com.br/oauth2/token',
  'https://api-v2.intelbras.com.br/products/1.0.0/serial-numbers/',
  'https://recsenha-callcenter.intelbras.com.br/ws/gera_senha/',
  'https://api.intelbras.com.br/token',
  'https://api.intelbras.com.br/contrasenha/1.0.0/',
];
const CABECALHOS_DA_RECUPERACAO = ['authorization', 'content-type', 'accept'];

api.post('/recuperacao/encaminhar', async (req, res) => {
  const { url, metodo, cabecalhos = {}, corpo } = req.body || {};
  let endereco;
  try {
    endereco = new URL(url);
  } catch {
    return res.status(400).send('Endereço inválido');
  }
  const semConsulta = `${endereco.origin}${endereco.pathname}`;
  if (!DESTINOS_DA_RECUPERACAO.some(destino => semConsulta.startsWith(destino))) {
    return res.status(400).send('Endereço não permitido');
  }
  const post = metodo === 'POST';
  try {
    const resposta = await fetch(endereco, {
      method: post ? 'POST' : 'GET',
      headers: Object.fromEntries(Object.entries(cabecalhos).filter(([nome]) => CABECALHOS_DA_RECUPERACAO.includes(nome.toLowerCase()))),
      body: post && typeof corpo === 'string' ? corpo : undefined,
      signal: AbortSignal.timeout(20000),
    });
    res.status(resposta.status).type(resposta.headers.get('content-type') || 'application/json').send(await resposta.text());
  } catch (err) {
    res.status(502).send(`O servidor da tabela não conseguiu falar com a Intelbras: ${err.message}`);
  }
});

// ---------- Admin: equipamentos (precisa de login) ----------

api.get('/buscarEquipamentos', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ 'tabela': await equipamentos.listarNomes(req.query.tabela) });
  } catch (err) {
    responderErro(res, err, 'Erro ao fazer pesquisa');
  }
})

api.get('/buscarEquipamento/:tabela/:equipamento', authenticateToken, async (req, res) => {
  try {
    const equipamento = await equipamentos.buscarPorNome(req.params.tabela, req.params.equipamento);
    if (!equipamento) {
      return res.status(404).send('Equipamento não encontrado');
    }
    res.status(200).json({ 'tabela': [equipamento] });
  } catch (err) {
    responderErro(res, err, 'Erro ao fazer pesquisa');
  }
})

// Corpo: { tabela, status: 'em_linha' | 'descontinuado', data (se descontinuado), ...colunas }
api.post('/adicionarCadastroEquipamento', authenticateToken, async (req, res) => {
  const { tabela, ...campos } = req.body;
  try {
    const historicoId = await equipamentos.adicionar(tabela, campos);
    res.status(200).json({ mensagem: 'Cadastro adicionado', historicoId });
  } catch (err) {
    responderErro(res, err, 'Erro ao adicionar cadastro');
  }
})

api.delete('/removerEquipamento', authenticateToken, async (req, res) => {
  const { modelo, tabela } = req.body
  try {
    const historicoId = await equipamentos.remover(tabela, modelo);
    await alertas.resolverDoEquipamento(tabela, modelo).catch(err => console.log('Erro ao resolver alertas:', err));
    res.status(200).json({ mensagem: 'Equipamento removido', historicoId })
  } catch (err) {
    responderErro(res, err, 'Erro ao remover equipamento');
  }
})

// :modelo é o nome atual no banco; o corpo pode trazer um "nome" novo, "status" e as colunas alteradas
api.put('/alterarCadastroEquipamento/:modelo', authenticateToken, async (req, res) => {
  const { tabela, ...camposParaAtualizar } = req.body;
  const nomeAtual = req.params.modelo;
  try {
    const historicoId = await equipamentos.alterar(tabela, nomeAtual, camposParaAtualizar);
    if (camposParaAtualizar.nome && camposParaAtualizar.nome !== nomeAtual) {
      await alertas.renomearEquipamento(tabela, nomeAtual, camposParaAtualizar.nome).catch(err => console.log('Erro ao atualizar alertas:', err));
    }
    res.status(200).json({ mensagem: 'Cadastro alterado', historicoId });
  } catch (err) {
    responderErro(res, err, 'Erro ao alterar cadastro');
  }
});

// Mesma alteração em vários equipamentos: { itens: [{ tabela, nome }], campos: { metodos_de_recuperacao: '...' } }
api.post('/admin/alterarVarios', authenticateToken, async (req, res) => {
  const { itens, campos } = req.body || {};
  try {
    res.status(200).json(await equipamentos.alterarVarios(itens, campos));
  } catch (err) {
    responderErro(res, err, 'Erro ao alterar os equipamentos');
  }
});

// Valores já usados em cada característica (sugestões no formulário)
api.get('/admin/valores/:tabela', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ valores: await equipamentos.valoresPorColuna(req.params.tabela) });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar sugestões');
  }
});

// Nova característica (coluna/filtro): { tabela, rotulo, categoria }
api.post('/admin/colunas', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await colunas.criar(req.body || {}));
  } catch (err) {
    responderErro(res, err, 'Erro ao criar a característica');
  }
});

// Características de um tipo e em quantos equipamentos cada uma está preenchida (página "Características")
api.get('/admin/colunas/:tabela/uso', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await colunas.uso(req.params.tabela));
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar as características');
  }
});

// Nome, categoria e "escondida" de qualquer característica: { tabela, coluna, rotulo, categoria, oculta }
api.put('/admin/colunas', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await colunas.salvar(req.body || {}));
  } catch (err) {
    responderErro(res, err, 'Erro ao salvar a característica');
  }
});

// Valores diferentes de uma característica e quantos equipamentos usam cada um (padronizar a escrita)
api.get('/admin/colunas/:tabela/:coluna/valores', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ valores: await colunas.valores(req.params.tabela, req.params.coluna) });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar os valores');
  }
});

// Troca um valor por outro em todos os equipamentos que o usam: { de, para, rotulo } → { alterados, erros, lote }
api.post('/admin/colunas/:tabela/:coluna/trocar-valor', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await colunas.trocarValor(req.params.tabela, req.params.coluna, req.body || {}));
  } catch (err) {
    responderErro(res, err, 'Erro ao trocar o valor');
  }
});

// Exclui qualquer característica (?rotulo= nome mostrado na tela). Os valores ficam no histórico para desfazer.
api.delete('/admin/colunas/:tabela/:coluna', authenticateToken, async (req, res) => {
  try {
    const historicoId = await colunas.excluir(req.params.tabela, req.params.coluna, { rotulo: req.query.rotulo });
    res.status(200).json({ mensagem: 'Característica excluída', historicoId });
  } catch (err) {
    responderErro(res, err, 'Erro ao excluir a característica');
  }
});

// ---------- Admin: histórico de alterações (consultar e desfazer) ----------

// ?limite=&origem=admin|planilha|desfazer&tipo=equipamentos|caracteristicas&busca=
api.get('/admin/historico', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ historico: await historico.listar(req.query) });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar o histórico');
  }
});

api.post('/admin/historico/:id/desfazer', authenticateToken, async (req, res) => {
  const id = idValido(req.params.id);
  if (id === null) {
    return res.status(400).send('Registro inválido');
  }
  try {
    res.status(200).json(await historico.desfazer(id));
  } catch (err) {
    responderErro(res, err, 'Erro ao desfazer');
  }
});

// Equipamentos removidos pelo painel que continuam fora da tabela (aba "Removidos").
// Restaurar = POST /api/admin/historico/:id/desfazer com o id da remoção.
api.get('/admin/removidos', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ removidos: await historico.listarRemovidos() });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar os removidos');
  }
});

// Produtos novos da planilha aguardando liberação (página "Revisão"): não aparecem nas tabelas até serem liberados
api.get('/admin/revisao', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ revisao: await equipamentos.listarEmRevisao() });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar os produtos em revisão');
  }
});

// Libera um produto da revisão para a tabela (em linha): { tabela, nome }. Só com dados técnicos preenchidos.
// Selo "Novo" de um produto: GET mostra o que vale hoje e a escolha do admin; PUT { tabela, nome, acao: 'marcar' | 'tirar' | 'automatico' }
api.get('/admin/selo-novo/:tabela/:nome', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await equipamentos.seloNovo(req.params.tabela, req.params.nome));
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar o selo Novo');
  }
});

api.put('/admin/selo-novo', authenticateToken, async (req, res) => {
  const { tabela, nome, acao } = req.body || {};
  try {
    res.status(200).json(await equipamentos.definirSeloNovo(tabela, nome, acao));
  } catch (err) {
    responderErro(res, err, 'Erro ao salvar o selo Novo');
  }
});

api.post('/admin/revisao/liberar', authenticateToken, async (req, res) => {
  const { tabela, nome } = req.body || {};
  try {
    const atual = equipamentos.tabelaValida(tabela) ? await equipamentos.buscarPorNome(tabela, nome) : null;
    if (!atual || atual.phaseout !== equipamentos.PHASEOUT_EM_REVISAO) {
      return res.status(404).send('Produto não encontrado na revisão');
    }
    if (equipamentos.contarDadosTecnicos(atual) === 0) {
      return res.status(400).send(`Preencha os dados técnicos de ${nome} antes de liberar`);
    }
    const historicoId = await equipamentos.alterar(tabela, nome, { status: equipamentos.STATUS.EM_LINHA });
    await alertas.resolverDoEquipamento(tabela, nome).catch(err => console.log('Erro ao resolver alertas:', err));
    res.status(200).json({ mensagem: `${nome} liberado na tabela`, historicoId });
  } catch (err) {
    responderErro(res, err, 'Erro ao liberar o produto');
  }
});

// Desfaz todas as mudanças de uma aplicação da planilha: { lote }
api.post('/admin/historico/desfazer-lote', authenticateToken, async (req, res) => {
  if (!req.body || !req.body.lote) {
    return res.status(400).send('Informe o lote');
  }
  try {
    res.status(200).json(await historico.desfazerLote(req.body.lote));
  } catch (err) {
    responderErro(res, err, 'Erro ao desfazer');
  }
});

// ---------- Admin: alertas e planilha de preços ----------

api.get('/admin/alertas', authenticateToken, async (req, res) => {
  try {
    res.status(200).json({ alertas: await alertas.listarAbertos() });
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar alertas');
  }
});

api.post('/admin/alertas/:id/resolver', authenticateToken, async (req, res) => {
  const id = idValido(req.params.id);
  if (id === null) {
    return res.status(400).send('Alerta inválido');
  }
  try {
    if (!await alertas.resolver(id)) {
      return res.status(404).send('Alerta não encontrado');
    }
    res.status(200).send('Alerta resolvido');
  } catch (err) {
    responderErro(res, err, 'Erro ao resolver alerta');
  }
});

// Avisos de rotina do painel: última aplicação da planilha e último backup diário
api.get('/admin/rotina', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await obterRotina());
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar os avisos de rotina');
  }
});

api.get('/admin/sincronizacao', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await obterStatus());
  } catch (err) {
    responderErro(res, err, 'Erro ao buscar status da planilha');
  }
});

// Corpo: { aplicar: false } analisa (não altera nada); { aplicar: true, ignorarLimite?: true } aplica as mudanças
api.post('/admin/sincronizacao', authenticateToken, async (req, res) => {
  try {
    res.status(200).json(await sincronizar({
      aplicar: req.body?.aplicar === true,
      ignorarLimite: req.body?.ignorarLimite === true,
    }));
  } catch (err) {
    responderErroSincronizacao(res, err);
  }
});

// Importa um arquivo da planilha (aba Tabela ou aba Encerramentos; o tipo é descoberto pelo conteúdo):
// o corpo é o próprio arquivo (.csv ou .xlsx), ?nome= é o nome original.
// Depois de salvar, já faz a análise (sem alterar nada) e devolve o resultado com o tipo recebido.
// ?analisar=nao: só salva (o painel usa no primeiro de dois arquivos enviados juntos).
api.post('/admin/planilha', authenticateToken, async (req, res) => {
  try {
    const tipo = await salvarPlanilhaEnviada(req, String(req.query.nome || ''));
    if (req.query.analisar === 'nao') return res.status(200).json({ tipo });
    res.status(200).json({ tipo, ...(await sincronizar({ aplicar: false })) });
  } catch (err) {
    responderErroSincronizacao(res, err);
  }
});

// /api/cameras?modelo=VHD,VHL, /api/gravadores?modelo=MHDX, /api/baluns, /api/extensores: só equipamentos em linha
// (rota genérica: precisa ficar por último na API)
api.get('/:tabela', async (req, res) => {
  const modelos = req.query.modelo ? String(req.query.modelo).split(',') : [];
  try {
    res.status(200).json({ 'tabela': await equipamentos.listarEmLinha(req.params.tabela, modelos) });
  } catch (err) {
    responderErro(res, err, 'Erro ao fazer pesquisa no banco');
  }
});

app.use('/api', api);

// ---------- Site (front/build) ----------

const PASTA_SITE = path.join(__dirname, '..', 'front', 'build');
if (fs.existsSync(path.join(PASTA_SITE, 'index.html'))) {
  app.use(express.static(PASTA_SITE));
  // Qualquer outro endereço (/cameras, /login, /home...) é uma página do site
  app.get('*', (req, res) => res.sendFile(path.join(PASTA_SITE, 'index.html')));
} else {
  console.warn('Site não encontrado em front/build: rode "npm run build" na pasta front.');
}

const agora = () => new Date().toLocaleString('pt-BR');

// Erro inesperado: registra e encerra; o serviço (servidor/servico.cmd) liga de novo em segundos
process.on('uncaughtException', (err) => {
  console.log(`[${agora()}] Erro inesperado, reiniciando:`, err);
  process.exit(1);
});
process.on('unhandledRejection', (err) => {
  console.log(`[${agora()}] Promessa rejeitada sem tratamento:`, err);
});

const servidor = app.listen(config.porta, () => {
  console.log(`[${agora()}] Tabela Comparativa rodando em http://localhost:${config.porta}`);
});
// Porta ocupada ou bloqueada: encerra com erro (o serviço tenta de novo)
servidor.on('error', (err) => {
  console.log(`[${agora()}] Não foi possível usar a porta ${config.porta}:`, err.message);
  process.exit(1);
});
// Mantém as conexões abertas por mais tempo que o padrão (5 s): evita que um envio de planilha
// reaproveite uma conexão que o servidor acabou de fechar ("conexão fechada inesperadamente")
servidor.keepAliveTimeout = 65 * 1000;
servidor.headersTimeout = 66 * 1000;

// Ao ligar o PC, o PostgreSQL pode subir depois da tabela: tenta de novo a cada 10 s até conseguir
const prepararComRepeticao = (tentativa = 1) => prepararBanco()
  .then(() => console.log(`[${agora()}] Banco de dados pronto.`))
  .catch(err => {
    console.log(`[${agora()}] Banco ainda indisponível (tentativa ${tentativa}): ${err.message || err.code || 'sem conexão'}. Tentando de novo em 10 s.`);
    setTimeout(() => prepararComRepeticao(tentativa + 1), 10 * 1000);
  });
prepararComRepeticao();
