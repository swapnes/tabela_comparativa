﻿# Reinicia a Tabela Comparativa (use depois de atualizar arquivos ou mudar o back\.env).
. "$PSScriptRoot\comum.ps1"
Exigir-Administrador
if (-not (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue)) { throw 'A tabela ainda não foi instalada neste PC (use INSTALAR_NO_SERVIDOR.bat).' }
Parar-Tabela
Start-Sleep 2
Start-ScheduledTask -TaskName $NomeTarefa
$porta = Ler-Env 'PORTA'
if (Esperar-Tabela $porta 60) { Write-Host "Tabela reiniciada: http://localhost:$porta" -ForegroundColor Green }
else { Write-Host "Não respondeu em 60 s. Veja back\dados\logs\servidor.log" -ForegroundColor Yellow }
