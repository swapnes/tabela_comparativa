const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: config.databaseUrl,
  // Nada fica pendurado (11/11/2026): sem conexão com o banco em 10 s, o pedido dá erro (o site tenta de novo);
  // uma consulta que passar de 60 s é cancelada pelo próprio PostgreSQL
  connectionTimeoutMillis: 10 * 1000,
  statement_timeout: 60 * 1000,
  keepAlive: true,
  // ssl: {
  //   rejectUnauthorized:false
  // }
});

// Sem esse listener, um erro numa conexão ociosa derruba o servidor
pool.on('error', (err) => {
  console.log('Erro inesperado no pool do banco:', err);
});

module.exports = pool;
