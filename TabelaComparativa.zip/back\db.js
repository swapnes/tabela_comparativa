const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: config.databaseUrl,
  // ssl: {
  //   rejectUnauthorized:false
  // }
});

// Sem esse listener, um erro numa conexão ociosa derruba o servidor
pool.on('error', (err) => {
  console.log('Erro inesperado no pool do banco:', err);
});

module.exports = pool;
