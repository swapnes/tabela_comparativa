// Restaura as tabelas da tabela antiga (cameras e gravadores, com os dados técnicos) a partir de um
// arquivo gerado pelo pg_dump no servidor do trabalho. Uso: node ferramentas/restaurarTabelaAntiga.js caminho.sql
// Segurança: só roda se as tabelas daqui estiverem vazias (nunca sobrescreve dados).
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const config = require('../config');
const pool = require('../db');

const TABELAS = ['cameras', 'gravadores'];

// Instruções da cópia que só fazem sentido no servidor antigo e quebrariam a restauração aqui:
// dono das tabelas (usuário de lá), permissões e o gatilho "verificar_phaseout" (a função dele não vem
// no pg_dump -t; o status agora é controlado pelo sistema). Os dados e as colunas são mantidos.
const INSTRUCOES_DO_SERVIDOR_ANTIGO = [/^ALTER TABLE .* OWNER TO /, /^GRANT /, /^REVOKE /, /^CREATE TRIGGER /];

// Tira as instruções acima (sem mexer nas linhas de dados dos blocos COPY) e grava uma cópia temporária
const prepararArquivo = (conteudo) => {
  let dentroDoCopy = false;
  const ignoradas = [];
  const linhas = conteudo.split(/\r?\n/).filter(linha => {
    if (dentroDoCopy) {
      if (linha === '\\.') dentroDoCopy = false;
      return true;
    }
    if (/^COPY .* FROM stdin;$/.test(linha)) {
      dentroDoCopy = true;
      return true;
    }
    if (INSTRUCOES_DO_SERVIDOR_ANTIGO.some(padrao => padrao.test(linha))) {
      ignoradas.push(linha);
      return false;
    }
    return true;
  });
  const temporario = path.join(require('os').tmpdir(), `tabela_antiga_${Date.now()}.sql`);
  fs.writeFileSync(temporario, linhas.join('\n'), 'utf8');
  return { temporario, ignoradas };
};

const acharPsql = () => {
  const base = 'C:\\Program Files\\PostgreSQL';
  if (!fs.existsSync(base)) return null;
  const versoes = fs.readdirSync(base).sort((a, b) => Number(b) - Number(a));
  for (const versao of versoes) {
    const psql = path.join(base, versao, 'bin', 'psql.exe');
    if (fs.existsSync(psql)) return psql;
  }
  return null;
};

const contar = async (tabela) => {
  try {
    const result = await pool.query(`SELECT count(*)::int AS total FROM ${tabela}`);
    return result.rows[0].total;
  } catch (err) {
    if (err.code === '42P01') return null; // tabela não existe
    throw err;
  }
};

const principal = async () => {
  const arquivo = path.resolve(process.argv[2] || path.join(__dirname, '..', '..', 'tabela_antiga.sql'));
  if (!fs.existsSync(arquivo)) {
    throw new Error(`Arquivo não encontrado: ${arquivo}\nColoque o "tabela_antiga.sql" na pasta principal da tabela (ou arraste o arquivo sobre o .bat).`);
  }
  const conteudo = fs.readFileSync(arquivo, 'utf8');
  if (!/CREATE TABLE [\w."]*cameras/i.test(conteudo) && !/CREATE TABLE [\w."]*gravadores/i.test(conteudo)) {
    throw new Error('O arquivo não parece ser a cópia das tabelas cameras/gravadores (pg_dump).');
  }

  const psql = acharPsql();
  if (!psql) throw new Error('psql não encontrado (PostgreSQL não instalado em C:\\Program Files\\PostgreSQL).');

  // Não sobrescreve nada: se já tiver equipamentos, para
  for (const tabela of TABELAS) {
    const total = await contar(tabela);
    if (total > 0) {
      throw new Error(`A tabela "${tabela}" daqui já tem ${total} equipamentos. Restauração cancelada para não misturar/sobrescrever dados.`);
    }
  }
  // Tabelas vazias criadas pelo sistema: remove para a cópia criar as originais (com as colunas de lá)
  for (const tabela of TABELAS) {
    if (await contar(tabela) === 0) {
      await pool.query(`DROP TABLE ${tabela}`);
      console.log(`Tabela vazia "${tabela}" removida para receber a cópia.`);
    }
  }
  await pool.end();

  const { temporario, ignoradas } = prepararArquivo(conteudo);
  if (ignoradas.length > 0) {
    console.log('Ignorando instruções do servidor antigo (não afetam os dados):');
    ignoradas.forEach(linha => console.log(`  - ${linha.slice(0, 110)}`));
  }

  console.log(`Restaurando ${path.basename(arquivo)}...`);
  const resultado = spawnSync(psql, ['-v', 'ON_ERROR_STOP=1', '-q', '-d', config.databaseUrl, '-f', temporario], { stdio: 'inherit' });
  fs.unlink(temporario, () => {});
  if (resultado.status !== 0) {
    throw new Error('O psql encontrou um erro ao restaurar (veja a mensagem acima). Nada foi apagado do servidor do trabalho.');
  }

  const { Pool } = require('pg');
  const conferencia = new Pool({ connectionString: config.databaseUrl });
  for (const tabela of TABELAS) {
    const result = await conferencia.query(`SELECT count(*)::int AS total, count(*) FILTER (WHERE phaseout = 'Equipamento em linha')::int AS em_linha FROM ${tabela}`)
      .catch(() => ({ rows: [{ total: 0, em_linha: 0 }] }));
    console.log(`  ${tabela}: ${result.rows[0].total} equipamentos (${result.rows[0].em_linha} em linha)`);
  }
  await conferencia.end();
  console.log('Pronto! Os dados técnicos da tabela antiga estão neste banco.');
};

principal().catch(async (err) => {
  console.error(`\nERRO: ${err.message}`);
  await pool.end().catch(() => {});
  process.exit(1);
});
