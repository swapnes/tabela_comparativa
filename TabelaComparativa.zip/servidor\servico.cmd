@echo off
rem ==================================================================
rem  Vigia da Tabela Comparativa (NAO precisa abrir na mao).
rem  A tarefa agendada "Tabela Comparativa" roda este arquivo ao ligar o PC,
rem  como SYSTEM, sem janela e sem ninguem logado.
rem  Se a tabela fechar por qualquer motivo, liga de novo em 5 segundos.
rem  Registro: back\dados\logs\servidor.log
rem ==================================================================
setlocal
set "PASTA=%~dp0.."
set "NODE=%ProgramFiles%\nodejs\node.exe"
if not exist "%NODE%" for /f "delims=" %%n in ('where node 2^>nul') do set "NODE=%%n"
set "LOGS=%PASTA%\back\dados\logs"
if not exist "%LOGS%" mkdir "%LOGS%"
cd /d "%PASTA%\back"

:ligar
rem Registro com mais de 5 MB vira servidor-anterior.log (nao cresce sem fim)
if exist "%LOGS%\servidor.log" for %%A in ("%LOGS%\servidor.log") do if %%~zA GTR 5000000 move /y "%LOGS%\servidor.log" "%LOGS%\servidor-anterior.log" >nul
echo [%date% %time%] Ligando a tabela...>> "%LOGS%\servidor.log"
"%NODE%" "%PASTA%\back\index.js" >> "%LOGS%\servidor.log" 2>&1
echo [%date% %time%] A tabela parou (codigo %errorlevel%). Ligando de novo em 5 s.>> "%LOGS%\servidor.log"
ping -n 6 127.0.0.1 >nul
goto ligar
