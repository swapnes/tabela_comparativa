@echo off
rem Reinicia a tabela no servidor (use depois de atualizar arquivos ou mudar o back\.env).
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor\reiniciar.ps1"
echo.
pause
