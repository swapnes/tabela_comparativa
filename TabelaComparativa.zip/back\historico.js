// Histórico de alterações: registra cada mudança (com os dados de antes e depois) e permite desfazer.
// Desfazer executa a operação inversa pelas funções normais do sistema, então o "desfazer" também fica
// registrado e pode ser desfeito (nada se perde).
const pool = require('./db');

const ACOES = {
  ADICIONAR: 'adicionar',
  REMOVER: 'remover',
  ALTERAR: 'alterar',
  CARACTERISTICA_CRIAR: 'caracteristica_criar',
  CARACTERISTICA_SALVAR: 'caracteristica_salvar',
  CARACTERISTICA_EXCLUIR: 'caracteristica_excluir',
};

const dataLocal = (data) => {
  const mes = String(data.getMonth() + 1).padStart(2, '0');
  const dia = String(data.getDate()).padStart(2, '0');
  return `${data.getFullYear()}-${mes}-${dia}`;
};

// Valor em forma comparável (datas viram aaaa-mm-dd; vazio vira null)
const normalizarValor = (valor) => {
  if (valor === null || valor === undefined || valor === '') return null;
  if (valor instanceof Date) return dataLocal(valor);
  const texto = String(valor);
  if (/^\d{4}-\d{2}-\d{2}T/.test(texto)) return dataLocal(new Date(texto));
  return texto;
};

// Nunca impede a operação principal: se o registro falhar, só avisa no console
const registrar = async ({ acao, tabela = null, nome = null, descricao, antes = null, depois = null, origem = 'admin', lote = null }) => {
  try {
    const result = await pool.query(
      `INSERT INTO historico (acao, tabela, nome, descricao, antes, depois, origem, lote)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
      [acao, tabela, nome, descricao, antes === null ? null : JSON.stringify(antes), depois === null ? null : JSON.stringify(depois), origem, lote]
    );
    return result.rows[0].id;
  } catch (err) {
    console.log('Erro ao registrar no histórico:', err.message);
    return null;
  }
};

// Filtros: origem ('admin' | 'planilha' | 'desfazer'), tipo ('equipamentos' | 'caracteristicas'), busca (nome/descrição)
const listar = async ({ limite = 200, origem, tipo, busca } = {}) => {
  const condicoes = [];
  const parametros = [];
  if (origem) {
    parametros.push(origem);
    condicoes.push(`origem = $${parametros.length}`);
  }
  if (tipo === 'equipamentos') condicoes.push(`acao IN ('adicionar', 'remover', 'alterar')`);
  if (tipo === 'caracteristicas') condicoes.push(`acao LIKE 'caracteristica_%'`);
  if (busca) {
    parametros.push(`%${busca}%`);
    condicoes.push(`(nome ILIKE $${parametros.length} OR descricao ILIKE $${parametros.length})`);
  }
  parametros.push(Math.min(Math.max(Number(limite) || 200, 1), 1000));
  const where = condicoes.length ? `WHERE ${condicoes.join(' AND ')}` : '';
  try {
    const result = await pool.query(`SELECT * FROM historico ${where} ORDER BY id DESC LIMIT $${parametros.length}`, parametros);
    return result.rows;
  } catch (err) {
    if (err.code === '42P01') return [];
    throw err;
  }
};

// Equipamentos removidos pelo admin no painel que continuam fora da tabela (aba "Removidos").
// Usa a remoção mais recente de cada equipamento; some da lista quando é restaurado ou cadastrado de novo.
const listarRemovidos = async () => {
  let removidos;
  try {
    removidos = (await pool.query(
      `SELECT DISTINCT ON (tabela, nome) id, tabela, nome, criado_em, antes, desfeito_em
       FROM historico
       WHERE acao = 'remover' AND origem = 'admin'
       ORDER BY tabela, nome, id DESC`
    )).rows.filter(registro => !registro.desfeito_em);
  } catch (err) {
    if (err.code === '42P01') return [];
    throw err;
  }

  // Tira os que já voltaram para a tabela (restaurados ou cadastrados de novo com o mesmo nome)
  const existentes = new Set();
  for (const tabela of [...new Set(removidos.map(registro => registro.tabela))]) {
    try {
      const result = await pool.query(`SELECT nome FROM ${tabela.replace(/[^a-z_]/g, '')}`);
      result.rows.forEach(linha => existentes.add(`${tabela}|${linha.nome}`));
    } catch (err) {
      if (err.code !== '42P01') throw err;
    }
  }
  return removidos
    .filter(registro => !existentes.has(`${registro.tabela}|${registro.nome}`))
    .sort((a, b) => new Date(b.criado_em) - new Date(a.criado_em));
};

const buscar = async (id) => {
  const result = await pool.query(`SELECT * FROM historico WHERE id = $1`, [id]);
  return result.rows[0] || null;
};

// lote (opcional): agrupa os registros do próprio "desfazer" (usado ao desfazer uma aplicação inteira)
const desfazer = async (id, { lote = null } = {}) => {
  // Carregados aqui para evitar dependência circular (esses módulos registram no histórico)
  const equipamentos = require('./equipamentos');
  const colunas = require('./colunas');
  const alertas = require('./alertas');
  const { ErroEquipamento } = equipamentos;

  const entrada = await buscar(id);
  if (!entrada) throw new ErroEquipamento('Registro do histórico não encontrado', 404);
  if (entrada.desfeito_em) throw new ErroEquipamento('Essa alteração já foi desfeita', 409);

  const opcoes = { origem: 'desfazer', lote };
  let novoId = null;

  // Equipamento de um tipo que não tem mais tabela (ex.: TESTER da antiga aba Acessórios): os dados ficam só aqui
  if (!entrada.acao.startsWith('caracteristica') && !equipamentos.tabelaValida(entrada.tabela)) {
    throw new ErroEquipamento('Esse tipo de equipamento não tem mais aba na tabela; os dados ficam guardados aqui no histórico.', 409);
  }

  switch (entrada.acao) {
    case ACOES.ADICIONAR: {
      novoId = await equipamentos.remover(entrada.tabela, entrada.nome, { ...opcoes, descricao: `Desfeito o cadastro: ${entrada.nome}` });
      await alertas.resolverDoEquipamento(entrada.tabela, entrada.nome).catch(() => {});
      break;
    }
    case ACOES.REMOVER: {
      novoId = await equipamentos.restaurar(entrada.tabela, entrada.antes, { ...opcoes, descricao: `Restaurado: ${entrada.nome}` });
      break;
    }
    case ACOES.ALTERAR: {
      const atual = await equipamentos.buscarPorNome(entrada.tabela, entrada.nome);
      if (!atual) {
        throw new ErroEquipamento(`${entrada.nome} não existe mais (foi removido ou renomeado depois). Desfaça primeiro as mudanças mais recentes.`, 409);
      }
      const mudaramDepois = Object.keys(entrada.depois || {})
        .filter(coluna => normalizarValor(atual[coluna]) !== normalizarValor(entrada.depois[coluna]));
      if (mudaramDepois.length > 0) {
        throw new ErroEquipamento(`${entrada.nome} foi alterado de novo depois (${mudaramDepois.join(', ')}). Desfaça primeiro as mudanças mais recentes.`, 409);
      }
      novoId = await equipamentos.alterar(entrada.tabela, entrada.nome, entrada.antes, { ...opcoes, descricao: `Desfeita a alteração: ${entrada.nome}` });
      if (entrada.antes && entrada.antes.nome && entrada.antes.nome !== entrada.nome) {
        await alertas.renomearEquipamento(entrada.tabela, entrada.nome, entrada.antes.nome).catch(() => {});
      }
      break;
    }
    case ACOES.CARACTERISTICA_CRIAR:
    case ACOES.CARACTERISTICA_SALVAR:
    case ACOES.CARACTERISTICA_EXCLUIR:
      novoId = await colunas.desfazer(entrada, opcoes);
      break;
    default:
      throw new ErroEquipamento('Esse tipo de alteração não pode ser desfeito');
  }

  await pool.query(`UPDATE historico SET desfeito_em = now(), desfeito_por = $2 WHERE id = $1`, [id, novoId]);
  return { novoId };
};

// Desfaz todas as mudanças de um lote (ex.: uma aplicação da planilha), da mais nova para a mais antiga
const desfazerLote = async (lote) => {
  const result = await pool.query(
    `SELECT id, descricao FROM historico WHERE lote = $1 AND desfeito_em IS NULL ORDER BY id DESC`,
    [lote]
  );
  let desfeitos = 0;
  const erros = [];
  const loteDoDesfazer = `desfeito:${lote}`;
  for (const { id, descricao } of result.rows) {
    try {
      await desfazer(id, { lote: loteDoDesfazer });
      desfeitos++;
    } catch (err) {
      erros.push(`${descricao}: ${err.message}`);
    }
  }
  return { desfeitos, erros };
};

module.exports = { ACOES, registrar, listar, listarRemovidos, desfazer, desfazerLote, normalizarValor };
