﻿# Roda NO PC DE TESTES: monta PACOTE_ATUALIZACAO\TabelaComparativa só com o que muda numa atualização
# (programa e site). NÃO leva back\.env, back\dados nem o banco — no servidor isso fica como está.
. "$PSScriptRoot\comum.ps1"
$destino = Join-Path $Pasta 'PACOTE_ATUALIZACAO\TabelaComparativa'
if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }

$copias = @(
  @{ De = 'back'; Excluir = @('node_modules', 'dados'); ExcluirArquivos = @('.env') },
  @{ De = 'front\build' },
  @{ De = 'servidor'; Excluir = @('banco') }
)
foreach ($c in $copias) {
  $origem = Join-Path $Pasta $c.De
  $alvo = Join-Path $destino $c.De
  $xd = @(); foreach ($d in $c.Excluir) { $xd += (Join-Path $origem $d) }
  $argumentos = @($origem, $alvo, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  if ($xd.Count) { $argumentos += '/XD'; $argumentos += $xd }
  if ($c.ExcluirArquivos) { $argumentos += '/XF'; $argumentos += $c.ExcluirArquivos }
  & robocopy @argumentos | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "Falha ao copiar $($c.De) (robocopy $LASTEXITCODE)." }
}
Get-ChildItem $Pasta -File | Where-Object { $_.Extension -in '.bat', '.md' } | Copy-Item -Destination $destino

if (Test-Path (Join-Path $destino 'back\.env')) { throw 'ERRO: o .env entrou no pacote.' }
$tamanho = [math]::Round(((Get-ChildItem $destino -Recurse -File | Measure-Object Length -Sum).Sum) / 1MB, 1)
Write-Host "OK  $destino ($tamanho MB)" -ForegroundColor Green
Write-Host ''
Write-Host 'No servidor: copie o CONTEUDO desta pasta por cima de C:\TabelaComparativa (substituir arquivos)' -ForegroundColor Green
Write-Host 'e rode REINICIAR_TABELA.bat. O back\.env, os dados e o banco de la nao sao tocados.' -ForegroundColor Green
