// Características (colunas / filtros) configuradas pelo painel do admin.
// - criar: cria uma coluna nova na tabela do banco (característica personalizada)
// - salvar: muda nome, categoria ou "escondida" de qualquer característica (original ou personalizada)
// - excluir: apaga qualquer característica, guardando os valores no histórico (dá para desfazer)
// - valores / trocarValor: valores diferentes de uma característica e troca de um valor em todos (padronizar a escrita)
// O nome amigável, a categoria e se está escondida ficam em "colunas_personalizadas".
const pool = require('./db');
const historico = require('./historico');
const { TABELAS, COLUNAS_DE_CONTROLE, PHASEOUT_EM_LINHA, ErroEquipamento, alterar } = require('./equipamentos');

const configuracaoAtual = async (tabela, coluna) => {
  const result = await pool.query(
    `SELECT tabela, coluna, rotulo, categoria, oculta, personalizada FROM colunas_personalizadas WHERE tabela = $1 AND coluna = $2`,
    [tabela, coluna]
  );
  return result.rows[0] || null;
};

// "Resolução térmica (px)" -> "resolucao_termica_px"
const nomeTecnico = (rotulo) => {
  let nome = String(rotulo || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
  if (/^\d/.test(nome)) nome = `c_${nome}`;
  return nome;
};

const validarTabela = (tabela) => {
  if (!TABELAS.includes(tabela)) {
    throw new ErroEquipamento('Tipo de equipamento inválido');
  }
};

const listar = async () => {
  try {
    const result = await pool.query(
      `SELECT id, tabela, coluna, rotulo, categoria, oculta, personalizada FROM colunas_personalizadas ORDER BY id`
    );
    return result.rows;
  } catch (err) {
    if (err.code === '42P01') return []; // tabela ainda não criada
    throw err;
  }
};

const colunasDaTabela = async (tabela) => {
  const result = await pool.query(
    `SELECT column_name FROM information_schema.columns
     WHERE table_schema = current_schema() AND table_name = $1 ORDER BY ordinal_position`,
    [tabela]
  );
  return result.rows.map(linha => linha.column_name);
};

// Características de uma tabela e em quantos equipamentos cada uma está preenchida
const uso = async (tabela) => {
  validarTabela(tabela);
  const colunas = (await colunasDaTabela(tabela)).filter(coluna => !COLUNAS_DE_CONTROLE.includes(coluna));
  if (colunas.length === 0) return { total: 0, colunas: [] };

  // Os nomes vêm do próprio banco (information_schema), então podem ir no SQL entre aspas
  const contagens = colunas.map((coluna, indice) =>
    `count(NULLIF(NULLIF(trim("${coluna.replace(/"/g, '""')}"::text), ''), '-')) AS c${indice}`
  );
  const result = await pool.query(`SELECT count(*) AS total, ${contagens.join(', ')} FROM ${tabela}`);
  const linha = result.rows[0];
  return {
    total: Number(linha.total),
    colunas: colunas.map((coluna, indice) => ({ coluna, preenchidos: Number(linha[`c${indice}`]) })),
  };
};

const criar = async ({ tabela, rotulo, categoria }, opcoes = {}) => {
  validarTabela(tabela);
  const rotuloLimpo = String(rotulo || '').trim();
  const coluna = nomeTecnico(rotuloLimpo);
  if (!rotuloLimpo || !coluna) {
    throw new ErroEquipamento('Informe o nome da característica');
  }
  if ((await colunasDaTabela(tabela)).includes(coluna)) {
    throw new ErroEquipamento(`Já existe uma característica "${coluna}" nessa tabela`, 409);
  }

  // O nome da coluna vem de nomeTecnico (só letras minúsculas, números e "_"), seguro para o SQL
  await pool.query(`ALTER TABLE ${tabela} ADD COLUMN "${coluna}" TEXT`);
  const result = await pool.query(
    `INSERT INTO colunas_personalizadas (tabela, coluna, rotulo, categoria, personalizada)
     VALUES ($1, $2, $3, $4, true)
     ON CONFLICT (tabela, coluna) DO UPDATE SET rotulo = EXCLUDED.rotulo, categoria = EXCLUDED.categoria, personalizada = true
     RETURNING id, tabela, coluna, rotulo, categoria, oculta, personalizada`,
    [tabela, coluna, rotuloLimpo, String(categoria || '').trim() || null]
  );
  const criada = result.rows[0];
  criada.historicoId = await historico.registrar({
    acao: historico.ACOES.CARACTERISTICA_CRIAR,
    tabela,
    nome: coluna,
    descricao: opcoes.descricao || `Característica criada: ${rotuloLimpo}`,
    depois: await configuracaoAtual(tabela, coluna),
    origem: opcoes.origem,
  });
  return criada;
};

// Nome, categoria e "escondida" de qualquer característica (cria o ajuste se ainda não existir)
const salvar = async ({ tabela, coluna, rotulo, categoria, oculta }, opcoes = {}) => {
  validarTabela(tabela);
  const rotuloLimpo = String(rotulo || '').trim();
  if (!rotuloLimpo) {
    throw new ErroEquipamento('Informe o nome da característica');
  }
  if (COLUNAS_DE_CONTROLE.includes(coluna) || !(await colunasDaTabela(tabela)).includes(coluna)) {
    throw new ErroEquipamento('Característica não encontrada', 404);
  }
  const antes = await configuracaoAtual(tabela, coluna);
  const result = await pool.query(
    `INSERT INTO colunas_personalizadas (tabela, coluna, rotulo, categoria, oculta, personalizada)
     VALUES ($1, $2, $3, $4, $5, false)
     ON CONFLICT (tabela, coluna) DO UPDATE SET rotulo = EXCLUDED.rotulo, categoria = EXCLUDED.categoria, oculta = EXCLUDED.oculta
     RETURNING id, tabela, coluna, rotulo, categoria, oculta, personalizada`,
    [tabela, coluna, rotuloLimpo, String(categoria || '').trim() || null, oculta === true]
  );
  const salva = result.rows[0];
  let descricao = `Característica alterada: ${rotuloLimpo}`;
  if ((antes ? antes.oculta : false) !== salva.oculta) {
    descricao = `Característica ${salva.oculta ? 'escondida' : 'mostrada'} na tabela: ${rotuloLimpo}`;
  }
  salva.historicoId = await historico.registrar({
    acao: historico.ACOES.CARACTERISTICA_SALVAR,
    tabela,
    nome: coluna,
    descricao: opcoes.descricao || descricao,
    antes,
    depois: await configuracaoAtual(tabela, coluna),
    origem: opcoes.origem,
  });
  return salva;
};

// Volta a configuração de uma característica para um estado anterior (null = sem ajuste, volta ao padrão)
const restaurarConfiguracao = async (tabela, coluna, configuracao, opcoes = {}) => {
  const antes = await configuracaoAtual(tabela, coluna);
  if (configuracao) {
    await pool.query(
      `INSERT INTO colunas_personalizadas (tabela, coluna, rotulo, categoria, oculta, personalizada)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (tabela, coluna) DO UPDATE SET rotulo = EXCLUDED.rotulo, categoria = EXCLUDED.categoria, oculta = EXCLUDED.oculta`,
      [tabela, coluna, configuracao.rotulo, configuracao.categoria, configuracao.oculta === true, configuracao.personalizada === true]
    );
  } else {
    await pool.query(`DELETE FROM colunas_personalizadas WHERE tabela = $1 AND coluna = $2 AND personalizada = false`, [tabela, coluna]);
  }
  return historico.registrar({
    acao: historico.ACOES.CARACTERISTICA_SALVAR,
    tabela,
    nome: coluna,
    descricao: opcoes.descricao || `Característica restaurada: ${(configuracao && configuracao.rotulo) || coluna}`,
    antes,
    depois: await configuracaoAtual(tabela, coluna),
    origem: opcoes.origem,
  });
};

// Tipo da coluna no banco (ex.: "text", "character varying(255)", "boolean"), para recriar igual no "Desfazer"
const tipoDaColuna = async (tabela, coluna) => {
  const result = await pool.query(
    `SELECT format_type(a.atttypid, a.atttypmod) AS tipo
     FROM pg_attribute a
     WHERE a.attrelid = to_regclass($1) AND a.attname = $2 AND NOT a.attisdropped`,
    [tabela, coluna]
  );
  return result.rows[0] ? result.rows[0].tipo : 'text';
};

const TIPO_SEGURO = /^[a-z][a-z0-9 ]*(\(\d+(,\s*\d+)?\))?(\[\])?$/i;

// Exclui qualquer característica (original ou criada pelo painel), menos nome/link/status.
// Antes de apagar a coluna, guarda no histórico o nome, a categoria, o tipo e TODOS os valores preenchidos:
// o "Desfazer" recria a coluna e devolve os valores a cada equipamento.
// opcoes.rotulo: nome mostrado na tela (para o histórico); opcoes.somenteVazia: recusa se tiver valores
const excluir = async (tabela, coluna, opcoes = {}) => {
  validarTabela(tabela);
  if (COLUNAS_DE_CONTROLE.includes(coluna) || !(await colunasDaTabela(tabela)).includes(coluna)) {
    throw new ErroEquipamento('Característica não encontrada', 404);
  }
  const nomeSql = `"${coluna.replace(/"/g, '""')}"`;
  const valores = (await pool.query(
    `SELECT nome, ${nomeSql}::text AS valor FROM ${tabela}
     WHERE ${nomeSql} IS NOT NULL AND trim(${nomeSql}::text) <> '' ORDER BY nome`
  )).rows;
  if (opcoes.somenteVazia && valores.length > 0) {
    throw new ErroEquipamento(`Essa característica já está preenchida em ${valores.length} equipamento(s); exclua pela página Características.`, 409);
  }

  const configuracao = await configuracaoAtual(tabela, coluna);
  const antes = {
    tabela,
    coluna,
    rotulo: (configuracao && configuracao.rotulo) || String(opcoes.rotulo || '').trim() || coluna,
    categoria: configuracao ? configuracao.categoria : null,
    oculta: configuracao ? configuracao.oculta : false,
    personalizada: configuracao ? configuracao.personalizada : false,
    configurada: Boolean(configuracao),
    tipo: await tipoDaColuna(tabela, coluna),
    valores,
  };

  const cliente = await pool.connect();
  try {
    await cliente.query('BEGIN');
    await cliente.query(`ALTER TABLE ${tabela} DROP COLUMN ${nomeSql}`);
    await cliente.query(`DELETE FROM colunas_personalizadas WHERE tabela = $1 AND coluna = $2`, [tabela, coluna]);
    await cliente.query('COMMIT');
  } catch (err) {
    await cliente.query('ROLLBACK');
    throw err;
  } finally {
    cliente.release();
  }

  return historico.registrar({
    acao: historico.ACOES.CARACTERISTICA_EXCLUIR,
    tabela,
    nome: coluna,
    descricao: opcoes.descricao || `Característica excluída: ${antes.rotulo}${valores.length ? ` (${valores.length} valores guardados)` : ''}`,
    antes,
    origem: opcoes.origem,
    lote: opcoes.lote || null,
  });
};

// Recria uma característica excluída com o mesmo tipo, nome, categoria e os valores que ela tinha
const recriar = async (configuracao, opcoes = {}) => {
  const { tabela, coluna } = configuracao;
  validarTabela(tabela);
  if (!/^[a-z0-9_]+$/.test(coluna)) {
    throw new ErroEquipamento('Nome técnico inválido');
  }
  if ((await colunasDaTabela(tabela)).includes(coluna)) {
    throw new ErroEquipamento(`A característica "${configuracao.rotulo || coluna}" já existe de novo; nada foi alterado.`, 409);
  }
  const tipo = TIPO_SEGURO.test(configuracao.tipo || '') ? configuracao.tipo : 'text';
  const valores = Array.isArray(configuracao.valores) ? configuracao.valores : [];

  const cliente = await pool.connect();
  try {
    await cliente.query('BEGIN');
    await cliente.query(`ALTER TABLE ${tabela} ADD COLUMN "${coluna}" ${tipo}`);
    if (valores.length > 0) {
      await cliente.query(
        `UPDATE ${tabela} t SET "${coluna}" = v.valor::${tipo}
         FROM (SELECT unnest($1::text[]) AS nome, unnest($2::text[]) AS valor) v
         WHERE t.nome = v.nome`,
        [valores.map(item => item.nome), valores.map(item => item.valor)]
      );
    }
    // Registros antigos (antes desta versão) não têm "configurada": eram sempre características do painel
    if (configuracao.configurada !== false) {
      await cliente.query(
        `INSERT INTO colunas_personalizadas (tabela, coluna, rotulo, categoria, oculta, personalizada)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (tabela, coluna) DO UPDATE SET rotulo = EXCLUDED.rotulo, categoria = EXCLUDED.categoria, oculta = EXCLUDED.oculta`,
        [tabela, coluna, configuracao.rotulo, configuracao.categoria, configuracao.oculta === true, configuracao.personalizada !== false]
      );
    }
    await cliente.query('COMMIT');
  } catch (err) {
    await cliente.query('ROLLBACK');
    throw err;
  } finally {
    cliente.release();
  }

  return historico.registrar({
    acao: historico.ACOES.CARACTERISTICA_CRIAR,
    tabela,
    nome: coluna,
    descricao: opcoes.descricao || `Característica recriada: ${configuracao.rotulo || coluna}${valores.length ? ` (${valores.length} valores devolvidos)` : ''}`,
    depois: (await configuracaoAtual(tabela, coluna)) || { tabela, coluna, rotulo: configuracao.rotulo },
    origem: opcoes.origem,
  });
};

const validarCaracteristica = async (tabela, coluna) => {
  validarTabela(tabela);
  if (COLUNAS_DE_CONTROLE.includes(coluna) || !(await colunasDaTabela(tabela)).includes(coluna)) {
    throw new ErroEquipamento('Característica não encontrada', 404);
  }
  return `"${coluna.replace(/"/g, '""')}"`;
};

// Valores diferentes de uma característica, com quantos equipamentos usam cada um (e quais)
const valores = async (tabela, coluna) => {
  const nomeSql = await validarCaracteristica(tabela, coluna);
  const result = await pool.query(
    `SELECT ${nomeSql}::text AS valor, count(*)::int AS total,
            count(*) FILTER (WHERE phaseout = $1)::int AS em_linha, array_agg(nome ORDER BY nome) AS nomes
     FROM ${tabela} WHERE ${nomeSql} IS NOT NULL AND trim(${nomeSql}::text) <> ''
     GROUP BY 1 ORDER BY 2 DESC, 1`,
    [PHASEOUT_EM_LINHA]
  );
  return result.rows;
};

// Troca um valor por outro em todos os equipamentos que têm exatamente esse valor ("para" vazio = apaga).
// Fica num lote só no histórico ("Padronização da escrita" → Desfazer tudo).
const trocarValor = async (tabela, coluna, { de, para, rotulo }) => {
  const nomeSql = await validarCaracteristica(tabela, coluna);
  const antigo = String(de ?? '');
  const novo = String(para ?? '').trim();
  if (!antigo) {
    throw new ErroEquipamento('Informe o valor a trocar');
  }
  if (novo === antigo) {
    throw new ErroEquipamento('O valor novo é igual ao atual');
  }
  const nomes = (await pool.query(`SELECT nome FROM ${tabela} WHERE ${nomeSql}::text = $1 ORDER BY nome`, [antigo])).rows.map(linha => linha.nome);
  if (nomes.length === 0) {
    throw new ErroEquipamento('Nenhum equipamento tem mais esse valor', 404);
  }

  const lote = `padronizacao:${new Date().toISOString()}`;
  const titulo = String(rotulo || '').trim() || coluna;
  let alterados = 0;
  const erros = [];
  for (const nome of nomes) {
    try {
      const descricao = `${titulo}: "${antigo}" → ${novo ? `"${novo}"` : 'vazio'} (${nome})`;
      if (await alterar(tabela, nome, { [coluna]: novo }, { lote, descricao })) alterados++;
    } catch (err) {
      if (!(err instanceof ErroEquipamento)) throw err;
      erros.push(`${nome}: ${err.message}`);
    }
  }
  return { alterados, erros, lote };
};

// Colunas que existem hoje em cada tabela (o site esconde as definições de colunas excluídas)
const colunasExistentes = async () => {
  const resultado = {};
  for (const tabela of TABELAS) {
    resultado[tabela] = await colunasDaTabela(tabela);
  }
  return resultado;
};

// Desfaz um registro do histórico de características (chamado por historico.desfazer)
const desfazer = async (entrada, opcoes = {}) => {
  const { acao, tabela, nome: coluna } = entrada;
  if (acao === historico.ACOES.CARACTERISTICA_CRIAR) {
    return excluir(tabela, coluna, { ...opcoes, somenteVazia: true, descricao: `Desfeita a criação da característica: ${entrada.depois ? entrada.depois.rotulo : coluna}` });
  }
  if (acao === historico.ACOES.CARACTERISTICA_EXCLUIR) {
    if (!entrada.antes) throw new ErroEquipamento('Não há dados para recriar essa característica');
    return recriar(entrada.antes, opcoes);
  }
  return restaurarConfiguracao(tabela, coluna, entrada.antes, opcoes);
};

module.exports = { listar, uso, criar, salvar, excluir, valores, trocarValor, desfazer, colunasExistentes };
